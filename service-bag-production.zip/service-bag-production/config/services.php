<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'resend' => [
        'key' => env('RESEND_KEY'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'jwt' => [
        'key' => env('JWT_KEY'),
        'ttl' => env('JWT_TTL', 900),
    ],

    'bag' => [
        'account_no' => env('BAG_ACCOUNT_NO'),
        'snap'       => [
            'base_url' => env('BAG_SNAP_BASE_URL'),
            'inbound'  => [
                'client_name'   => env('BAG_SNAP_INBOUND_CLIENT_NAME'),
                'client_id'     => env('BAG_SNAP_INBOUND_CLIENT_ID'),
                'client_secret' => env('BAG_SNAP_INBOUND_CLIENT_SECRET')
            ],
            'outbound' => [
                'client_id'     => env('BAG_SNAP_OUTBOUND_CLIENT_ID'),
                'client_secret' => env('BAG_SNAP_OUTBOUND_CLIENT_SECRET'),
                'partner_id'    => env('BAG_SNAP_OUTBOUND_PARTNER_ID'),
                'channel_id'    => env('BAG_SNAP_OUTBOUND_CHANNEL_ID'),
            ],
            'va' => [
                'length'                  => env('BAG_SNAP_VA_LENGTH', 16),
                'prefix_open'             => env('BAG_SNAP_VA_PREFIX_OPEN'),
                'prefix_closed'           => env('BAG_SNAP_VA_PREFIX_CLOSED'),
                'prefix_reference_number' => env('BAG_SNAP_VA_PREFIX_REF_NUMBER', 'BAG'),
            ]
        ],
        'non_snap' => [
            'base_url'    => env('BAG_NON_SNAP_BASE_URL'),
            'merchant_id' => env('BAG_NON_SNAP_MERCHANT_ID'),
            'api_key'     => env('BAG_NON_SNAP_API_KEY'),
            'secret_key'  => env('BAG_NON_SNAP_SECRET_KEY')
        ],
        'client_lock_duration' => env('BAG_CLIENT_LOCK_DURATION', 300),
        'vendor_lock_duration' => env('BAG_VENDOR_LOCK_DURATION', 300),
    ],

    'http' => [
        'logging' => env('HTTP_LOGGING_CALL', true),
        'retry' => [
            'default' => [
                'attempts'       => env('RETRY_DEFAULT_ATTEMPTS', 0),
                'delay_ms'       => env('RETRY_DEFAULT_DELAY_MS', 1000),
                'timeout'        => env('RETRY_DEFAULT_TIMEOUT', 120),
                'retry_on_codes' => env('RETRY_DEFAULT_ON_CODES', ''),
            ]
        ],
    ]
];

<?php

namespace Database\Seeders;

use App\Models\Client;
use Illuminate\Database\Seeder;

class ClientSeeder extends Seeder
{
    public function run(): void
    {
        // Client::factory()->create([
        //     'name'                => 'Paprika Core PG',
        //     'base_url'            => 'http://core-pg.test',
        //     'va_payment_endpoint' => '/api/v1/virtual-accounts/payment',
        // ]);
        // if (app()->environment(['local'])) {
        //     Client::factory(2)->create();
        // } elseif (app()->environment(['test'])) {
        //     Client::factory()->create(['is_active' => false]);
        //     Client::factory(2)->create();
        // }
    }
}

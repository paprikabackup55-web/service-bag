<?php

namespace Database\Seeders;

use App\Models\PaymentMethod;
use Illuminate\Database\Seeder;

class PaymentMethodSeeder extends Seeder
{
    public function run(): void
    {
        $methods = [
            [
                'id' => PaymentMethod::INTRA,
                'code' => 'INTRA',
                'name' => 'Intrabank',
            ],
            [
                'id' => PaymentMethod::INTER,
                'code' => 'INTER',
                'name' => 'Interbank',
            ],
            [
                'id' => PaymentMethod::BI_FAST,
                'code' => 'BI_FAST',
                'name' => 'BI FAST',
            ],
            [
                'id' => PaymentMethod::VA_OPEN,
                'code' => 'VA_OPEN',
                'name' => 'VA Open',
            ],
            [
                'id' => PaymentMethod::VA_CLOSED,
                'code' => 'VA_CLOSED',
                'name' => 'VA Closed',
            ],
        ];

        foreach ($methods as $method) {
            PaymentMethod::upsert(
                $method,
                'id',
                ['code', 'name']
            );
        }
    }
}

<?php

namespace Database\Seeders;

use App\Models\Client;
use App\Models\ClientIpAddress;
use Illuminate\Database\Seeder;

class ClientIpAddressSeeder extends Seeder
{
    public function run(): void
    {
        if (app()->environment(['local', 'test'])) {
            // $clientIds = Client::pluck('id');

            // foreach ($clientIds as $clientId) {
            //     ClientIpAddress::factory()->create([
            //         'client_id' => $clientId,
            //         'value' => '127.0.0.1'
            //     ]);

            //     ClientIpAddress::factory(rand(2, 5))->create(['client_id' => $clientId]);
            // }
        }
    }
}

<?php

namespace Database\Seeders;

use App\Models\ApiService;
use Illuminate\Database\Seeder;

class ApiServiceSeeder extends Seeder
{
    public function run(): void
    {
        $services = [
            ['id' => ApiService::ACCOUNT_BALANCE, 'name' => 'Account Balance'],
            ['id' => ApiService::ACCOUNT_STATEMENT, 'name' => 'Account Statement'],
            ['id' => ApiService::DISBURSEMENT_INQUIRY_ACCOUNT, 'name' => 'Disbursement - Inquiry account'],
            ['id' => ApiService::DISBURSEMENT_TRANSFER, 'name' => 'Disbursement - Transfer'],
            ['id' => ApiService::DISBURSEMENT_INQUIRY_STATUS, 'name' => 'Disbursement - Inquiry status'],
            ['id' => ApiService::VIRTUAL_ACCOUNT_CREATE, 'name' => 'Virtual Account - Create'],
            ['id' => ApiService::VIRTUAL_ACCOUNT_UPDATE, 'name' => 'Virtual Account - Update'],
            ['id' => ApiService::VIRTUAL_ACCOUNT_DELETE, 'name' => 'Virtual Account - Delete'],
            ['id' => ApiService::ACCESS_TOKEN, 'name' => 'Access Token', 'code' => '73'],
            ['id' => ApiService::VIRTUAL_ACCOUNT_INQUIRY, 'name' => 'Virtual Account - Inquiry', 'code' => '24'],
            ['id' => ApiService::VIRTUAL_ACCOUNT_PAYMENT, 'name' => 'Virtual Account - Payment', 'code' => '25'],
            ['id' => ApiService::VIRTUAL_ACCOUNT_NOTIFICATION, 'name' => 'Virtual Account - Notification', 'code' => '24'],
        ];

        foreach ($services as $service) {
            ApiService::upsert(
                $service,
                'id',
                ['name']
            );
        }
    }
}

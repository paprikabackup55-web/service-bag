<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('clients', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->uuid('api_key')->unique();
            $table->text('private_key');
            $table->text('client_api_key')->nullable();
            $table->text('public_key')->nullable();
            $table->boolean('is_active')->default(true);
            $table->string('base_url')->nullable();
            $table->string('va_payment_endpoint')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('clients');
    }
};

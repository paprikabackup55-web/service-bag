<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('virtual_account_inquiries', function (Blueprint $table) {
            $table->id();
            $table->string('request_id', 128)->unique();
            $table->string('reference_no', 24)->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->string('channel_id', 5);
            $table->string('merchant_id', 6)->nullable();
            $table->string('processing_code', 6)->nullable();
            $table->string('flag_amount_check', 2)->nullable();
            $table->string('hashed_source_account_no', 32)->nullable();
            $table->string('source_bank_code', 3)->nullable();
            $table->foreignId('virtual_account_id')->constrained('virtual_accounts');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('virtual_account_inquiries');
    }
};

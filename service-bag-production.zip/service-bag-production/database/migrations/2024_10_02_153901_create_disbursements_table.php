<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('disbursements', function (Blueprint $table) {
            $table->id();
            $table->char('status_code', 2)->nullable();
            $table->string('partner_reference_no', 30);
            $table->char('reference_no', 30)->unique();
            $table->string('customer_reference_no', 30)->nullable();
            $table->string('account_no', 30);
            $table->string('account_name', 100)->nullable();
            $table->char('receiver_type', 2)->nullable();
            $table->char('receiver_account_type', 2)->nullable();
            $table->char('bank_code', 3);
            $table->char('bank_type', 2)->nullable();
            $table->decimal('amount', 20);
            $table->char('currency', 3);
            $table->string('remark')->nullable();
            $table->foreignId('payment_method_id')->constrained('payment_methods');
            $table->foreignId('client_id')->constrained('clients');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('disbursements');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('client_ip_addresses', function (Blueprint $table) {
            $table->id();
            $table->ipAddress('value');
            $table->foreignId('client_id')->constrained('clients');
            $table->timestamps();

            $table->unique(['value', 'client_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('client_ip_addresses');
    }
};

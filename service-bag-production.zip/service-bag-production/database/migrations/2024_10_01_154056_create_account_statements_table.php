<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('account_statements', function (Blueprint $table) {
            $table->id();
            $table->string('status', 20);
            $table->string('reference_no', 100);
            $table->string('type', 100);
            $table->decimal('start_balance', 20);
            $table->decimal('amount', 20);
            $table->char('currency', 3);
            $table->string('remark');
            $table->timestamp('transaction_date');
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('account_statements');
    }
};

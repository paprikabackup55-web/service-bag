<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('virtual_account_payments', function (Blueprint $table) {
            $table->string('reference_no', 32)->nullable()->change();
            $table->string('channel_code', 6)->nullable()->change();
            $table->string('source_bank_code', 5)->nullable()->change();
            $table->string('source_account_no', 35)->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::table('virtual_account_payments', function (Blueprint $table) {
            $table->char('reference_no', 20)->nullable()->unique();
            $table->char('channel_code', 4)->nullable();
            $table->char('source_bank_code', 3)->nullable()->change();
            $table->char('source_account_no', 32)->nullable()->change();
        });
    }
};
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('virtual_accounts', function (Blueprint $table) {
            $table->id();
            $table->string('no', 28);
            $table->string('name', 100);
            $table->char('type',1)->comment('O: Open C: Closed');
            $table->boolean('is_active')->default(true);
            $table->string('partner_service_id', 8);
            $table->string('customer_no', 20);
            $table->string('trx_id', 64);
            $table->foreignId('client_id')->constrained('clients');
            $table->softDeletes();
            $table->timestamps();
            $table->unique(['no', 'deleted_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('virtual_accounts');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('api_services', function (Blueprint $table) {
            $table->id();
            $table->string('name', 100);
            $table->char('code', 2)->default('00');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('api_services');
    }
};

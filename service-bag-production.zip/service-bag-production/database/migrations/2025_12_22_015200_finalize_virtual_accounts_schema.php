<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // 1. ADD NEW COLUMNS
        Schema::table('virtual_accounts', function (Blueprint $table) {
            if (! Schema::hasColumn('virtual_accounts', 'amount')) {
                $table->decimal('amount', 20, 2)->default(0)->after('trx_id');
            }

            if (! Schema::hasColumn('virtual_accounts', 'currency')) {
                $table->char('currency', 3)->default('IDR')->after('amount');
            }

            if (! Schema::hasColumn('virtual_accounts', 'expires_at')) {
                $table->timestamp('expires_at')->default(DB::raw("now() + INTERVAL '1 day'"))->after('currency');
            }

            if (! Schema::hasColumn('virtual_accounts', 'status')) {
                $table->string('status', 10)
                    ->default('INITIATED')
                    ->comment('INITIATED, PAID, CANCELED, EXPIRED')
                    ->after('expires_at');
            }

            // Index VA number
            $table->index('no');
        });

        // Drop unique(no, deleted_at)
        Schema::table('virtual_accounts', function (Blueprint $table) {
            try {
                $table->dropUnique(['no', 'deleted_at']);
            } catch (\Throwable) {
                // ignore if already dropped
            }
        });

        // Drop legacy lifecycle columns
        Schema::table('virtual_accounts', function (Blueprint $table) {
            if (Schema::hasColumn('virtual_accounts', 'is_active')) {
                $table->dropColumn('is_active');
            }

            if (Schema::hasColumn('virtual_accounts', 'deleted_at')) {
                $table->dropColumn('deleted_at');
            }
        });

        // 4. ENFORCE FINAL CONSTRAINTS

        Schema::table('virtual_accounts', function (Blueprint $table) {
            $table->timestamp('expires_at')->nullable(false)->change();
            $table->string('status', 10)->nullable(false)->change();
        });

        // 5. CLEANUP virtual_account_payments
        Schema::table('virtual_account_payments', function (Blueprint $table) {
            foreach (['expires_at', 'paid_at'] as $column) {
                if (Schema::hasColumn('virtual_account_payments', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }

    public function down(): void
    {
        // 1. REVERT FINAL CONSTRAINTS
        Schema::table('virtual_accounts', function (Blueprint $table) {
            $table->boolean('is_active')->default(true);
            $table->softDeletes();
            $table->unique(['no', 'deleted_at']);
            $table->dropIndex(['no']);
        });

        Schema::table('virtual_accounts', function (Blueprint $table) {
            $table->timestamp('expires_at')->nullable()->change();
            $table->string('status', 10)->nullable()->change();
            $table->decimal('amount', 20, 2)->nullable()->change();
            $table->char('currency', 3)->nullable()->change();
        });
    }
};

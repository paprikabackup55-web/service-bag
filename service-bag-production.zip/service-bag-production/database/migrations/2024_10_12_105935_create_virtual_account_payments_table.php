<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('virtual_account_payments', function (Blueprint $table) {
            $table->id();
            $table->char('reference_no', 20)->nullable()->unique();
            $table->string('payment_reference_no', 64)->nullable();
            $table->decimal('amount', 20);
            $table->char('currency', 3);
            $table->char('status_code', 2)->nullable()->comment('Enum PaymentStatus');
            $table->char('channel_code', 4)->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamp('notified_at')->nullable();
            $table->timestamp('callback_received_at')->nullable();
            $table->tinyInteger('callback_retry_count')->default(0);
            $table->string('merchant_id', 10)->nullable()->comment('merchant identifier from bag');
            $table->string('order_id', 32)->nullable();
            $table->string('description', 100)->nullable()->comment('description from notification');
            $table->char('source_bank_code', 3)->nullable();
            $table->char('source_account_no', 32)->nullable();
            $table->string('source_account_name', 100)->nullable();
            $table->foreignId('virtual_account_id')->constrained('virtual_accounts');
            $table->foreignId('inquiry_id')->nullable()->unique()->constrained('virtual_account_inquiries');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('virtual_account_payments');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('request_logs', function (Blueprint $table) {
            $table->id();
            $table->string('ip_addresses');
            $table->text('request_headers');
            $table->text('request_payload');
            $table->smallInteger('response_status')->nullable();
            $table->text('response_body')->nullable();
            $table->integer('duration')->nullable()->comment('ms');
            $table->integer('memory')->nullable()->comment('MB');
            $table->foreignId('api_service_id')->constrained('api_services');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('request_logs');
    }
};

<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class ClientIpAddressFactory extends Factory
{
    public function definition(): array
    {
        return [
            'value' => fake()->ipv4()
        ];
    }
}

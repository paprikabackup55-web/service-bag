<?php

namespace Database\Factories;

use App\Helpers\SecurityHelper;
use Illuminate\Database\Eloquent\Factories\Factory;

class ClientFactory extends Factory
{
    public function definition(): array
    {
        $key = SecurityHelper::generateAsymmetricKey();

        return [
            'name'                => fake()->company(),
            'api_key'             => (string) str()->uuid(),
            'client_api_key'      => null,
            'private_key'         => $key['private'],
            'public_key'          => null,
            'base_url'            => 'https://example.com',
            'va_payment_endpoint' => '/api/v1/virtual-accounts/payment',
        ];
    }
}

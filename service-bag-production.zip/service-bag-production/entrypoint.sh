#!/bin/sh
set -e

# kalau arg pertama option, default ke php-fpm
if [ "${1#-}" != "$1" ]; then
  set -- php-fpm "$@"
fi

# Pastikan public/storage -> storage/app/public (idempotent, aman utk EFS)
cd /var/www/service-bag || exit 1
if [ -L public/storage ]; then
  rm -f public/storage || true
elif [ -d public/storage ]; then
  mv public/storage "public/storage.bak.$(date +%s)" || true
fi
[ -e public/storage ] || ln -s storage/app/public public/storage || true

# Build caches (jangan bikin container exit kalau gagal)
php /var/www/service-bag/artisan storage:link || true
php /var/www/service-bag/artisan app:clear-caches || true
php /var/www/service-bag/artisan route:clear || true
php /var/www/service-bag/artisan config:clear || true
php /var/www/service-bag/artisan event:clear  || true
php /var/www/service-bag/artisan view:clear || true
php /var/www/service-bag/artisan config:cache || true
php /var/www/service-bag/artisan route:cache  || true
php /var/www/service-bag/artisan event:cache  || true
php /var/www/service-bag/artisan view:cache   || true

exec "$@"

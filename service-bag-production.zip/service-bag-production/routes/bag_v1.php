<?php

use App\Http\Controllers\Bag\V1\AccessTokenController;
use App\Http\Controllers\Bag\V1\VirtualAccountController;
use App\Models\ApiService;
use Illuminate\Support\Facades\Route;

Route::controller(AccessTokenController::class)
    ->prefix('access-token')
    ->group(function () {
        Route::post('b2b', 'generate')
            ->withoutMiddleware('verify.bag')
            ->middleware('api.service:'.ApiService::ACCESS_TOKEN);
    });

Route::controller(VirtualAccountController::class)
    ->prefix('transfer-va')
    ->group(function () {
        Route::post('inquiry', 'inquiry')->middleware('api.service:'.ApiService::VIRTUAL_ACCOUNT_INQUIRY);
        Route::post('payment', 'payment')->middleware('api.service:'.ApiService::VIRTUAL_ACCOUNT_PAYMENT);
        Route::post('notification', 'paymentNotification')->middleware('api.service:'.ApiService::VIRTUAL_ACCOUNT_NOTIFICATION);
    });

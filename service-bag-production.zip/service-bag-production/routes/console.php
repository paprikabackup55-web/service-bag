<?php

use App\Console\Commands\LogDailyAccountStatement;
use Illuminate\Support\Facades\Schedule;

// Schedule::command(LogDailyAccountStatement::class)
//     ->everyFiveMinutes()
//     ->between('07:00', '12:00')
//     ->withoutOverlapping(10)
//     ->runInBackground();
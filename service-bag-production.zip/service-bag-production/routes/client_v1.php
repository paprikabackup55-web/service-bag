<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Client\V1\AccountController;
use App\Http\Controllers\Client\V1\DisbursementController;
use App\Http\Controllers\Client\V1\VirtualAccountController;
use App\Models\ApiService;

Route::controller(AccountController::class)
    ->prefix('accounts')
    ->group(function () {
        Route::get('balance/{responseType}', 'getBalance')
            ->middleware('api.service:'.ApiService::ACCOUNT_BALANCE)
            ->where('responseType', 'raw|simple');
        Route::get('statement', 'getStatement')->middleware('api.service:'.ApiService::ACCOUNT_STATEMENT);
    });

Route::controller(DisbursementController::class)
    ->prefix('disbursements')
    ->group(function () {
        Route::post('inquiry', 'inquiryAccount')->middleware('api.service:'.ApiService::DISBURSEMENT_INQUIRY_ACCOUNT);
        Route::post('transfer', 'transfer')->middleware('api.service:'.ApiService::DISBURSEMENT_TRANSFER);
        Route::get('status', 'inquiryStatus')->middleware('api.service:'.ApiService::DISBURSEMENT_INQUIRY_STATUS);
    });

Route::controller(VirtualAccountController::class)
    ->prefix('virtual-accounts')
    ->group(function () {
        Route::post('create', 'create')->middleware('api.service:'.ApiService::VIRTUAL_ACCOUNT_CREATE);
        Route::put('update', 'update')->middleware('api.service:'.ApiService::VIRTUAL_ACCOUNT_UPDATE);
        Route::delete('delete', 'delete')->middleware('api.service:'.ApiService::VIRTUAL_ACCOUNT_DELETE);
    });

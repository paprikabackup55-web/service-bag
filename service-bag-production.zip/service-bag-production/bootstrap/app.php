<?php

use App\Enums\LogLevel;
use App\Enums\ResponseCode;
use App\Enums\ResponseCodeSnap;
use App\Helpers\LogHelper;
use App\Helpers\ResponseHelper;
use App\Http\Middleware\LogRequest;
use App\Http\Middleware\SetApiService;
use App\Http\Middleware\VerifyBagRequest;
use App\Http\Middleware\VerifyClientRequest;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Foundation\Http\Middleware\ConvertEmptyStringsToNull;
use Illuminate\Foundation\Http\Middleware\TrimStrings;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        commands: __DIR__.'/../routes/console.php',
        using: function () {
            Route::prefix('snap/api/v1.0')
                ->middleware(['api', 'log.request', 'verify.bag'])
                ->group(base_path('routes/bag_v1.php'));

            Route::prefix('api/v1')
                ->middleware(['api', 'log.request', 'verify.client'])
                ->group(base_path('routes/client_v1.php'));
        }
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->remove([
            ConvertEmptyStringsToNull::class,
            TrimStrings::class,
        ]);

        $middleware->alias([
            'api.service'   => SetApiService::class,
            'log.request'   => LogRequest::class,
            'verify.client' => VerifyClientRequest::class,
            'verify.bag'    => VerifyBagRequest::class,
        ]);

        $middleware->priority([
            SetApiService::class,
            LogRequest::class,
            VerifyClientRequest::class,
            VerifyBagRequest::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        $exceptions->report(function (Throwable $e) {
            LogHelper::create(LogLevel::Error, 'Global Exception Handler', $e);
        });

        $exceptions->render(function (AuthenticationException $e) {
            return ResponseHelper::generate(ResponseCode::Unauthorized);
        });

        $exceptions->render(function (AccessDeniedHttpException $e) {
            return ResponseHelper::generate(ResponseCode::Forbidden);
        });

        $exceptions->render(function (NotFoundHttpException $e, Request $request) {
            return $request->expectsJson() ? ResponseHelper::generate(ResponseCode::NotFound) : false;
        });

        $exceptions->render(function (MethodNotAllowedHttpException $e, Request $request) {
            return $request->expectsJson() ? ResponseHelper::generate(ResponseCode::MethodNotAllowed) : false;
        });

        $exceptions->render(function (ValidationException $e) {
            $field = $e->validator->errors()->keys()[0];
            $responseCode = ResponseCodeSnap::InvalidFieldFormat;
            $message = null;
            if (array_key_exists('Required', array_values($e->validator->failed())[0])) {
                $responseCode = ResponseCodeSnap::InvalidMandatoryField;
                $message = 'Missing Mandatory Field';
            }

            return ResponseHelper::generate($responseCode, message: $message, context: "{{$field}}");
        });

        $exceptions->render(function (Throwable $e) {
            return ResponseHelper::generate(ResponseCode::GeneralError);
        });
    })->create();

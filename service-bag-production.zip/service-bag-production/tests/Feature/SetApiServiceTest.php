<?php

use App\Http\Middleware\SetApiService;
use App\Models\ApiService;
use Illuminate\Http\Request;

it('should add the api_service_id and api_service_code to request attributes if valid api service exists', function () {
    $id = 12;
    $apiService = ApiService::select(['id', 'code'])->find($id);
    $middleware = new SetApiService();

    $request = Request::create('/api/test', 'GET');
    $next = fn ($request) => response('move to next');
    $response = $middleware->handle($request, $next, $id);

    expect($request->attributes->get('api_service_id'))->toBe($id);
    expect($request->attributes->get('api_service_code'))->toBe($apiService->code);
    expect($response->getStatusCode())->toBe(200);
    expect($response->getContent())->toBe('move to next');
});

it('should throw an exception if api service does not exist', function () {
    $id = -1;
    $apiService = ApiService::find($id);
    $middleware = new SetApiService();

    $request = Request::create('/api/test', 'GET');
    $next = fn ($request) => response('test');

    expect($apiService)->toBeNull();
    expect(fn () => $middleware->handle($request, $next, $id))->toThrow(Exception::class, 'Invalid API service');
});

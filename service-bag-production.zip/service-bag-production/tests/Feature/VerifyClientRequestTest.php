<?php

use App\Enums\ResponseCode;
use App\Helpers\ResponseHelper;
use App\Helpers\SecurityHelper;
use App\Http\Middleware\VerifyClientRequest;
use App\Models\Client;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

/** Setup */
beforeEach(function () {
    // Mock the Cache::rememberForever method to bypass caching
    Cache::shouldReceive('tags')
        ->with('remember-forever')
        ->andReturnSelf();

    Cache::shouldReceive('rememberForever')
        ->andReturnUsing(fn($key, $callback) => $callback());
});

/** Datasets */
dataset('missingHeaders', [
    'X-API-KEY',
    'X-TIMESTAMP',
    'X-SIGNATURE',
]);

dataset('nonUuidStrings', [
    'your-api-key',
    'dff90c70-d478-4197-969a',
    'dff90c70-d478-6094dc8a6052',
    'd478-4197-969a-6094dc8a6052',
    'dff90c70-d478-4197-969a-6094dc8a6052-c',
]);

dataset('timestampDifferencesInSeconds', [
    301,
    -301,
]);

/** Helpers */
function createClientRequest(
    string $url = '/some-endpoint',
    string $method = 'GET',
    ?string $ip = null,
    array $headers = [],
    array $body = []
): Request {
    $request = Request::create($url, $method);

    if ($ip) {
        $request->server->set('REMOTE_ADDR', $ip);
    }

    foreach ($headers as $key => $value) {
        $request->headers->set($key, $value);
    }

    $request->request->add($body);

    return $request;
}

function handleVerifyClientRequest(Request $request)
{
    $middleware = new VerifyClientRequest;
    $next = fn() => response('move to next');

    return $middleware->handle($request, $next);
}

function assertVerifyClientResponse($response, JsonResponse $expectedResponse)
{
    expect($response->getStatusCode())->toBe($expectedResponse->getStatusCode());
    expect($response->getContent())->toBe($expectedResponse->getContent());
}

/** Test Cases */
it('rejects requests without required headers', function (string $missingKey) {
    // Given
    $headers = [
        'X-API-KEY' => 'your-api-key',
        'X-TIMESTAMP' => '2024-11-21T10:00:00Z',
        'X-SIGNATURE' => 'a-signature',
    ];
    unset($headers[$missingKey]);
    $request = createClientRequest(
        url: '/some-endpoint',
        headers: $headers
    );

    // When
    $response = handleVerifyClientRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCode::Unauthorized,
        "Unauthorized. Missing header {$missingKey}"
    );
    assertVerifyClientResponse($response, $expectedResponse);
})->with('missingHeaders');

it('rejects requests without required header values', function (string $missingKey) {
    // Given
    $headers = [
        'X-API-KEY' => 'your-api-key',
        'X-TIMESTAMP' => '2024-11-21T10:00:00Z',
        'X-SIGNATURE' => 'a-signature',
    ];
    $headers[$missingKey] = '';
    $request = createClientRequest(
        url: '/some-endpoint',
        headers: $headers
    );

    // When
    $response = handleVerifyClientRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCode::Unauthorized,
        "Unauthorized. Missing header {$missingKey}"
    );
    assertVerifyClientResponse($response, $expectedResponse);
})->with('missingHeaders');

it('rejects requests with non-uuid apiKey ', function (string $nonUuidString) {
    // Given
    $request = createClientRequest(
        url: '/some-endpoint',
        headers: [
            'X-API-KEY' => $nonUuidString,
            'X-TIMESTAMP' => '2024-11-21T10:00:00Z',
            'X-SIGNATURE' => 'a-signature',
        ]
    );

    // When
    $response = handleVerifyClientRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Unknown client');
    assertVerifyClientResponse($response, $expectedResponse);
})->with('nonUuidStrings');

it('rejects requests with unknown client (unregistered client/api_key)', function () {
    // Given
    do {
        $unknownApiKey = str()->uuid();
    } while (DB::table('clients')->where('api_key', $unknownApiKey)->exists());
    $request = createClientRequest(
        url: '/some-endpoint',
        headers: [
            'X-API-KEY' => $unknownApiKey,
            'X-TIMESTAMP' => '2024-11-21T10:00:00Z',
            'X-SIGNATURE' => 'a-signature',
        ]
    );

    // When
    $response = handleVerifyClientRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Unknown client');
    assertVerifyClientResponse($response, $expectedResponse);
});

it('rejects requests with inactive client', function () {
    // Given
    $inactiveClient = Client::where('is_active', false)->first();
    $request = createClientRequest(
        url: '/some-endpoint',
        headers: [
            'X-API-KEY' => $inactiveClient->api_key,
            'X-TIMESTAMP' => '2024-11-21T10:00:00Z',
            'X-SIGNATURE' => 'a-signature',
        ]
    );

    // When
    $response = handleVerifyClientRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Suspended');
    assertVerifyClientResponse($response, $expectedResponse);
});

it('rejects requests with invalid X-TIMESTAMP value', function (int $timestampDifference) {
    // Given
    $activeClient = Client::where('is_active', true)->first();
    $invalidTimestamp = now()->addSeconds($timestampDifference)->format('c');
    $request = createClientRequest(
        url: '/some-endpoint',
        headers: [
            'X-API-KEY' => $activeClient->api_key,
            'X-TIMESTAMP' => $invalidTimestamp,
            'X-SIGNATURE' => 'a-signature',
        ]
    );

    // When
    $response = handleVerifyClientRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Invalid timestamp');
    assertVerifyClientResponse($response, $expectedResponse);
})->with('timestampDifferencesInSeconds');

it('rejects requests with valid client but invalid ip address', function () {
    // Given
    $activeClient = Client::where('is_active', true)->whereHas('ipAddresses')->first();
    $ipAddresses = $activeClient->ipAddresses()->get()->pluck('value');
    do {
        $invalidIp = fake()->ipv4();
    } while ($ipAddresses->contains($invalidIp));
    $request = createClientRequest(
        url: '/some-endpoint',
        headers: [
            'X-API-KEY' => $activeClient->api_key,
            'X-TIMESTAMP' => now()->format('c'),
            'X-SIGNATURE' => 'a-signature',
        ],
        ip: $invalidIp
    );

    // When
    $response = handleVerifyClientRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Invalid IP');
    assertVerifyClientResponse($response, $expectedResponse);
});

it('rejects requests with invalid X-SIGNATURE due to wrong private key', function () {
    // Given
    $activeClient = Client::where('is_active', true)->whereHas('ipAddresses')->first();
    $validApiKey = $activeClient->api_key;
    $validIpAddress = $activeClient->ipAddresses()->get()->pluck('value')[0];
    $validTimestamp = now()->format('c');
    $request = createClientRequest(
        url: '/some-endpoint',
        method: 'POST',
        ip: $validIpAddress,
        headers: [
            'X-API-KEY' => $validApiKey,
            'X-TIMESTAMP' => $validTimestamp,
        ],
        body: [
            'key1' => 'value1',
            'key2' => 'value2',
        ]
    );

    $requestBody = json_encode($request->all(), JSON_UNESCAPED_SLASHES);

    // Generate Invalid X-SIGNATURE
    $invalidPrivateKey = SecurityHelper::generateAsymmetricKey()['private'];
    $invalidSignature = SecurityHelper::generateAsymmetricSignature(
        data: implode(':', [
            $request->getMethod(),
            $request->getPathInfo(),
            hash('sha256', $requestBody),
            $validTimestamp,
        ]),
        privateKey: $invalidPrivateKey
    );
    $request->headers->set('X-SIGNATURE', $invalidSignature);

    // When
    $response = handleVerifyClientRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Invalid signature');
    assertVerifyClientResponse($response, $expectedResponse);
});

it('rejects requests with invalid X-SIGNATURE due to wrong hasing algorithm', function () {
    // Given
    $activeClient = Client::where('is_active', true)->whereHas('ipAddresses')->first();
    $validApiKey = $activeClient->api_key;
    $validIpAddress = $activeClient->ipAddresses()->get()->pluck('value')[0];
    $validTimestamp = now()->format('c');
    $request = createClientRequest(
        url: '/some-endpoint',
        method: 'POST',
        ip: $validIpAddress,
        headers: [
            'X-API-KEY' => $validApiKey,
            'X-TIMESTAMP' => $validTimestamp,
        ],
        body: [
            'key1' => 'value1',
            'key2' => 'value2',
        ]
    );

    $requestBody = json_encode($request->all(), JSON_UNESCAPED_SLASHES);

    // Generate Invalid X-SIGNATURE
    $validPrivateKey = $activeClient->private_key;
    $invalidSignature = SecurityHelper::generateAsymmetricSignature(
        data: implode(':', [
            $request->getMethod(),
            $request->getPathInfo(),
            hash('sha512', $requestBody),
            $validTimestamp,
        ]),
        privateKey: $validPrivateKey
    );
    $request->headers->set('X-SIGNATURE', $invalidSignature);

    // When
    $response = handleVerifyClientRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Invalid signature');
    assertVerifyClientResponse($response, $expectedResponse);
});

it('allows requests with all correct headers', function () {
    // Given
    $activeClient = Client::where('is_active', true)->whereHas('ipAddresses')->first();
    $validApiKey = $activeClient->api_key;
    $validIpAddress = $activeClient->ipAddresses()->get()->pluck('value')[0];
    $validTimestamp = now()->format('c');
    $request = createClientRequest(
        url: '/some-endpoint',
        method: 'POST',
        ip: $validIpAddress,
        headers: [
            'X-API-KEY' => $validApiKey,
            'X-TIMESTAMP' => $validTimestamp,
        ],
        body: [
            'key1' => 'value1',
            'key2' => 'value2',
        ]
    );

    $requestBody = json_encode($request->all(), JSON_UNESCAPED_SLASHES);

    // Generate Valid X-SIGNATURE
    $validPrivateKey = $activeClient->private_key;
    $validSignature = SecurityHelper::generateAsymmetricSignature(
        data: implode(':', [
            $request->getMethod(),
            $request->getPathInfo(),
            hash('sha256', $requestBody),
            $validTimestamp,
        ]),
        privateKey: $validPrivateKey
    );
    $request->headers->set('X-SIGNATURE', $validSignature);

    // When
    $response = handleVerifyClientRequest($request);

    // Then
    expect($request->attributes->get('client')->id)->toBe($activeClient->id);
    expect($response->getStatusCode())->toBe(200);
    expect($response->getContent())->toBe('move to next');
});

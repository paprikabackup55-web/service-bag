<?php

use App\Enums\ResponseCodeSnap;
use App\Helpers\ResponseHelper;
use App\Helpers\SecurityHelper;
use App\Http\Middleware\VerifyBagRequest;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/** Datasets */
dataset('missingHeaders', [
    'X-TIMESTAMP',
    'X-SIGNATURE',
    'CHANNEL-ID',
    'X-PARTNER-ID',
    'X-EXTERNAL-ID',
    'Authorization',
]);

dataset('timestampDifferencesInSeconds', [
    301,
    -301,
]);

/** Helpers */
function defaultBagRequestHeaders()
{
    return [
        'X-TIMESTAMP' => '2024-11-21T10:00:00Z',
        'X-SIGNATURE' => 'a-signature',
        'CHANNEL-ID' => 'channel',
        'X-PARTNER-ID' => 'partner-id',
        'X-EXTERNAL-ID' => 'external-id',
        'Authorization' => 'an-access-token',
    ];
}

function createBagRequest(
    string $url = '/some-endpoint',
    string $method = 'GET',
    ?string $ip = null,
    array $headers = [],
    array $body = []
): Request {
    $request = Request::create($url, $method);

    if ($ip) {
        $request->server->set('REMOTE_ADDR', $ip);
    }

    foreach ($headers as $key => $value) {
        $request->headers->set($key, $value);
    }

    $request->request->add($body);

    return $request;
}

function handleVerifyBagRequest(Request $request)
{
    $middleware = new VerifyBagRequest;
    $next = fn () => response('move to next');

    return $middleware->handle($request, $next);
}

function assertVerifyBagResponse($response, JsonResponse $expectedResponse)
{
    expect($response->getStatusCode())->toBe($expectedResponse->getStatusCode());
    expect($response->getContent())->toBe($expectedResponse->getContent());
}

/** Test Cases */
it('rejects requests without required headers', function (string $missingField) {
    // Given
    $headers = defaultBagRequestHeaders();
    unset($headers[$missingField]);
    $request = createBagRequest(url: '/snap-endpoint', headers: $headers);

    // When
    $response = handleVerifyBagRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCodeSnap::InvalidMandatoryField,
        message: 'Missing Mandatory Field',
        context: "{{$missingField}}"
    );
    assertVerifyBagResponse($response, $expectedResponse);
})->with('missingHeaders');

it('rejects requests with required headers with empty value', function (string $missingField) {
    // Given
    $headers = defaultBagRequestHeaders();
    $headers[$missingField] = '';
    $request = createBagRequest(url: '/some-endpoint', headers: $headers);

    // When
    $response = handleVerifyBagRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCodeSnap::InvalidMandatoryField,
        message: 'Missing Mandatory Field',
        context: "{{$missingField}}"
    );
    assertVerifyBagResponse($response, $expectedResponse);
})->with('missingHeaders');

it('rejects requests with required headers with white spaces value', function (string $missingField) {
    // Given
    $headers = defaultBagRequestHeaders();
    $headers[$missingField] = '   ';
    $request = createBagRequest(url: '/some-endpoint', headers: $headers);

    // When
    $response = handleVerifyBagRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCodeSnap::InvalidMandatoryField,
        message: 'Missing Mandatory Field',
        context: "{{$missingField}}"
    );
    assertVerifyBagResponse($response, $expectedResponse);
})->with('missingHeaders');

it('rejects requests with invalid token for Authorization header, not a JWT Token', function () {
    // Given
    $headers = defaultBagRequestHeaders();
    $headers['Authorization'] = 'some-random-access-token';
    $request = createBagRequest(url: '/some-endpoint', headers: $headers);

    // When
    $response = handleVerifyBagRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCodeSnap::InvalidToken,
        message: 'Access Token Invalid'
    );
    assertVerifyBagResponse($response, $expectedResponse);
});

it('rejects requests with invalid token for Authorization header, incorrect JWT payload', function () {
    // Given
    $clientKey = 'a-random-guess-of-client-key';
    $jwtToken = SecurityHelper::generateJwt($clientKey, 'API', 900);

    $headers = defaultBagRequestHeaders();
    $headers['Authorization'] = 'Bearer '.$jwtToken;
    $request = createBagRequest(url: '/some-endpoint', headers: $headers);

    // When
    $response = handleVerifyBagRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCodeSnap::InvalidToken,
        message: 'Access Token Invalid'
    );
    assertVerifyBagResponse($response, $expectedResponse);
});

it('rejects requests with invalid token for Authorization header, incorrect pertner id', function () {
    // Given
    $clientKey = config('services.bag.snap.outbound.client_id');
    $jwtToken = SecurityHelper::generateJwt($clientKey, 'API', 900);

    $headers = defaultBagRequestHeaders();
    $headers['Authorization'] = 'Bearer '.$jwtToken;
    $headers['X-PARTNER-ID'] = 'a-random-guess-of-partner-id';
    $request = createBagRequest(url: '/some-endpoint', headers: $headers);

    // When
    $response = handleVerifyBagRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCodeSnap::InvalidToken,
        message: 'Access Token Invalid'
    );
    assertVerifyBagResponse($response, $expectedResponse);
});

it('rejects requests with invalid token for Authorization header, expired JWT token', function () {
    // Given
    $tokenExpiredIn = 1;
    $clientKey = config('services.bag.snap.outbound.client_id');
    $jwtToken = SecurityHelper::generateJwt($clientKey, 'API', $tokenExpiredIn);

    $headers = defaultBagRequestHeaders();
    $headers['Authorization'] = 'Bearer '.$jwtToken;
    $headers['X-PARTNER-ID'] = $clientKey;
    $request = createBagRequest(url: '/some-endpoint', headers: $headers);

    // When
    Carbon::sleep(1);
    $response = handleVerifyBagRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCodeSnap::InvalidToken,
        message: 'Access Token Invalid'
    );
    assertVerifyBagResponse($response, $expectedResponse);
});

it('rejects requests with expired X-TIMESTAMP value', function (int $timestampDifference) {
    // Given
    $clientKey = config('services.bag.snap.outbound.client_id');
    $headers = defaultBagRequestHeaders();
    $headers['Authorization'] = 'Bearer '.SecurityHelper::generateJwt($clientKey, 'API', 900);
    $headers['X-PARTNER-ID'] = $clientKey;
    $headers['X-TIMESTAMP'] = now()->addSeconds($timestampDifference)->format('c');

    $request = createBagRequest(url: '/some-endpoint', headers: $headers);

    // When
    $response = handleVerifyBagRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCodeSnap::InvalidFieldFormat,
        context: '{X-TIMESTAMP}'
    );
    assertVerifyBagResponse($response, $expectedResponse);
})->with('timestampDifferencesInSeconds');

it('rejects requests with invalid X-SIGNATURE value, due to invalid secret key', function () {
    // Given
    $clientKey = config('services.bag.snap.outbound.client_id');
    $secretKey = 'a-random-guess-of-secret-key';
    $endpoint = '/some-endpoint';
    $method = 'POST';
    $accessToken = SecurityHelper::generateJwt($clientKey, 'API', 900);
    $timestamp = now()->format('c');
    $body = ['key1' => 'value1', 'key2' => 'value2'];

    // generate x-signature
    $signatue = SecurityHelper::generateSymmetricSignature(
        algo: 'sha512',
        data: implode(':', [
            strtoupper($method),
            $endpoint,
            $accessToken,
            hash('sha256', count($body) === 0 ? '' : json_encode($body, JSON_UNESCAPED_SLASHES)),
            $timestamp,
        ]),
        key: $secretKey
    );

    $headers = defaultBagRequestHeaders();
    $headers['Authorization'] = 'Bearer '.$accessToken;
    $headers['X-PARTNER-ID'] = $clientKey;
    $headers['X-TIMESTAMP'] = $timestamp;
    $headers['X-SIGNATURE'] = $signatue;

    $request = createClientRequest(
        url: $endpoint,
        method: $method,
        headers: $headers,
        body: $body
    );

    // When
    $response = handleVerifyBagRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCodeSnap::Unauthorized,
        context: 'Signature'
    );
    assertVerifyBagResponse($response, $expectedResponse);
});

it('rejects requests with invalid X-SIGNATURE value, due to tampered body', function () {
    // Given
    $clientKey = config('services.bag.snap.outbound.client_id');
    $secretKey = config('services.bag.snap.outbound.client_secret');
    $endpoint = '/some-endpoint';
    $method = 'POST';
    $accessToken = SecurityHelper::generateJwt($clientKey, 'API', 900);
    $timestamp = now()->format('c');
    $body = ['key1' => 'value1', 'key2' => 'value2'];

    // generate x-signature
    $signatue = SecurityHelper::generateSymmetricSignature(
        algo: 'sha512',
        data: implode(':', [
            strtoupper($method),
            $endpoint,
            $accessToken,
            hash('sha256', count($body) === 0 ? '' : json_encode($body, JSON_UNESCAPED_SLASHES)),
            $timestamp,
        ]),
        key: $secretKey
    );

    $headers = defaultBagRequestHeaders();
    $headers['Authorization'] = 'Bearer '.$accessToken;
    $headers['X-PARTNER-ID'] = $clientKey;
    $headers['X-TIMESTAMP'] = $timestamp;
    $headers['X-SIGNATURE'] = $signatue;

    $body['key2'] = 'value3'; //tampering the body after sign
    $request = createClientRequest(
        url: $endpoint,
        method: $method,
        headers: $headers,
        body: $body
    );

    // When
    $response = handleVerifyBagRequest($request);

    // Then
    $expectedResponse = ResponseHelper::generate(
        ResponseCodeSnap::Unauthorized,
        context: 'Signature'
    );
    assertVerifyBagResponse($response, $expectedResponse);
});

it('allows requests with all correct headers', function () {
    // Given
    $clientKey = config('services.bag.snap.outbound.client_id');
    $secretKey = config('services.bag.snap.outbound.client_secret');
    $endpoint = '/some-endpoint';
    $method = 'POST';
    $accessToken = SecurityHelper::generateJwt($clientKey, 'API', 900);
    $timestamp = now()->format('c');
    $body = ['key1' => 'value1', 'key2' => 'value2'];

    // generate x-signature
    $signatue = SecurityHelper::generateSymmetricSignature(
        algo: 'sha512',
        data: implode(':', [
            strtoupper($method),
            $endpoint,
            $accessToken,
            hash('sha256', count($body) === 0 ? '' : json_encode($body, JSON_UNESCAPED_SLASHES)),
            $timestamp,
        ]),
        key: $secretKey
    );

    $headers = defaultBagRequestHeaders();
    $headers['Authorization'] = 'Bearer '.$accessToken;
    $headers['X-PARTNER-ID'] = $clientKey;
    $headers['X-TIMESTAMP'] = $timestamp;
    $headers['X-SIGNATURE'] = $signatue;

    $request = createClientRequest(
        url: $endpoint,
        method: $method,
        headers: $headers,
        body: $body
    );

    // When
    $response = handleVerifyBagRequest($request);

    // Then
    expect($response->getStatusCode())->toBe(200);
    expect($response->getContent())->toBe('move to next');
});

<?php

namespace Tests\Unit;

use App\Helpers\DateHelper;
use Carbon\Carbon;
use Illuminate\Support\Facades\Config;
use InvalidArgumentException;
use Tests\TestCase;

class DateHelperTest extends TestCase
{
    public function test_datetime_with_null_value()
    {
        $result = DateHelper::datetime(null);
        $this->assertNull($result);
    }

    public function test_datetime_with_invalid_value()
    {
        Config::set('app.timezone', 'UTC');
        $this->expectException(InvalidArgumentException::class);

        $invalidDatetime = 'invalid datetime';
        DateHelper::datetime($invalidDatetime);
    }

    public function test_datetime_with_empty_string_value()
    {
        Config::set('app.timezone', 'UTC');
        $expected = Carbon::now()->timezone('UTC')->toDateTimeString();
        $result = DateHelper::datetime('');

        $this->assertEquals($expected, $result);
    }

    public function test_datetime_with_valid_value()
    {
        Config::set('app.timezone', 'Asia/Jakarta');
        $datetime = '2024-04-15 12:00:00';
        $expected = Carbon::parse($datetime)->timezone('Asia/Jakarta')->toDateTimeString();
        $result = DateHelper::datetime($datetime);

        $this->assertEquals($expected, $result);
    }

    public function test_datetime_with_valid_value_but_different_timezone()
    {
        Config::set('app.timezone', 'Europe/London');
        $datetime = '2024-04-15 12:00:00';
        $expected = Carbon::parse($datetime)->timezone('Europe/London')->toDateTimeString();
        $result = DateHelper::datetime($datetime);

        $this->assertEquals($expected, $result);
    }
}

<?php

namespace Tests\Unit;

use App\Helpers\SecurityHelper;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Str;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\TestCase;

class SecurityHelperTest extends TestCase
{
    /**
     * Data provider methods
     */
    public static function ipAddressDataProvider()
    {
        // Create a mock Request with an IP and x-forwarded-for header
        return [
            'data with duplicates' => [
                '192.168.1.1',
                '10.0.0.1, 10.0.0.2, 192.168.1.1',
                ['192.168.1.1', '10.0.0.1', '10.0.0.2'],
            ],
            'data with whitespaces' => [
                '192.168.1.1',
                '  10.0.0.1,  192.168.1.1  , ',
                ['192.168.1.1', '10.0.0.1'],
            ],
            'data with proxy' => [
                '192.168.1.1',
                'fe80::780b:cd:b91:5b6d%6',
                ['192.168.1.1', 'fe80::780b:cd:b91:5b6d%6'],
            ],
            'data with no x-forward-for' => [
                '192.168.1.1',
                '',
                ['192.168.1.1'],
            ],
        ];
    }

    #[DataProvider('ipAddressDataProvider')]
    public function test_get_ip_addresses(
        string $remoteAddress,
        string $xForwardFor,
        array $expectedIpAddresses
    ) {
        $request = Request::create('/some-endpoint', 'GET', []);
        $request->server->set('REMOTE_ADDR', $remoteAddress);
        $request->headers->set('x-forwarded-for', $xForwardFor);

        $actualIpAddresses = SecurityHelper::getIpAddresses($request);

        $this->assertIsArray($actualIpAddresses);
        $this->assertEquals($expectedIpAddresses, $actualIpAddresses);
    }

    public function test_generate_asymmetric_key()
    {
        $keys = SecurityHelper::generateAsymmetricKey();

        $this->assertNotEmpty($keys['private'], 'Private key is empty');
        $this->assertNotEmpty($keys['public'], 'Public key is empty');

        $privateKey = $keys['private'];
        $publicKey = $keys['public'];

        $message = "Hello? (Hello, hello, hello)\nIs there anybody in there?";
        openssl_public_encrypt($message, $encryptedMessage, $publicKey);
        openssl_private_decrypt($encryptedMessage, $decryptedMessage, $privateKey);

        $this->assertEquals($message, $decryptedMessage, 'Decrypted message does not match the original');
    }

    public function test_get_public_key()
    {
        $privateKey = openssl_pkey_new([
            'private_key_bits' => 2048,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
        ]);
        openssl_pkey_export($privateKey, $privateKeyStr);

        $publicKey = SecurityHelper::getPublicKey($privateKeyStr);

        $this->assertNotEmpty($publicKey, 'Public key is empty');

        $data = "Hello? (Hello, hello, hello)\nIs there anybody in there?";
        openssl_public_encrypt($data, $encryptedData, $publicKey);
        openssl_private_decrypt($encryptedData, $decryptedData, $privateKeyStr);
        $this->assertEquals($data, $decryptedData, 'Decrypted data does not match the original data');
    }

    public function test_generate_asymmetric_signature()
    {
        $privateKey = openssl_pkey_new([
            'private_key_bits' => 2048,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
        ]);
        openssl_pkey_export($privateKey, $privateKeyStr);
        $publicKey = openssl_pkey_get_details($privateKey)['key'];
        $data = "Hello? (Hello, hello, hello)\nIs there anybody in there?";

        $signature = SecurityHelper::generateAsymmetricSignature($data, $privateKeyStr);

        $this->assertNotEmpty($signature, 'Signature should not be empty');
        $decodedSignature = base64_decode($signature);
        $isValid = openssl_verify($data, $decodedSignature, $publicKey, OPENSSL_ALGO_SHA256);
        $this->assertEquals(1, $isValid, 'Signature is not valid');
    }

    public function test_verify_asymmetric_signature()
    {
        $privateKey = openssl_pkey_new([
            'private_key_bits' => 2048,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
        ]);
        openssl_pkey_export($privateKey, $privateKeyStr);
        $publicKey = openssl_pkey_get_details($privateKey)['key'];

        $data = 'Test data to sign';
        openssl_sign($data, $signature, $privateKeyStr, OPENSSL_ALGO_SHA256);
        $signature = base64_encode($signature);

        $verificationResult = SecurityHelper::verifyAsymmetricSignature($data, $signature, $publicKey);
        $this->assertEquals(1, $verificationResult, 'Signature verification failed');

        $alteredData = $data . ' ';
        $invalidVerificationResult = SecurityHelper::verifyAsymmetricSignature($alteredData, $signature, $publicKey);
        $this->assertEquals(0, $invalidVerificationResult, 'Signature verification passed with altered data');
    }

    public function test_generate_symmetric_signature()
    {
        $algo = 'sha256';  //hashing algorithm "md5", "sha256", "haval160,4, etc"
        $data = "Hello? (Hello, hello, hello)\nIs there anybody in there?";
        $key = 'secret-key';

        $actualSignature = SecurityHelper::generateSymmetricSignature($algo, $data, $key);
        $expectedSignature = hash_hmac($algo, $data, $key);

        $this->assertEquals($expectedSignature, $actualSignature);
    }

    public function test_verify_symmetric_signature()
    {
        $algo = 'md5';
        $data = "Hello? (Hello, hello, hello)\nIs there anybody in there?";
        $key = 'secret-key';
        $signature = hash_hmac($algo, $data, $key);

        $isValid = SecurityHelper::verifySymmetricSignature($algo, $data, $key, $signature);
        $this->assertTrue($isValid);
    }

    public function test_generate_jwt()
    {
        $subject = 'subject';
        $audience = 'audience';
        $lifetime = 300;
        $jwtKey = Str::random(64);
        Config::set('services.jwt.key', $jwtKey);
        Config::set('app.url', 'https://example.com');

        $token = SecurityHelper::generateJwt($subject, $audience, $lifetime);

        $decoded = JWT::decode($token, new Key($jwtKey, 'HS256'));
        $this->assertEquals($subject, $decoded->sub);
        $this->assertEquals($audience, $decoded->aud);
        $this->assertEquals(config('app.url'), $decoded->iss);
        $this->assertGreaterThanOrEqual(time(), $decoded->iat);
        $this->assertLessThanOrEqual(time() + $lifetime, $decoded->exp);
        $this->assertTrue(Str::isUuid($decoded->jti));
    }

    public function test_verify_jwt()
    {
        $lifetime = 300;
        $jwtKey = Str::random(64);
        Config::set('services.jwt.key', $jwtKey);
        Config::set('app.url', 'https://example.com');
        $now = now();

        $payload = [
            'iss' => config('app.url'),
            'sub' => 'test-subject',
            'aud' => 'test-audience',
            'exp' => $now->clone()->addSeconds($lifetime)->timestamp,
            'nbf' => $now->timestamp,
            'iat' => $now->timestamp,
            'jti' => (string) Str::uuid()
        ];

        $jwtToken = JWT::encode($payload, config('services.jwt.key'), 'HS256');

        $decoded = SecurityHelper::verifyJwt($jwtToken);
        $this->assertEquals($payload['sub'], $decoded->sub);
        $this->assertEquals($payload['aud'], $decoded->aud);
        $this->assertEquals($payload['iss'], $decoded->iss);
        $this->assertEquals($payload['jti'], $decoded->jti);
        $this->assertGreaterThanOrEqual(time(), $decoded->iat);
        $this->assertGreaterThanOrEqual(time(), $decoded->nbf);
        $this->assertLessThanOrEqual(time() + $lifetime, $decoded->exp);
    }
}

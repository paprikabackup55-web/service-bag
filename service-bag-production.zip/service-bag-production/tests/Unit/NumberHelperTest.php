<?php

namespace Tests\Unit;

use App\Helpers\NumberHelper;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

class NumberHelperTest extends TestCase
{
    /**
     * Data provider methods
     */
    public static function randomNumberDataProvider1()
    {
        return [
            'digit 1' => [1],
            'digit 10' => [10],
            'digit 20' => [20],
        ];
    }

    public static function randomNumberDataProvider2()
    {
        return [
            'digit 0' => [0],
            'digit negative' => [-7],
            'digit negative' => [-13],
        ];
    }

    public static function decimalDataProvider()
    {
        return [
            'large negative int -1203953245' => [-1203953245, '-1203953245.00'],
            'small negative int -120' => [-120, '-120.00'],
            'zero' => [0, '0.00'],
            'small positive int 120' => [120, '120.00'],
            'large positive int 1203953245' => [1203953245, '1203953245.00'],
            'large negative float -1203953245.5267' => [-1203953245.5267, '-1203953245.53'],
            'large negative float -1203953245.5257' => [-1203953245.5257, '-1203953245.53'],
            'large negative float -1203953245.5247' => [-1203953245.5247, '-1203953245.52'],
            'small negative float -120.12785' => [-120.12785, '-120.13'],
            'small negative float -120.12585' => [-120.12585, '-120.13'],
            'small negative float -120.12085' => [-120.12085, '-120.12'],
            'small positive float 120.009' => [120.009, '120.01'],
            'small positive float 120.005' => [120.005, '120.01'],
            'small positive float 120.002' => [120.002, '120.00'],
            'large positive float 1203953245.5267' => [1203953245.5267, '1203953245.53'],
            'large positive float 1203953245.5257' => [1203953245.5257, '1203953245.53'],
            'large positive float 1203953245.5247' => [1203953245.5247, '1203953245.52'],
        ];
    }

    public static function decimalDataProviderWithRounding()
    {
        return [
            'rounding 1195.5267' => [1195.5267, '1195.53'],
            'large positive float 1195.5967' => [1195.5967, '1195.60'],
            'large positive float 1195.9967' => [1195.9967, '1196.00'],
        ];
    }

    #[DataProvider('randomNumberDataProvider1')]
    public function test_number_function_return_string_of_numbers_with_correct_length($lenght): void
    {
        $generatedRandomNumber = NumberHelper::random($lenght);

        $this->assertIsString($generatedRandomNumber);
        $this->assertEquals($lenght, strlen($generatedRandomNumber));
        $this->assertMatchesRegularExpression('/^\d+$/', $generatedRandomNumber);
    }

    #[DataProvider('randomNumberDataProvider2')]
    public function test_number_function_return_empty_string_for_non_positive_input(int $lenght): void
    {
        $generatedRandomNumber = NumberHelper::random($lenght);

        $this->assertIsString($generatedRandomNumber);
        $this->assertEquals('', $generatedRandomNumber);
    }

    #[DataProvider('decimalDataProvider'), DataProvider('decimalDataProviderWithRounding')]
    public function test_decimal_function_return_string_of_numbers_with_correct_format(
        int|float $value,
        string $expectedValue
    ): void {
        $formattedValue = NumberHelper::decimal($value);
        $this->assertIsString($formattedValue);
        $this->assertEquals($expectedValue, $formattedValue);
        $this->assertMatchesRegularExpression('/^-?\d+(\.\d{2})?$/', $formattedValue);
    }
}

<?php

namespace App\Traits;

trait HasValues
{
    /**
     * Get an array of enum values (backed values for backed enums, names for non-backed).
     *
     * @return array
     */
    public static function values(): array
    {
        $cases = self::cases();
        return $cases ? array_column($cases, property_exists($cases[0], 'value') ? 'value' : 'name') : [];
    }

    /**
     * Get an associative array of enum case names and their values.
     *
     * @return array
     */
    public static function toArray(): array
    {
        $cases = self::cases();
        return $cases ? array_combine(
            array_column($cases, 'name'),
            array_column($cases, property_exists($cases[0], 'value') ? 'value' : 'name')
        ) : [];
    }
}

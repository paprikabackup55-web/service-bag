<?php

namespace App\Enums;

use App\Traits\HasValues;

enum DisbursementStatus: string
{
    use HasValues;
    
    case Success   = '00';
    case Initiated = '01';
    case Paying    = '02';
    case Pending   = '03';
    case Refunded  = '04';
    case Canceled  = '05';
    case Failed    = '06';
    case NotFound  = '07';

    public function getCode(): string
    {
        return $this->value;
    }

    public function getDesc(): string
    {
        return match ($this) {
            default  => str()->headline($this->name)
        };
    }
}

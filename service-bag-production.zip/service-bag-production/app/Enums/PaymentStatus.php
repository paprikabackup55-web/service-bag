<?php

namespace App\Enums;

use App\Traits\HasValues;

enum PaymentStatus: string
{
    use HasValues;

    case Success   = '00';
    case Failed    = '01';
    case Pending   = '02';

    public function getCode(): string
    {
        return $this->value;
    }

    public function getDesc(): string
    {
        return match ($this) {
            default  => str()->headline($this->name)
        };
    }

    public static function isSuccess(string $statusDesc): bool
    {
        return strcasecmp($statusDesc, PaymentStatus::Success->getDesc()) === 0;
    }
}

<?php

namespace App\Enums;

enum VirtualAccountStatus: string
{
    case INITIATED = 'INITIATED';
    case PAID      = 'PAID';
    case CANCELED  = 'CANCELED';
    case EXPIRED   = 'EXPIRED';

    /**
     * Status yang masih bisa dipakai untuk inquiry/payment
     */
    public static function activeStatuses(): array
    {
        return [
            self::INITIATED->value,
        ];
    }

    /**
     * Status final (terminal)
     */
    public static function finalStatuses(): array
    {
        return [
            self::PAID->value,
            self::CANCELED->value,
            self::EXPIRED->value,
        ];
    }

    /**
     * Semua value (untuk validation)
     */
    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }
}
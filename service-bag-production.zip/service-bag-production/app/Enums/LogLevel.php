<?php

namespace App\Enums;

use App\Traits\HasValues;

enum LogLevel: string
{
    use  HasValues;
    
    case Emergency  = 'emergency';
    case Alert      = 'alert';
    case Critical   = 'critical';
    case Error      = 'error';
    case Warning    = 'warning';
    case Notice     = 'notice';
    case Info       = 'info';
    case Debug      = 'debug';
}

<?php

namespace App\Enums;

enum ResponseCode: string
{
    case Ok                          = '20000';
    case BadRequest                  = '40000';
    case GetBalanceFailed            = '40001';
    case GetStatementFailed          = '40002';
    case InquiryAccountFailed        = '40003';
    case InvalidTransactionStatus    = '40008';
    case VirtualAccountAlreadyExists = '40009';
    case VirtualAccountNotFound      = '40010';
    case Unauthorized                = '40100';
    case GetAccessTokenFailed        = '40101';
    case Forbidden                   = '40300';
    case NotFound                    = '40400';
    case MethodNotAllowed            = '40500';
    case Conflict                    = '40900';
    case DuplicatePartnerReferenceNo = '40901';
    case ValidationError             = '42200';
    case TooManyAttempts             = '42900';
    case GeneralError                = '50000';
    case InternalServerError         = '50001';
    case ExternalServerError         = '50002';

    public function getStatus(): int
    {
        return (int) substr($this->value, 0, 3);
    }

    public function getCode(): string
    {
        return $this->getStatus() . request()->attributes->get('api_service_code', '00') . substr($this->value, 3);
    }

    public function getMessage(): string
    {
        return match ($this) {
            self::Conflict  => 'Request in progress',
            default         => str()->headline($this->name)
        };
    }
}

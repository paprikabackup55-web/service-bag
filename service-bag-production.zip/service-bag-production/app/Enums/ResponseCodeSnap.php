<?php

namespace App\Enums;

enum ResponseCodeSnap: String
{
    case Successful                         = '20000';
    case RequestInProgress                  = '20200';
    case BadRequest                         = '40000';
    case InvalidFieldFormat                 = '40001';
    case InvalidMandatoryField              = '40002';
    case Unauthorized                       = '40100';
    case InvalidToken                       = '40101';
    case InvalidCustomerToken               = '40102';
    case TokenNotFound                      = '40103';
    case CustomerTokenNotFound              = '40104';
    case TransactionExpired                 = '40300';
    case TransactionNotFound                = '40401';
    case InvalidMerchant                    = '40408';
    case InvalidBillOrVirtualAccount        = '40412';
    case InvalidAmount                      = '40413';
    case PaidBill                           = '40414';
    case InvalidBillOrVirtualAccountExpired = '40419';
    case Conflict                           = '40900';
    case DuplicatePartnerReferenceNo        = '40901';
    case GeneralError                       = '50000';
    case InternalServerError                = '50001';
    case ExternalServerError                = '50002';
    case Timeout                            = '50400';

    public function getStatus(): int
    {
        return (int) substr($this->value, 0, 3);
    }

    public function getCode(): string
    {
        return $this->getStatus() . request()->attributes->get('api_service_code', '00') . substr($this->value, 3);
    }

    public function getMessage(): string
    {
        return match ($this) {
            self::InvalidToken                          => 'Invalid Token (B2B)',
            self::TokenNotFound                         => 'Token Not Found (B2B)',
            self::InvalidBillOrVirtualAccount           => 'Invalid Bill/Virtual Account',
            self::PaidBill                              => 'Bill has been paid',
            self::InvalidBillOrVirtualAccountExpired    => 'Virtual account is expired.',
            self::DuplicatePartnerReferenceNo           => 'Duplicate PartnerReferenceNo',
            default => str()->headline($this->name)
        };
    }

    public static function tryFromExtResponse(string $externalCode): ?self
    {
        if (strlen($externalCode) < 5) {
            return null;
        }

        $normalizedCode = substr($externalCode, 0, 3) . substr($externalCode, -2);
        
        return self::tryFrom($normalizedCode);
    }
}

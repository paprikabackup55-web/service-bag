<?php

namespace App\Enums;

use App\Traits\HasValues;

enum VirtualAccountType: string
{
    use HasValues;
    
    case OPEN_PAYMENT   = 'O';
    case CLOSE_PAYMENT  = 'C';
}
<?php

namespace App\Enums;

use App\Traits\HasValues;

enum Currency: string
{
    use HasValues;

    case IDR = 'IDR';
    // case USD = 'USD';
}

<?php

namespace App\Data\AdditionalInfo;

use Spatie\LaravelData\Data;

class PaymentAdditionalInfoData extends Data
{
    /**
     * Create a new class instance.
     */
    public function __construct(
        public string $merchantId,
        public string $channel,
        public string $proCode,
        public ?string $sourceAccountName,
        public ?string $paymentDetails,
    ) {}
}

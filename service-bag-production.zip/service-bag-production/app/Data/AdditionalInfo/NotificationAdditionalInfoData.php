<?php

namespace App\Data\AdditionalInfo;

use Spatie\LaravelData\Data;

class NotificationAdditionalInfoData extends Data
{
    /**
     * Create a new class instance.
     */
    public function __construct(
        public ?string $merchantId,
        public ?string $orderId,
        public ?string $amount,
        public ?string $procode,
        public ?string $flagAmountCheck,
        public ?string $description,
        public ?string $destinationVAName,
        public ?string $sourceBankCode,
        public ?string $sourceName,
        public ?string $sourceAccount,
    ) {}
}

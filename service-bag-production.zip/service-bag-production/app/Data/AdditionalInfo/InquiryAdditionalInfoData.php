<?php

namespace App\Data\AdditionalInfo;

use Spatie\LaravelData\Data;

class InquiryAdditionalInfoData extends Data
{
    /**
     * Create a new class instance.
     */
    public function __construct(
        public string $merchantId,
        public string $proCode,
        public ?string $channel,
        public ?string $senderName,
        public ?string $flagAmountCheck,
        public ?string $referenceNo,
    ) {}
}

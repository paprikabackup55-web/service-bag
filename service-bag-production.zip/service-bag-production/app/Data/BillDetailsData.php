<?php

namespace App\Data;

use Spatie\LaravelData\Data;

class BillDetailsData extends Data
{
    /**
     * Create a new class instance.
     */
    public function __construct(
        public ?string $billCode,
        public ?string $billNo,
        public ?string $billName,
        public ?string $billShortName,
        public ?FreeTextsData $billDescription,
        public ?string $billSubCompany,
        public ?AmountData $billAmount,
        public ?string $billReferenceNo,
        // public ?AdditionalInfoData $additionalInfo,
    ) {}
}

<?php

namespace App\Data;

use App\Data\AdditionalInfo\NotificationAdditionalInfoData;
use Spatie\LaravelData\Data;

class NotificationVaData extends Data
{
    /**
     * Create a new class instance.
     */
    public function __construct(
        public string $partnerServiceId,
        public string $customerNo,
        public string $virtualAccountNo,
        public ?string $inquiryRequestId,
        public ?string $paymentRequestId,
        public ?string $partnerReferenceNo,
        public ?string $trxDateTime,
        public ?string $paymentStatus = '', // Success; Fail
        public ?FreeTextsData $paymentFlagReason,
        public ?NotificationAdditionalInfoData $additionalInfo,
    ) {}
}

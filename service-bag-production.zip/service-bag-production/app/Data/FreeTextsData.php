<?php

namespace App\Data;

use Spatie\LaravelData\Data;

class FreeTextsData extends Data
{
    /**
     * Create a new class instance.
     */
    public function __construct(
        public ?string $english,
        public ?string $indonesia,
    ) {}
}

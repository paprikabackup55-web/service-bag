<?php

namespace App\Data;

use Spatie\LaravelData\Data;

class AmountData extends Data
{
    /**
     * Create a new class instance.
     */
    public function __construct(
        public string $value,
        public string $currency
    ) {}
}

<?php

namespace App\Data;

use App\Data\AdditionalInfo\PaymentAdditionalInfoData;
use Spatie\LaravelData\Data;

class PaymentVaData extends Data
{
    /**
     * Create a new class instance.
     */
    public function __construct(
        public string $partnerServiceId,
        public string $customerNo,
        public string $virtualAccountNo,
        public string $paymentRequestId,
        public AmountData $paidAmount,
        public string $referenceNo,
        public ?string $virtualAccountName,
        public ?string $virtualAccountEmail,
        public ?string $virtualAccountPhone,
        public ?string $trxId,
        public ?string $channelCode,
        public ?string $sourceAccountNo,
        public ?string $sourceBankCode,
        public ?AmountData $cumulativePaymentAmount,
        public ?AmountData $totalAmount,
        public ?string $trxDateTime,
        public ?string $journalNum,
        public ?string $paymentType,
        public ?string $flagAdvise,
        public ?string $subCompany,
        public ?BillDetailsData $billDetails,
        public ?FreeTextsData $freeTexts,
        public ?PaymentAdditionalInfoData $additionalInfo,
    ) {}

    public static function fromInquiryVaDto(InquiryVaData $dto): self
    {
        return new self(
            partnerServiceId       : $dto->partnerServiceId,
            customerNo             : $dto->customerNo,
            virtualAccountNo       : $dto->virtualAccountNo,
            paymentRequestId       : $dto->inquiryRequestId,
            paidAmount             : $dto->amount,
            referenceNo            : $dto->additionalInfo->referenceNo,
            virtualAccountName     : null,
            virtualAccountEmail    : null,
            virtualAccountPhone    : null,
            trxId                  : null,
            channelCode            : $dto->channelCode,
            sourceAccountNo        : $dto->sourceAccountNo,
            sourceBankCode         : $dto->sourceBankCode,
            cumulativePaymentAmount: null,
            totalAmount            : $dto->amount,
            trxDateTime            : $dto->txnDateInit,
            journalNum             : null,
            paymentType            : null,
            flagAdvise             : null,
            subCompany             : null,
            billDetails            : null,
            freeTexts              : null,
            additionalInfo         : new PaymentAdditionalInfoData(
                merchantId       : $dto->additionalInfo->merchantId,
                channel          : $dto->additionalInfo->channel,
                proCode          : $dto->additionalInfo->proCode,
                sourceAccountName: $dto->additionalInfo->senderName,
                paymentDetails   : null,
            )
        );
    }
}

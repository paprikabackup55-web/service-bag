<?php

namespace App\Data;

use App\Data\AdditionalInfo\InquiryAdditionalInfoData;
use Spatie\LaravelData\Data;

class InquiryVaData extends Data
{
    public function __construct(
        public string $partnerServiceId,
        public string $inquiryRequestId,
        public string $customerNo,
        public string $virtualAccountNo,
        public string $txnDateInit,
        public ?string $language,
        public ?AmountData $amount,
        public ?string $channelCode,
        public ?string $sourceAccountNo,
        public ?string $sourceBankCode,
        public ?string $passApp,
        public ?InquiryAdditionalInfoData $additionalInfo,
    ) {}
}

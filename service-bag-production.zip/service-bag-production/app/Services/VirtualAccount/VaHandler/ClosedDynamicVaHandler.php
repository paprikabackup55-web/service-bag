<?php

namespace App\Services\VirtualAccount\VaHandler;

use Carbon\Carbon;
use App\Helpers\NumberHelper;
use App\Models\VirtualAccount;
use App\Helpers\BagConfigHelper;
use App\Enums\VirtualAccountStatus;
use App\Http\Requests\Client\V1\VirtualAccount\CreateRequest;
use App\Exceptions\VirtualAccount\InvalidExpirationDateException;

class ClosedDynamicVaHandler implements VirtualAccountHandler
{
    public function createVa(int $clientId, array $vaData): VirtualAccount
    {
        if (Carbon::createFromFormat(CreateRequest::EXP_DATE_FORMAT, $vaData['expiration'])->isPast()) {
            throw new InvalidExpirationDateException;
        }

        $partnerServiceId = trim($vaData['partnerServiceId']);
        $prefix = BagConfigHelper::va()['prefix_closed'] . $partnerServiceId;
        $vaLength = (int) BagConfigHelper::va()['length'];
        $suffixLength = $vaLength - strlen($prefix);

        do {
            // TODO: Optimize
            $vaNumber = $prefix . NumberHelper::random($suffixLength);
        } while (VirtualAccount::where('no', $vaNumber)->exists());

        $virtualAccount = VirtualAccount::create([
            'no'                 => $vaNumber,
            'name'               => strtoupper($vaData['customerName']),
            'type'               => $vaData['virtualAccountType'],
            'partner_service_id' => $partnerServiceId,
            'customer_no'        => $vaData['customerNo'],
            'trx_id'             => $vaData['trxId'],
            'client_id'          => $clientId,
            'amount'             => $vaData['amount'],
            'currency'           => $vaData['currency'],
            'expires_at'         => $vaData['expiration'],
            'status'             => VirtualAccountStatus::INITIATED,
        ]);

        return $virtualAccount;
    }

    public function updateVa(VirtualAccount $virtualAccount, array $dataToUpdate): VirtualAccount
    {
        $customerName = strtoupper($dataToUpdate['name']);
        $virtualAccount->update([
            'name'      => $customerName,
            'is_active' => $dataToUpdate['is_active'],
        ]);

        $vaPayment = $virtualAccount->payments()->orderByDesc('id')->first();
        $paymentData = $dataToUpdate['paymentData'];

        if (! is_null($vaPayment) && ! empty($paymentData)) {
            $vaPayment->update($paymentData);
        }

        return $virtualAccount;
    }

    public function deleteVa(VirtualAccount $virtualAccount): bool
    {
        return $virtualAccount->delete();
    }
}

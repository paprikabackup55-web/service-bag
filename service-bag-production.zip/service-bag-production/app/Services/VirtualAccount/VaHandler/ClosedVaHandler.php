<?php

namespace App\Services\VirtualAccount\VaHandler;

use Throwable;
use Carbon\Carbon;
use App\Enums\LogLevel;
use App\Helpers\LogHelper;
use App\Models\VirtualAccount;
use App\Helpers\BagConfigHelper;
use Illuminate\Support\Facades\DB;
use App\Enums\VirtualAccountStatus;
use App\Http\Requests\Client\V1\VirtualAccount\CreateRequest;
use App\Exceptions\VirtualAccount\InvalidExpirationDateException;

class ClosedVaHandler implements VirtualAccountHandler
{
    public function createVa(int $clientId, array $vaData): VirtualAccount
    {
        if (Carbon::createFromFormat(CreateRequest::EXP_DATE_FORMAT, $vaData['expiration'])->isPast()) {
            throw new InvalidExpirationDateException;
        }

        $partnerServiceId = trim($vaData['partnerServiceId']);
        $customerNo = trim($vaData['customerNo']);

        $vaLength = (int) BagConfigHelper::va()['length'];
        $prefix = BagConfigHelper::va()['prefix_closed'] . $partnerServiceId;
        $suffixLength = $vaLength - strlen($prefix);
        $vaNumber = $prefix . str_pad($customerNo, $suffixLength, '0', STR_PAD_LEFT);

        DB::beginTransaction();
        try {// TODO: do proper locking
            $lastVa = VirtualAccount::where('no', $vaNumber)
                ->orderByDesc('id')
                ->lockForUpdate()
                ->first();

            if ($lastVa && $lastVa->status === VirtualAccountStatus::INITIATED) {
                $lastVa->update(['status' => VirtualAccountStatus::CANCELED]);
            }
            
            $virtualAccount = VirtualAccount::create([
                'no'                 => $vaNumber,
                'name'               => strtoupper($vaData['customerName']),
                'type'               => $vaData['virtualAccountType'],
                'partner_service_id' => $partnerServiceId,
                'customer_no'        => $customerNo,
                'trx_id'             => $vaData['trxId'],
                'client_id'          => $clientId,
                'amount'             => $vaData['amount'],
                'currency'           => $vaData['currency'],
                'expires_at'         => $vaData['expiration'],
                'status'             => VirtualAccountStatus::INITIATED,
            ]);
        } catch (Throwable $th) {
            DB::rollBack();
            LogHelper::create(LogLevel::Error, __METHOD__, $th);
            throw $th;
        }

        DB::commit();

        return $virtualAccount;
    }

    public function updateVa(VirtualAccount $virtualAccount, array $dataToUpdate): VirtualAccount
    {
        $virtualAccount->update([
            'name'      => strtoupper($dataToUpdate['name']),
            'is_active' => $dataToUpdate['is_active'],
        ]);

        $vaPayment = $virtualAccount->payments()->orderByDesc('id')->first();
        $paymentData = $dataToUpdate['paymentData'];

        if (! is_null($vaPayment) && ! empty($paymentData)) {
            $vaPayment->update($paymentData);
        }

        return $virtualAccount;
    }

    public function deleteVa(VirtualAccount $virtualAccount): bool
    {
        return $virtualAccount->delete();
    }
}

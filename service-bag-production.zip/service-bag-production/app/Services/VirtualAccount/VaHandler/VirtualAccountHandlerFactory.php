<?php

namespace App\Services\VirtualAccount\VaHandler;

use App\Enums\VirtualAccountType;
use InvalidArgumentException;

class VirtualAccountHandlerFactory
{
    public static function getVaHandler(VirtualAccountType $vaType, string $customerNo): VirtualAccountHandler
    {
        if ($vaType === VirtualAccountType::OPEN_PAYMENT) {
            return new OpenVaHandler;
        } elseif ($vaType === VirtualAccountType::CLOSE_PAYMENT && !empty($customerNo)) {
            return new ClosedVaHandler;
        } elseif ($vaType === VirtualAccountType::CLOSE_PAYMENT && empty($customerNo)) {
            return new ClosedDynamicVaHandler;
        } else {
            throw new InvalidArgumentException('Fail to create Virtual Account Handler');
        }
    }
}

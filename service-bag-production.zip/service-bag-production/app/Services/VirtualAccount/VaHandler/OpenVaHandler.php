<?php

namespace App\Services\VirtualAccount\VaHandler;

use App\Models\VirtualAccount;
use App\Helpers\BagConfigHelper;
use App\Enums\VirtualAccountStatus;

class OpenVaHandler implements VirtualAccountHandler
{
    public function createVa(int $clientId, array $vaData): VirtualAccount
    {
        $partnerServiceId = trim($vaData['partnerServiceId']);
        $customerNo       = trim($vaData['customerNo']);
        $customerName     = strtoupper($vaData['customerName']);

        $vaLength = (int) BagConfigHelper::va()['length'];
        $prefix = BagConfigHelper::va()['prefix_open'] . $partnerServiceId;
        $suffixLength = $vaLength - strlen($prefix);

        $virtualAccount = VirtualAccount::updateOrCreate(
            ['no' => $prefix . str_pad($customerNo, $suffixLength, "0", STR_PAD_LEFT)],
            [
                'name'               => $customerName,
                'type'               => $vaData['virtualAccountType'],
                'partner_service_id' => $partnerServiceId,
                'customer_no'        => $customerNo,
                'trx_id'             => $vaData['trxId'],
                'client_id'          => $clientId,
                'amount'             => 0.00,
                'expires_at'         => $vaData['expiration'],
                'status'             => VirtualAccountStatus::INITIATED,
            ]
        );

        // if (strcasecmp($virtualAccount->name, $customerName) !== 0) {
        //     throw new VirtualAccountAlreadyExistsException;
        // }

        return $virtualAccount;
    }

    public function updateVa(VirtualAccount $virtualAccount, array $dataToUpdate): VirtualAccount
    {
        $customerName = strtoupper($dataToUpdate['name']);
        $virtualAccount->update([
            'name'      => $customerName,
            'is_active' => $dataToUpdate['is_active'],
        ]);

        return $virtualAccount;
    }

    public function deleteVa(VirtualAccount $virtualAccount): bool
    {
        return $virtualAccount->delete();
    }
}

<?php

namespace App\Services\VirtualAccount\VaHandler;

use App\Models\VirtualAccount;

interface VirtualAccountHandler
{
    public function createVa(int $clientId, array $vaData): VirtualAccount;
    public function updateVa(VirtualAccount $virtualAccount, array $dataToUpdate): VirtualAccount;
    public function deleteVa(VirtualAccount $virtualAccount): bool;
}

<?php

namespace App\Services\VirtualAccount;

use App\Models\VirtualAccountPayment;
use App\Services\Http\ClientHttpService;
use Illuminate\Http\Client\Response;

class VaClientCallback extends ClientHttpService
{
    public function callbackPayment(VirtualAccountPayment $payment): Response
    {
        $payment->increment('callback_retry_count', 1, ['updated_at' => now()]);

        $virtualAccount = $payment->virtualAccount()->first();

        $requestBody = [
            'statusCode'            => $payment->status_code->value,
            'statusDesc'            => $payment->status_desc['en'],
            'referenceNo'           => $payment->reference_no,
            'paymentRequestId'      => $payment->inquiry->request_id,
            'paymentReferenceNo'    => $payment->payment_reference_no,
            'channelCode'           => $payment->inquiry->channel_id,
            'hashedSourceAccountNo' => $payment->source_account_no,
            'sourceBankCode'        => $payment->source_bank_code,
            'virtualAccountNo'      => $virtualAccount->no,
            'virtualAccountName'    => $virtualAccount->name,
            'virtualAccountTrxType' => $virtualAccount->type,
            'customerNo'            => $virtualAccount->customer_no,
            'amount'                => $payment->amount,
            'currency'              => $payment->currency,
            'paidAt'                => $payment->updated_at,
        ];

        $response = $this->logHttpCall(__METHOD__, $virtualAccount)
            ->callPost(
                baseUrl: $this->client->base_url,
                endpoint: $this->client->va_payment_endpoint,
                body: $requestBody
            );

        if ($response->successful()) {
            $payment->update(['callback_received_at' => now()->toDateTimeString()]);
        }

        return $response;
    }
}

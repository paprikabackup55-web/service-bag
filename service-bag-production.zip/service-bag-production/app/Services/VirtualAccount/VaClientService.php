<?php

namespace App\Services\VirtualAccount;

use App\Enums\LogLevel;
use App\Enums\VirtualAccountType;
use App\Exceptions\VirtualAccount\VirtualAccountNotFoundException;
use App\Helpers\LogHelper;
use App\Models\Client;
use App\Models\VirtualAccount;
use App\Services\VirtualAccount\VaHandler\VirtualAccountHandlerFactory;
use Exception;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Illuminate\Support\Facades\DB;
use Throwable;

class VaClientService
{
    public function createVirtualAccount(Client $client, array $vaData): VirtualAccount
    {
        $customerNo = $vaData['customerNo'];
        $vaType = VirtualAccountType::tryFrom($vaData['virtualAccountType']);

        if (! $vaType) {
            throw new Exception("Invalid Virtual Account Type {$vaData['virtualAccountType']}");
        }

        $vaTypeHandler = VirtualAccountHandlerFactory::getVaHandler($vaType, $customerNo);
        $virtualAccount = $vaTypeHandler->createVa($client->id, $vaData);

        return $virtualAccount;
    }

    public function updateVirtualAccount(Client $client, string $vaNo, array $dataToUpdate): VirtualAccount
    {
        // Query for open payment type
        $openPaymentQuery = function (EloquentBuilder $query) {
            $query->where('type', VirtualAccountType::OPEN_PAYMENT);
        };

        // Query for unpaid close payments
        $unpaidClosePaymentQuery = function (EloquentBuilder $query) {
            $query->where('type', VirtualAccountType::CLOSE_PAYMENT)
                ->whereHas('payments', function (EloquentBuilder $query) {
                    $query->whereNull('paid_at');
                });
        };

        // Main query : find va to update
        $virtualAccount = $client->virtualAccounts()
            ->where('no', $vaNo)
            ->where(function (EloquentBuilder $query) use ($openPaymentQuery, $unpaidClosePaymentQuery) {
                $query->where($openPaymentQuery)
                    ->orWhere($unpaidClosePaymentQuery);
            })
            ->first() ?? throw new VirtualAccountNotFoundException;

        DB::beginTransaction();
        try {
            $vaTypeHandler = VirtualAccountHandlerFactory::getVaHandler($virtualAccount->type, $virtualAccount->customer_no);
            // check if the rollback is still works after refactor using handler
            $virtualAccount = $vaTypeHandler->updateVa($virtualAccount, $dataToUpdate);
            DB::commit();
        } catch (Throwable $th) {
            DB::rollBack();
            LogHelper::create(LogLevel::Error, __METHOD__, $th, $virtualAccount);
            throw $th;
        }

        return $virtualAccount;
    }

    public function deleteVirtualAccount(Client $client, string $vaNo): bool
    {
        $virtualAccount = $client->virtualAccounts()->where('no', $vaNo)->first() ?? throw new VirtualAccountNotFoundException;

        $vaTypeHandler = VirtualAccountHandlerFactory::getVaHandler(
            $virtualAccount->type,
            $virtualAccount->customer_no
        );

        return $vaTypeHandler->deleteVa($virtualAccount);
    }
}

<?php

namespace App\Services\VirtualAccount;

use App\Data\InquiryVaData;
use App\Data\NotificationVaData;
use App\Data\PaymentVaData;
use App\Enums\Currency;
use App\Enums\LogLevel;
use App\Enums\PaymentStatus;
use App\Enums\ResponseCodeSnap;
use App\Enums\VirtualAccountStatus;
use App\Enums\VirtualAccountType;
use App\Exceptions\InternalServerException;
use App\Exceptions\VirtualAccount\BillNotFoundException;
use App\Exceptions\VirtualAccount\DuplicateInquiryRequestException;
use App\Exceptions\VirtualAccount\ExpiredBillException;
use App\Exceptions\VirtualAccount\InquiryRequestNotFoundException;
use App\Exceptions\VirtualAccount\InvalidAmountException;
use App\Exceptions\VirtualAccount\PaidBillException;
use App\Exceptions\VirtualAccount\VirtualAccountNotFoundException;
use App\Helpers\BagConfigHelper;
use App\Helpers\LogHelper;
use App\Helpers\NumberHelper;
use App\Helpers\ResponseHelper;
use App\Jobs\VaPaymentCallbackJob;
use App\Models\VirtualAccount;
use App\Models\VirtualAccountPayment;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\DB;
use Throwable;

class VaBagService
{
    public function inquiry(InquiryVaData $dto, string $channelId): VirtualAccount
    {
        $inquiryRequestId = trim($dto->inquiryRequestId);
        $amount = (float) $dto->amount->value;
        $currency = $dto->amount->currency;
        $additionalInfo = $dto->additionalInfo;

        if (DB::table('virtual_account_inquiries')->where('request_id', $inquiryRequestId)->exists()) {
            throw new DuplicateInquiryRequestException;
        }

        $va = $this->findVirtualAccount($dto->virtualAccountNo);

        $this->validateForPayment($va, $amount, $currency, false);

        if ($amount != 0) { // This is for 2nd Inquiry: flag for first inquiry is $amount == 0
            $this->validateForPayment($va, $amount, $currency, $additionalInfo->flagAmountCheck);

            $va->inquiries()->create([
                'request_id'               => $inquiryRequestId,
                'hashed_source_account_no' => $dto->sourceAccountNo,
                'source_bank_code'         => $dto->sourceBankCode,
                'merchant_id'              => $additionalInfo->merchantId,
                'processing_code'          => $additionalInfo->proCode,
                'flag_amount_check'        => $additionalInfo->flagAmountCheck,
                'reference_no'             => $additionalInfo->referenceNo,
                'channel_id'               => '', // todo: make it nullable
            ]);

            $paymentDto = PaymentVaData::fromInquiryVaDto($dto);
            $this->payment($paymentDto);
        }

        return $va;
    }

    public function payment(PaymentVaData $dto): VirtualAccountPayment
    {
        $paymentRequestId = $dto->paymentRequestId;
        $paidAmountData = $dto->paidAmount;

        $virtualAccount = $this->findVirtualAccount($dto->virtualAccountNo);

        $inquiry = $virtualAccount->inquiries()
            ->where('request_id', $paymentRequestId)
            ->whereNull('completed_at')
            ->orderByDesc('created_at')
            ->first() ?? throw new InquiryRequestNotFoundException('Invalid paymentRequestId');

        $payment = VirtualAccountPayment::create(
            [
                'status_code' => PaymentStatus::Pending,
                'reference_no' => $this->generateReferenceNo(),
                'payment_reference_no' => $dto->referenceNo ?? $paymentRequestId,
                'amount' => $paidAmountData->value,
                'currency' => $paidAmountData->currency,
                'channel_code' => $dto->channelCode,
                'source_bank_code' => $dto->sourceBankCode,
                'source_account_no' => $dto->sourceAccountNo,
                'source_account_name' => $dto->additionalInfo->sourceAccountName,
                'virtual_account_id' => $virtualAccount->id,
                'inquiry_id' => $inquiry->id,
            ]
        );

        try {
            $this->validateForPayment($virtualAccount, $paidAmountData->value, $paidAmountData->currency);
            // $this->clientCallbackPayment($payment);
        } catch (Throwable $th) {
            $payment->update(['status_code' => PaymentStatus::Failed]);
            throw $th;
        }

        if ($virtualAccount->type === VirtualAccountType::CLOSE_PAYMENT) {
            $virtualAccount->update(['status' => VirtualAccountStatus::PAID]);
        }

        // $payment->update(['status_code' => PaymentStatus::Success]); // payment better stay at pending
        $inquiry->update(['completed_at' => now()->toDateTimeString()]);

        return $payment;
    }

    public function paymentNotification(NotificationVaData $dto): VirtualAccountPayment
    {
        $virtualAccount = $this->findVirtualAccount($dto->virtualAccountNo);
        $requestId = $dto->paymentRequestId ?? $dto->inquiryRequestId;

        throw_if(blank($requestId), new Exception('Payment not found'));

        $payment = VirtualAccountPayment::where('status_code', PaymentStatus::Pending)
            ->whereHas('inquiry.virtualAccount', fn ($q) => $q->where('id', $virtualAccount->id))
            ->whereHas('inquiry', fn ($q) => $q->where('request_id', $requestId))
            ->whereHas('inquiry', fn ($q) => $q->whereNotNull('completed_at'))
            ->first() ?? throw new BillNotFoundException;

        $statusCode = PaymentStatus::isSuccess($dto->paymentStatus ?? '') ? PaymentStatus::Success : PaymentStatus::Failed;

        $additionalInfo = $dto->additionalInfo;

        $payment->update([
            'status_code' => $statusCode,
            'notified_at' => now()->toDateTimeString(),
            'description' => $additionalInfo?->description,
            // 'order_id'    => $additionalInfo?->orderId,
        ]);

        VaPaymentCallbackJob::dispatch($payment->id);

        return $payment;
    }

    private function findVirtualAccount(string $vaNo): VirtualAccount
    {
        return VirtualAccount::query()
            ->where('no', $vaNo)
            ->whereNot('status', VirtualAccountStatus::CANCELED)
            ->orderByDesc('id')
            ->first() ?? throw new VirtualAccountNotFoundException;
    }

    private function generateReferenceNo(): string
    {
        $maxAttempts = 100;
        $attempt = 0;
        $prefixRefNo = BagConfigHelper::va()['prefix_ref_number'];
        do {
            throw_if($attempt >= $maxAttempts, new Exception('reference number generator failed'));
            $referenceNo = $prefixRefNo.now()->format('ymdHis').NumberHelper::random(4);
            $attempt++;
        } while (DB::table('virtual_account_payments')->where('reference_no', $referenceNo)->exists());

        return $referenceNo;
    }

    public function validateForPayment(
        VirtualAccount $va,
        float $paidAmount,
        string $paidCurrency,
        ?bool $flagAmountCheck = true
    ): void {
        // Status Validation
        throw_if($va->status === VirtualAccountStatus::CANCELED, new Exception('Virtual Account is not active'));

        // Validate Paid Status
        throw_if($va->status === VirtualAccountStatus::PAID, new PaidBillException);

        // Validate Expiration Date
        $expirationDate = Carbon::parse($va->expires_at);
        throw_if($expirationDate->isPast() || $va->status === VirtualAccountStatus::EXPIRED, new ExpiredBillException);

        // Validate Amount
        throw_if($paidAmount < 0 || ! in_array($paidCurrency, Currency::values()), new InvalidAmountException);

        // Validate Exact Amount for Closed VA
        if ($va->type === VirtualAccountType::CLOSE_PAYMENT) {
            throw_if(
                $flagAmountCheck === true && ($va->amount != $paidAmount || $va->currency != $paidCurrency),
                new InvalidAmountException
            );
        }
    }

    public function clientCallbackPayment(VirtualAccountPayment $payment): void
    {
        try {
            $virtualAccount = $payment->virtualAccount()->first();

            $vaClientCallback = new VaClientCallback($virtualAccount->client);

            $response = $vaClientCallback->callbackPayment($payment);

            LogHelper::create(LogLevel::Info, __METHOD__, $response, $virtualAccount);
        } catch (ConnectionException $e) {
            LogHelper::create(LogLevel::Warning, __METHOD__, $e, $virtualAccount);
            throw $e;
        } catch (Throwable $e) {
            LogHelper::create(LogLevel::Error, __METHOD__, $e, $virtualAccount);
            throw $e;
        }

        if ($response->failed()) {
            LogHelper::create(LogLevel::Alert, 'Unexpected status from core-pg:'.__METHOD__, $response, $virtualAccount);
            throw new Exception('Core Server Error');
        }

        $responseBody = $response->json() ?? [];

        $snapResponse = ResponseHelper::toSnapCode($responseBody['responseCode']);

        if ($snapResponse !== ResponseCodeSnap::Successful) {
            match ($snapResponse) {
                ResponseCodeSnap::TransactionExpired => throw new ExpiredBillException,
                ResponseCodeSnap::TransactionNotFound => throw new BillNotFoundException,
                ResponseCodeSnap::InvalidAmount => throw new InvalidAmountException,
                ResponseCodeSnap::InvalidMandatoryField,
                ResponseCodeSnap::InvalidMerchant,
                ResponseCodeSnap::DuplicatePartnerReferenceNo => throw new InternalServerException,
                default => throw new Exception('Unknown Error'),
            };
        }
    }
}

<?php

namespace App\Services\Disbursement;

use App\Enums\DisbursementStatus;
use App\Exceptions\Disbursement\DuplicatePartnerReferenceNoException;
use App\Exceptions\Disbursement\InvalidDisbursementStatus;
use App\Exceptions\Disbursement\PartnerReferenceNoNotFound;
use App\Exceptions\Disbursement\PaymentMethodNotFound;
use App\Helpers\NumberHelper;
use App\Models\Client;
use App\Models\Disbursement;
use App\Models\PaymentMethod;
use Exception;
use Illuminate\Support\Facades\Cache;

class DisbursementService
{
    public function inquiryAccount(Client $client, array $inquiryData): Disbursement
    {
        $paymentMethodCode = $inquiryData['paymentMethodCode'];
        $partnerReferenceNo = $inquiryData['partnerReferenceNo'];
        $accountNo = $inquiryData['accountNo'];
        $bankCode = $inquiryData['bankCode'];
        $bankType = $inquiryData['bankType'];
        $amount = $inquiryData['amount'];
        $currency = $inquiryData['currency'];
        $remark = $inquiryData['remark'];

        if ($client->disbursements()->where('partner_reference_no', $partnerReferenceNo)->exists()) {
            throw new DuplicatePartnerReferenceNoException;
        }

        $paymentMethod = Cache::tags('payment_methods')->remember(
            key: implode(':', ['payment_methods']),
            ttl: 3600 * 3,
            callback: fn() => PaymentMethod::select(['id', 'name', 'code'])->get()
        )->filter(fn($pm) => $pm->code === $paymentMethodCode)
        ->first() ?? throw new PaymentMethodNotFound;

        do { //TODO: this should be clarified later by BAG 
            if ($paymentMethod->id === PaymentMethod::BI_FAST) {
                $referenceNo = app()->environment('production')
                    ? now()->format('ymdu') : '133' . NumberHelper::random(9);
            } else {
                $referenceNo = now()->format('ymdHisu') . NumberHelper::random(12);
            }
        } while (Disbursement::where('reference_no', $referenceNo)->exists());

        $disbursement = $client->disbursements()->create([
            'partner_reference_no' => $partnerReferenceNo,
            'reference_no'         => $referenceNo,
            'account_no'           => $accountNo,
            'bank_code'            => $bankCode,
            'bank_type'            => $bankType,
            'amount'               => $amount,
            'currency'             => $currency,
            'remark'               => $remark,
            'payment_method_id'    => $paymentMethod->id,
        ]);

        $httpResult = TransferServiceFactory::create($paymentMethod->id)->inquiry($disbursement);

        if (! $httpResult->isSuccess) {
            $disbursement->update(['status_code' => DisbursementStatus::NotFound]);
            throw new Exception($httpResult->message);
        }

        $responseBody = $httpResult->data;
        $disbursement->update([
            'status_code'           => DisbursementStatus::Initiated,
            'account_name'          => $responseBody['beneficiaryAccountName'] ?? $responseBody['data']['receiverName'] ?? '',
            'customer_reference_no' => $responseBody['data']['customerRefNumber'] ?? '',
            'receiver_type'         => $responseBody['data']['receiverType'] ?? '',
            'receiver_account_type' => $responseBody['data']['receiverAccountType'] ?? '',
        ]);

        return $disbursement;
    }

    public function transfer(Client $client, string $partnerReferenceNo): Disbursement
    {
        $disbursement = $client->disbursements()
            ->with('paymentMethod')
            ->where('partner_reference_no', $partnerReferenceNo)
            ->first() ?? throw new PartnerReferenceNoNotFound;

        throw_if(
            $disbursement->status_code !== DisbursementStatus::Initiated,
            new InvalidDisbursementStatus(data: [
                'referenceNo' => $disbursement->reference_no,
                'status_code' => $disbursement->status_code->value,
                'status_desc' => $disbursement->status_desc,
            ])
        );

        $disbursement->update(['status_code' => DisbursementStatus::Pending]);

        $httpResult = TransferServiceFactory::create($disbursement->payment_method_id)->transfer($disbursement);

        $disbursement->update([
            'status_code' => $httpResult->isSuccess ? DisbursementStatus::Success : DisbursementStatus::Failed
        ]);

        return $disbursement;
    }

    public function inquiryStatus(Client $client, string $partnerReferenceNo): Disbursement
    {
        $disbursement = $client->disbursements()
            ->with('paymentMethod')
            ->where('partner_reference_no', $partnerReferenceNo)
            ->whereNotNull('status_code')
            ->first() ?? throw new PartnerReferenceNoNotFound;

        //TODO: Update disbursement status after http call, snap one is not given, bifast one is given, thou not clear (see doc)
        $httpResult = TransferServiceFactory::create($disbursement->payment_method_id)->status($disbursement);

        return $disbursement;
    }
}

<?php

namespace App\Services\Disbursement;

use App\Models\PaymentMethod;
use InvalidArgumentException;

class TransferServiceFactory
{
    public static function create(int $paymentMethodId): TransferService
    {
        return match ($paymentMethodId) {
            PaymentMethod::INTRA   => new TransferIntrabankService(),
            PaymentMethod::INTER   => new TransferInterbankService(),
            PaymentMethod::BI_FAST => new TransferBifastService(),
            default                => throw new InvalidArgumentException("Unsupported payment method ID: $paymentMethodId"),
        };
    }
}
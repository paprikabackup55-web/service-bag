<?php

namespace App\Services\Disbursement;

use App\Enums\LogLevel;
use App\Helpers\BagConfigHelper;
use App\Helpers\LogHelper;
use App\Models\Disbursement;
use App\Services\Http\BagSnapHttpService;
use App\Services\Support\HttpResult;
use Throwable;

class TransferIntrabankService extends BagSnapHttpService implements TransferService
{
    private const INQUIRY_SUCCESS_CODE  = '2001500';
    private const TRANSFER_SUCCESS_CODE = '2001700';
    private const STATUS_SUCCESS_CODE   = '2003600';  // the api is not given by vendor (supposed to be given)

    public function inquiry(Disbursement $disbursement): HttpResult
    {
        try {
            $accessToken = $this->getAccessToken();
            $endpoint = '/snap/api/v1.0/account-inquiry-internal';
            $body = [
                'partnerReferenceNo'   => $disbursement->reference_no,
                'beneficiaryAccountNo' => $disbursement->account_no,
                'additionalInfo'       => [
                    'merchantId' => BagConfigHelper::inbound()['client_name'],// TODO
                    'channel'    => 'API',
                    'proCode'    => '321000',
                ],
            ];

            $response = $this->logHttpCall(__METHOD__, $disbursement)
                ->callPost(BagConfigHelper::baseUrl(), $endpoint, $body, $accessToken);

            return HttpResult::fromSnapResponse($response, self::INQUIRY_SUCCESS_CODE);
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th, $disbursement);

            return HttpResult::fromException($th);
        }
    }

    public function transfer(Disbursement $disbursement): HttpResult
    {
        try {
            $accessToken = $this->getAccessToken();
            $endpoint = '/snap/api/v1.0/transfer-intrabank';
            $body = [
                'partnerReferenceNo' => $disbursement->reference_no,
                'amount'             => [
                    'value'    => $disbursement->amount,
                    'currency' => $disbursement->currency,
                ],
                'beneficiaryAccountName' => $disbursement->account_name,
                'beneficiaryAccountNo'   => $disbursement->account_no,
                'beneficiaryEmail'       => '',
                'currency'               => $disbursement->currency,
                'customerReference'      => '',
                'feeType'                => '',
                'remark'                 => substr($disbursement->remark ?? '', 0, 50),
                'sourceAccountNo'        => BagConfigHelper::accountNo(),
                'transactionDate'        => now()->format('c'),
                'additionalInfo'         => [
                    'merchantId' => BagConfigHelper::inbound()['client_name'],
                    'channel'    => 'API',
                    'proCode'    => '172007',//TODO: clarify
                    'customerId' => '',
                ],
            ];

            $response = $this->logHttpCall(__METHOD__, $disbursement)
                ->callPost(BagConfigHelper::baseUrl(), $endpoint, $body, $accessToken);

            return HttpResult::fromSnapResponse($response, self::TRANSFER_SUCCESS_CODE);
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th, $disbursement);

            return HttpResult::fromException($th);
        }
    }

    public function status(Disbursement $disbursement): HttpResult
    {
        return HttpResult::success(null);
    }
}

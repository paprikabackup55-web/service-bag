<?php

namespace App\Services\Disbursement;

use App\Models\Disbursement;
use App\Services\Support\HttpResult;

interface TransferService {
    public function inquiry(Disbursement $disbursement): HttpResult;
    public function transfer(Disbursement $disbursement): HttpResult;
    public function status(Disbursement $disbursement): HttpResult;
}

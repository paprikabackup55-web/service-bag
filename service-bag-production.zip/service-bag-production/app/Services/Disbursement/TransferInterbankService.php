<?php

namespace App\Services\Disbursement;

use App\Enums\LogLevel;
use App\Helpers\BagConfigHelper;
use App\Helpers\LogHelper;
use App\Models\Disbursement;
use App\Services\Http\BagSnapHttpService;
use App\Services\Support\HttpResult;
use Throwable;

class TransferInterbankService extends BagSnapHttpService implements TransferService
{
    public const INQUIRY_SUCCESS_CODE  = '2001600';
    public const TRANSFER_SUCCESS_CODE = '2001800';
    public const STATUS_SUCCESS_CODE   = '2003600';  // the api is not given by vendor

    public function inquiry(Disbursement $disbursement): HttpResult
    {
        try {
            $accessToken = $this->getAccessToken();
            $endpoint = '/snap/api/v1.0/account-inquiry-external';
            $body = [
                'beneficiaryBankCode'  => $disbursement->bank_code,
                'beneficiaryAccountNo' => $disbursement->account_no,
                'partnerReferenceNo'   => $disbursement->reference_no,
                'additionalInfo'       => [
                    'merchantId'      => BagConfigHelper::inbound()['client_name'],
                    'channel'         => 'API',
                    'proCode'         => '321000',//TODO: clarify
                    'sourceAccountNo' => BagConfigHelper::accountNo(),
                ],
            ];

            $response = $this->logHttpCall(__METHOD__, $disbursement)
                ->callPost(BagConfigHelper::baseUrl(), $endpoint, $body, $accessToken);

            return HttpResult::fromSnapResponse($response, self::INQUIRY_SUCCESS_CODE);
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th, $disbursement);

            return HttpResult::fromException($th);
        }
    }

    public function transfer(Disbursement $disbursement): HttpResult
    {
        try {
            $accessToken = $this->getAccessToken();
            $endpoint = '/snap/api/v1.0/transfer-interbank';
            $body = [
                'partnerReferenceNo' => $disbursement->reference_no,
                'amount'             => [
                    'value'    => $disbursement->amount,
                    'currency' => $disbursement->currency,
                ],
                'beneficiaryAccountName' => $disbursement->account_name,
                'beneficiaryAccountNo'   => $disbursement->account_no,
                'beneficiaryAddress'     => '',
                'beneficiaryBankCode'    => $disbursement->bank_code,
                'beneficiaryBankName'    => '',
                'beneficiaryEmail'       => '',
                'currency'               => $disbursement->currency,
                'customerReference'      => '',
                'sourceAccountNo'        => BagConfigHelper::accountNo(),
                'transactionDate'        => now()->format('c'),
                'feeType'                => '',
                'additionalInfo'         => [
                    'merchantId' => BagConfigHelper::inbound()['client_name'],
                    'channel'    => 'API',
                    'proCode'    => '172007',//TODO: clarify
                    'customerId' => '',
                ],
            ];

            $response = $this->logHttpCall(__METHOD__, $disbursement)
                ->callPost(BagConfigHelper::baseUrl(), $endpoint, $body, $accessToken);

            return HttpResult::fromSnapResponse($response, self::TRANSFER_SUCCESS_CODE);
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th, $disbursement);

            return HttpResult::fromException($th);
        }
    }

    public function status(Disbursement $disbursement): HttpResult
    {
        return HttpResult::success(null);
    }
}

<?php

namespace App\Services\Disbursement;

use App\Enums\LogLevel;
use App\Helpers\BagConfigHelper;
use App\Helpers\LogHelper;
use App\Models\Disbursement;
use App\Services\Http\BagBifastHttpService;
use App\Services\Support\HttpResult;
use Throwable;

class TransferBifastService extends BagBifastHttpService implements TransferService
{
    public const SUCCESS_CODE = '00';

    public function inquiry(Disbursement $disbursement): HttpResult
    {
        try {
            $endpoint = '/api/v1/bifast/inquirytransferout';
            $body = [
                'merchantId'            => BagConfigHelper::bifast()['merchant_id'],
                'merchantType'          => '6849',//via API
                'referenceNumber'       => $disbursement->reference_no,
                'receiverBankCode'      => $disbursement->bank_code,
                'description'           => $disbursement->remark,
                'receiverAccountNumber' => $disbursement->account_no,
                'receiverBankType'      => $disbursement->bank_type,
                'IDCustT24'             => '',
                'senderTown'            => '',
                'dateTime'              => now()->toDateTimeString(),
                'amount'                => $disbursement->amount,
                'senderBankCode'        => '037',//TODO
                'terminalId'            => self::getIdentifierNumberFromIp(),
                'currency'              => $disbursement->currency,
                'senderAccountType'     => '10',//TODO: config
                'senderName'            => 'PT PAPRIKA MULTIMEDIA',//TODO: config
                'receiverProxyValue'    => '',
                'receiverProxyType'     => '',
                'senderAccountNumber'   => BagConfigHelper::accountNo(),
            ];

            $response = $this->logHttpCall(__METHOD__, $disbursement)
                ->callPost(BagConfigHelper::bifast()['base_url'], $endpoint, $body);

            return HttpResult::fromBifastResponse($response, self::SUCCESS_CODE);
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th, $disbursement);

            return HttpResult::fromException($th);
        }
    }

    public function transfer(Disbursement $disbursement): HttpResult
    {
        try {
            $endpoint = '/api/v1/bifast/transferoutgoing';
            $terminalId = self::getIdentifierNumberFromIp();
            $description = substr($disbursement->remark ?? '', 0, 255);
            $receiverBankType = '01';// TODO: 10=Savings Account, 20=Current account, 30=Credit Card, 32=Loan, 60=E-Money, 00=None of the above
            $now = now();

            $body = [
                'merchantId'            => BagConfigHelper::bifast()['merchant_id'],
                'amount'                => $disbursement->amount,
                'senderResident'        => '01',//01 WNI, 02 WNA
                'senderTown'            => '',
                'merchantType'          => '6849',
                'senderIdNumber'        => '031880529061000',//TODO: no KTP pengirim
                'receiverBankCode'      => $disbursement->bank_code,
                'description'           => $description,
                'receiverResident'      => '',
                'terminalId'            => $terminalId,
                'receiverAccountNumber' => $disbursement->account_no,
                'dateTime'              => $now->format('Y-m-d H:i:s'),
                'senderAccountNumber'   => BagConfigHelper::accountNo(),
                'receiverIdNumber'      => '',
                'receiverName'          => $disbursement->account_name,
                'senderType'            => '02',//TODO: 02 Coporate
                'currency'              => $disbursement->currency,
                'receiverAccountType'   => '',
                'receiverProxyType'     => '',
                'receiverProxyValue'    => '',
                'receiverBankType'      => $receiverBankType,//TODO
                'receiverType'          => $disbursement->receiverType,//TODO: the enum same as senderType
                'senderBankCode'        => '037',
                'senderAccountType'     => '10',//TODO: config
                'receiverTown'          => '',
                'senderName'            => 'PT PAPRIKA MULTIMEDIA',//TODO: config
                'IDCustT24'             => '',
                'customerRefNumber'     => $disbursement->customer_ref_number,
                'referenceNumber'       => $disbursement->reference_no,
            ];

            $response = $this->logHttpCall(__METHOD__, $disbursement)
                ->callPost(BagConfigHelper::bifast()['base_url'], $endpoint, $body);

            return HttpResult::fromBifastResponse($response, self::SUCCESS_CODE);
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th, $disbursement);

            return HttpResult::fromException($th);
        }
    }

    public function status(Disbursement $disbursement): HttpResult
    {
        try {
            $endpoint = '/api/v1/bifast/statusReqOutgoing';
            $terminalId = self::getIdentifierNumberFromIp();
            $senderAccType = '10';//TODO: 10=Savings Account, 20=Current account, 30=Credit Card, 32=Loan, 60=E-Money, 00=None of above
            $receiverName = substr($disbursement->account_name ?? '', 0, 50);
            $receiverBankType = '01';// TODO: 10=Savings Account, 20=Current account, 30=Credit Card, 32=Loan, 60=E-Money, 00=None of the above

            $now = now();

            $body = [
                'merchantId'            => BagConfigHelper::bifast()['merchant_id'],
                'amount'                => $disbursement->amount,
                'senderResident'        => '01',//TODO: 01 WNI, 02 WNA
                'senderTown'            => '',
                'merchantType'          => '6849',//via API
                'senderIdNumber'        => '031880529061000',// TODO: no KTP pengirim
                'receiverBankCode'      => $disbursement->bank_code,
                'description'           => '',
                'receiverResident'      => '',
                'terminalId'            => $terminalId,
                'receiverAccountNumber' => $disbursement->account_no,
                'dateTime'              => $now->format('Y-m-d H:i:s'),
                'senderAccountNumber'   => BagConfigHelper::accountNo(),
                'receiverIdNumber'      => '',
                'receiverName'          => $receiverName,
                'senderType'            => '02',//TODO: 02 Coporate
                'currency'              => $disbursement->currency,
                'receiverAccountType'   => '',
                'receiverProxyValue'    => '',
                'receiverProxyValue'    => '',
                'receiverBankType'      => $receiverBankType,//TODO: 
                'receiverType'          => $disbursement->receiver_type,
                'senderBankCode'        => '037',
                'senderAccountType'     => $senderAccType,//TODO: config
                'receiverTown'          => '',
                'senderName'            => 'PT PAPRIKA MULTIMEDIA',//TODO: config
                'IDCustT24'             => '',
                'customerRefNumber'     => $disbursement->customer_ref_number,
                'referenceNumber'       => $disbursement->reference_no,
            ];

            $response = $this->logHttpCall(__METHOD__, $disbursement)
                ->callPost(BagConfigHelper::bifast()['base_url'], $endpoint, $body);

            return HttpResult::fromBifastResponse($response, self::SUCCESS_CODE);
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th, $disbursement);

            return HttpResult::fromException($th);
        }
    }

    private function getIdentifierNumberFromIp(): string
    {
        $ip = request()->ip() ?? '0.0.0.0';
        $cleanedIp = str_replace('.', '', $ip);
        $identifier = substr($cleanedIp, 0, 8);

        return str()->padRight($identifier, 8, '0');
    }
}

<?php

namespace App\Services\Support;

class Result
{
    public bool $isSuccess;
    public $data;
    public ?string $message;

    protected function __construct(bool $isSuccess, $data = null, ?string $message = null)
    {
        $this->isSuccess = $isSuccess;
        $this->data = $data;
        $this->message = $message;
    }

    public static function success($data = null): self
    {
        return new static(true, $data);
    }

    public static function failure(string $message): self
    {
        return new static(false, null, $message);
    }

    public function toArray(): array
    {
        return [
            'isSuccess' => $this->isSuccess,
            'data'      => $this->data,
            'message'   => $this->message,
        ];
    }
}
<?php

namespace App\Services\Support;

use Exception;
use Throwable;
use Illuminate\Http\Client\Response;

class HttpResult extends Result
{
    public ?Response $response;
    public ?string $errorCode;

    public function __construct(
        ?Response $response,
        bool $isSuccess,
        $data = null,
        ?string $errorCode = null,
        ?string $errorMessage = null
    ) {
        parent::__construct($isSuccess, $data, $errorMessage);
        $this->response = $response;
        $this->errorCode = $errorCode;

        // Override data if success and response is available
        if ($isSuccess && $response && $data === null) {
            $this->data = $response->json();
        }
    }

    public static function fromSnapResponse(Response $response, string $successCode): self
    {
        $isSuccess = $response->json('responseCode') === $successCode;

        return new self(
            response    : $response,
            isSuccess   : $isSuccess,
            errorCode   : $isSuccess ? null: $response->json('responseCode'),
            errorMessage: $isSuccess ? null: $response->json('responseMessage') ?? 'Unknown error'
        );
    }

    public static function fromBifastResponse(Response $response, string $successCode): self
    {
        $isSuccess = $response->json('responseCode') === $successCode;

        return new self(
            response    : $response,
            isSuccess   : $isSuccess,
            errorCode   : $isSuccess ? null: $response->json('responseCode'),
            errorMessage: $isSuccess ? null: $response->json('desacription') ?? 'Unknown error'
        );
    }

    public static function fromException(Throwable $exception): self
    {
        $errorCode = $exception instanceof Exception ? (string) $exception->getCode() : '500';
        return new self(
            response    : null,
            isSuccess   : false,
            data        : null,
            errorCode   : $errorCode,
            errorMessage: $exception->getMessage()
        );
    }

    public function toArray(): array
    {
        $baseArray = parent::toArray();
        return array_merge($baseArray, [
            'errorCode'  => $this->errorCode,
            'statusCode' => $this->response ? $this->response->getStatusCode() : null,
            // Optionally include response details if needed
        ]);
    }
}

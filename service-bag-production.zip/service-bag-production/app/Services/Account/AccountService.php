<?php

namespace App\Services\Account;

use App\Exceptions\ApiException\BagSnapApiException;
use App\Helpers\NumberHelper;
use App\Helpers\BagConfigHelper;
use App\Services\Http\BagSnapHttpService;

class AccountService extends BagSnapHttpService
{
    public function getBalance(bool $isSimpleResponse): array
    {
        $accessToken = $this->getAccessToken();
        $endpoint = '/snap/api/v1.0/balance-inquiry';
        $body = [
            'partnerReferenceNo' => now()->format('ymdHis').NumberHelper::random(8),
            'accountNo'          => BagConfigHelper::accountNo(),
            'bankCardToken'      => '',
            'balanceTypes'       => '',
            'additionalInfo'     => [
                'merchantId' => BagConfigHelper::inbound()['client_name'],
                'channel'    => 'API',
            ],
        ];

        $response = $this->logHttpCall(__METHOD__)
            ->callPost(BagConfigHelper::baseUrl(), $endpoint, $body, $accessToken);

        throw_if(
            $response->json('responseCode') !== '2001100',
            new BagSnapApiException($response->json('responseCode'), $response->json('responseMessage'))
        );

        $data = $response->json();
        if ($isSimpleResponse) {
            $accountInfo = $response->json('accountInfo.element');
            $balance = $accountInfo['availableBalance']['value'];
            $status = match ($response->json('accountInfo.element.status')) {
                '0001' => 'Active',
                '0002' => 'Close',
                '0004' => 'New',
                '0006' => 'Restricted',
                '0007' => 'Frozen',
                '0009' => 'Dormant'
            };

            $data = [
                'accountNo' => $response->json('accountNo'),
                'accountName' => $response->json('name'),
                'accountStatus' => $status,
                'balance' => $balance,
            ];
        }

        return $data;
    }

    public function getStatement(string $startDate, string $endDate, int $page, int $perPage): array
    {
        $accessToken = $this->getAccessToken();
        $endpoint = '/snap/api/v1.0/bank-statement';
        $body = [
            'partnerReferenceNo' => now()->format('ymdHis').NumberHelper::random(8),
            'fromDateTime' => $startDate,
            'toDateTime' => $endDate,
            'pageSize' => (string) $perPage,
            'pageNumber' => (string) $page,
            'additionalInfo' => [
                'merchantId' => BagConfigHelper::inbound()['client_name'],
                'channel' => 'API',
                'account' => BagConfigHelper::accountNo(),
            ],
        ];

        $response = $this->logHttpCall(__METHOD__)
            ->callPost(BagConfigHelper::baseUrl(), $endpoint, $body, $accessToken);

        throw_if(
            $response->json('responseCode') !== '2001200',
            new BagSnapApiException($response->json('responseCode'), $response->json('responseMessage'))
        );

        return $response->json('detailData');
    }
}

<?php

namespace App\Services\Http;

use App\Enums\LogLevel;
use App\Enums\ResponseCode;
use App\Enums\ResponseCodeSnap;
use App\Exceptions\ApiException\BagSnapApiException;
use App\Exceptions\GetAccessTokenException;
use App\Helpers\BagConfigHelper;
use App\Helpers\LogHelper;
use App\Helpers\NumberHelper;
use App\Helpers\SecurityHelper;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Throwable;

class BagSnapHttpService extends BaseHttpService
{
    protected function throwApiException(
        ResponseCodeSnap|ResponseCode $errorCode,
        string $message,
        ?Throwable $previous = null
    ): never {
        throw new BagSnapApiException($errorCode, $message, $previous);
    }

    protected function handleFailedResponse(Response $response, string $method, string $url): void
    {
        $responseData = $response->json();
        if (is_array($responseData) && isset($responseData['responseCode'])) {
            $code = ResponseCodeSnap::tryFromExtResponse($responseData['responseCode']) ?? ResponseCodeSnap::GeneralError;
            $message = $responseData['responseMessage'] ?? 'Unknown error';
        } else {
            $status = $response->status();
            $code = match ($status) {
                400     => ResponseCodeSnap::BadRequest,
                401     => ResponseCodeSnap::Unauthorized,
                403     => ResponseCodeSnap::TransactionExpired,
                404     => ResponseCodeSnap::TransactionNotFound,
                default => ResponseCodeSnap::GeneralError,
            };
            $message = "Request to {$url} failed with status {$status}";
        }

        $this->throwApiException($code, $message);
    }

    protected function generateHeaders(
        string $method,
        string $endpoint,
        ?array $body = [],
        ?string $accessToken = null
    ): array {
        $timestamp = now()->format('c');
        $headers = [
            'X-TIMESTAMP' => $timestamp,
            'X-SIGNATURE' => SecurityHelper::generateSymmetricSignature(
                algo: 'sha512',
                data: implode(':', [
                    strtoupper($method),
                    $endpoint,
                    $accessToken,
                    hash('sha256', count($body) === 0 ? '' : json_encode($body, JSON_UNESCAPED_SLASHES)),
                    $timestamp,
                ]),
                key: base64_decode(BagConfigHelper::inbound()['client_secret'])
            ),
            'X-PARTNER-ID' => BagConfigHelper::inbound()['client_id'],
            'X-EXTERNAL-ID' => now()->format('ymdHisu').NumberHelper::random(12),
            'CHANNEL-ID' => '12345',
        ];

        if ($accessToken) {
            $headers['Authorization'] = "Bearer {$accessToken}";
        }

        return $headers;
    }

    protected function getAccessToken(): string
    {
        $accessTokenCacheKey = implode(':', [
            'clients',
            request()->attributes->get('client')->id,
            'snap_access_token',
        ]);

        $accessToken = Cache::get($accessTokenCacheKey);
        if (! $accessToken) {
            $timestamp = now()->format('c');
            $clientKey = BagConfigHelper::inbound()['client_id'];
            $logMessage = Str::snake(Str::after(__METHOD__, '::'));
            $baseUrl = BagConfigHelper::baseUrl();

            try {
                $response = Http::acceptJson()
                    ->withHeaders([
                        'X-TIMESTAMP' => $timestamp,
                        'X-CLIENT-KEY' => $clientKey,
                        'X-SIGNATURE' => SecurityHelper::generateAsymmetricSignature(
                            data      : $clientKey.'|'.$timestamp,
                            privateKey: Storage::disk('local')->get('bag/private.pem')
                        ),
                    ])
                    ->beforeSending(LogHelper::logOutgoingRequest($logMessage))
                    ->post(
                        url: $baseUrl.'/api/v1/bisnap/access-token',
                        data: ['grantType' => 'client_credentials']
                    );

                $isError = $response->json('responseCode') !== '2007300';

                LogHelper::create(LogLevel::Info, $logMessage, $response);
            } catch (Throwable $th) {
                $isError = true;
                LogHelper::create(LogLevel::Error, $logMessage, $th);
            }

            throw_if($isError, GetAccessTokenException::class, 'Get access token failed');

            $accessToken = $response->json('accessToken');

            Cache::put($accessTokenCacheKey, $accessToken, $response->json('expiresIn') - 60);
        }

        return $accessToken;
    }
}

<?php

namespace App\Services\Http;

use App\Enums\ResponseCode;
use App\Enums\ResponseCodeSnap;
use App\Exceptions\ApiException\ClientApiException;
use App\Helpers\SecurityHelper;
use App\Models\Client;
use Throwable;

class ClientHttpService extends BaseHttpService
{
    public function __construct(protected Client $client) {}

    protected function throwApiException(
        ResponseCodeSnap|ResponseCode $errorCode,
        string $message,
        ?Throwable $previous = null
    ): never {
        throw new ClientApiException($errorCode, $message, $previous);
    }

    protected function generateHeaders(
        string $method,
        string $endpoint,
        ?array $body = [],
        ?string $accessToken = null
    ): array {
        $timestamp = now()->format('c');

        return [
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
            'X-API-KEY'    => $this->client->client_api_key,
            'X-TIMESTAMP'  => $timestamp,
            'X-SIGNATURE'  => SecurityHelper::generateAsymmetricSignature(
                data: implode(':', [
                    $method,
                    parse_url($endpoint, PHP_URL_PATH),
                    hash('sha256', json_encode($body, JSON_UNESCAPED_SLASHES)),
                    $timestamp,
                ]),
                privateKey: $this->client->private_key
            ),
            'X-REQUEST-ID' => (string) str()->uuid(),
        ];
    }
}

<?php

namespace App\Services\Http;

use App\Enums\ResponseCode;
use App\Enums\ResponseCodeSnap;
use App\Exceptions\ApiException\BagBifastApiException;
use App\Helpers\BagConfigHelper;
use App\Helpers\SecurityHelper;
use Throwable;

class BagBifastHttpService extends BaseHttpService
{
    protected function throwApiException(
        ResponseCodeSnap|ResponseCode $errorCode,
        string $message,
        ?Throwable $previous = null
    ): never {
        throw new BagBifastApiException($errorCode, $message, $previous);
    }

    protected function generateHeaders(
        string $method,
        string $endpoint,
        ?array $body = [],
        ?string $accessToken = null
    ): array {
        $apiKey = BagConfigHelper::bifast()['api_key'];
        $timestamp = now()->format('c');
        $minifiedBody = str_replace(["\n", "\r"], '', json_encode($body, JSON_UNESCAPED_SLASHES));

        return [
            'Api-Key'   => $apiKey,
            'Timestamp' => $timestamp,
            'Signature' => SecurityHelper::generateSymmetricSignature(
                algo: 'sha256',
                data: implode(':', [
                    strtoupper($method),
                    $endpoint,
                    $apiKey,
                    hash('sha256', $minifiedBody),
                    $timestamp,
                ]),
                key: BagConfigHelper::bifast()['secret_key']
            ),
        ];
    }
}

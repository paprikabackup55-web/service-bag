<?php

namespace App\Services\Http;

use App\Enums\ResponseCode;
use App\Enums\ResponseCodeSnap;
use App\Helpers\LogHelper;
use Exception;
use GuzzleHttp\Exception\ConnectException;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\RequestException;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;
use InvalidArgumentException;
use Throwable;

abstract class BaseHttpService
{
    private $loggingOutgoingCall = null;

    abstract protected function throwApiException(
        ResponseCodeSnap|ResponseCode $errorCode,
        string $message,
        ?Throwable $previous = null
    ): never;

    abstract protected function generateHeaders(
        string $method,
        string $endpoint,
        ?array $body = [],
        ?string $accessToken = null
    ): array;

    protected function logHttpCall(string $message, ?Model $model = null): self
    {
        $this->loggingOutgoingCall = [
            'log_message' => $message,
            'log_model'   => $model,
        ];

        return $this;
    }

    protected function isLoggingCallEnabled(): bool
    {
        return config('services.http.logging');
    }

    protected function getRetryConfig(): array
    {
        return config('services.http.retry.default');
    }

    protected function handleFailedResponse(Response $response, string $method, string $url): void
    {
        $status = $response->status();
        $code = match ($status) {
            400 => ResponseCode::BadRequest,
            401 => ResponseCode::Unauthorized,
            403 => ResponseCode::Forbidden,
            404 => ResponseCode::NotFound,
            default => ResponseCode::GeneralError,
        };

        $message = "Request to {$url} failed with status {$status}";

        $this->throwApiException($code, $message);
    }

    protected function shouldRetryRequest(
        Exception $exception,
        PendingRequest $request,
        array $retryOnCodes
    ): bool {
        if ($exception instanceof ConnectionException) {
            return true;
        }

        if ($exception instanceof RequestException) {
            $status = $exception->response->status();

            if (in_array($status, $retryOnCodes)) {
                return true;
            }
        }

        return false;
    }

    protected function executeRequest(
        string $method,
        string $baseUrl,
        string $endpoint,
        ?array $query = null,
        ?array $body = null,
        ?string $accessToken = null
    ): Response {
        $url = $baseUrl.$endpoint;
        $headers = $this->generateHeaders($method, $endpoint, $body, $accessToken);

        try {
            $retryConfig = $this->getRetryConfig();

            $retryConfigCodes = $this->getRetryConfig()['retry_on_codes'];
            $retryOnCodes = array_map(
                'intval',
                is_array($retryConfigCodes) ? $retryConfigCodes : explode(',', $retryConfigCodes)
            );

            $http = Http::acceptJson()
                ->timeout($retryConfig['timeout'])
                ->withHeaders($headers)
                ->retry(
                    times: $retryConfig['attempts'],
                    sleepMilliseconds: $retryConfig['delay_ms'],
                    when: fn ($exception, $request) => $this->shouldRetryRequest($exception, $request, $retryOnCodes)
                );

            $logData = $this->loggingOutgoingCall;
            $this->loggingOutgoingCall = null;
            $isLogHttpCall = $logData !== null && $this->isLoggingCallEnabled();
            if ($isLogHttpCall) {
                $http->beforeSending(LogHelper::logOutgoingRequest($logData['log_message'], $logData['log_model']));
            }

            $response = match (strtoupper($method)) {
                'GET'    => $http->get(url: $url, query: $query),
                'POST'   => $http->post(url: $url, data: $body),
                'PUT'    => $http->put(url: $url, data: $body),
                'DELETE' => $http->delete(url: $url, data: $body),
                default  => throw new InvalidArgumentException("Unsupported HTTP method: {$method}"),
            };

            if ($isLogHttpCall) {
                LogHelper::logOutgoingResponse($logData['log_message'], $response, $logData['log_model']);
            }

            if ($response->failed()) {
                $this->handleFailedResponse($response, $method, $url);
            }

            return $response;
        } catch (ConnectException $e) {
            $this->throwApiException(ResponseCodeSnap::Timeout, "Request timed out: {$e->getMessage()}", $e);
        }
    }

    protected function callGet(string $baseUrl, string $endpoint, ?array $query = [], ?string $accessToken = null): Response
    {
        return $this->executeRequest('GET', $baseUrl, $endpoint, $query, null, $accessToken);
    }

    protected function callPost(string $baseUrl, string $endpoint, ?array $body = [], ?string $accessToken = null): Response
    {
        return $this->executeRequest('POST', $baseUrl, $endpoint, null, $body, $accessToken);
    }

    protected function callPut(string $baseUrl, string $endpoint, ?array $body = [], ?string $accessToken = null): Response
    {
        return $this->executeRequest('PUT', $baseUrl, $endpoint, null, $body, $accessToken);
    }

    protected function callDelete(string $baseUrl, string $endpoint, ?array $body = [], ?string $accessToken = null): Response
    {
        return $this->executeRequest('DELETE', $baseUrl, $endpoint, null, $body, $accessToken);
    }
}

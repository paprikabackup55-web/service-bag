<?php

namespace App\Locks;

use Illuminate\Http\Request;

class LockContextFactory
{
    /**
     * Create a ClientLockContext from the request.
     *
     * @param Request $request
     * @param string $bodyIdentifier
     * @return ClientLockContext
     */
    public static function createClientLockContext(Request $request, string $bodyIdentifier): ClientLockContext
    {
        return new ClientLockContext(
            'clients',
            $request->attributes->get('client')->id,
            $request->attributes->get('api_service_id'),
            $bodyIdentifier
        );
    }

    /**
     * Create a BagLockContext from the request.
     *
     * @param Request $request
     * @return BagLockContext
     */
    public static function createBagLockContext(Request $request): BagLockContext
    {
        return BagLockContext::fromRequest($request);
    }
}

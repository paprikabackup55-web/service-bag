<?php

namespace App\Locks;

use App\Exceptions\LockAcquisitionException;
use App\Helpers\BagConfigHelper;
use Illuminate\Cache\Lock;
use Illuminate\Support\Facades\Cache;

class LockManager
{
    public function createLock(string $key, int $lockDuration): Lock
    {
        $lock = Cache::lock($key, $lockDuration);
        if (! $lock->get()) {
            throw new LockAcquisitionException;
        }

        return $lock;
    }

    public function acquireClientLock(ClientLockContext $context, ?int $lockDuration = null): Lock
    {
        $key = $this->generateClientLockKey($context);
        if (! $lockDuration) {
            $lockDuration = BagConfigHelper::clientLockDuration() ?? 300;
        }

        return $this->createLock($key, $lockDuration);
    }

    public function acquireBagLock(BagLockContext $context, ?int $lockDuration = null): Lock
    {
        $key = $this->generateBagLockKey($context);
        if (! $lockDuration) {
            $lockDuration = BagConfigHelper::bagLockDuration() ?? 300;
        }

        return $this->createLock($key, $lockDuration);
    }

    protected function generateClientLockKey(ClientLockContext $context): string
    {
        return implode(':', [
            'clients',
            $context->clientId,
            $context->apiServiceId,
            $context->bodyIdentifier,
        ]);
    }

    protected function generateBagLockKey(BagLockContext $context): string
    {
        return implode(':', [
            'bag',
            $context->apiServiceId,
            $context->date,
            $context->externalId,
        ]);
    }
}

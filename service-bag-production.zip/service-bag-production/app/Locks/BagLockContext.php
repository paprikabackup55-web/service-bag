<?php

namespace App\Locks;

use Illuminate\Http\Request;


class BagLockContext
{
    public string $apiServiceId;
    public string $date;
    public string $externalId;

    public function __construct(string $apiServiceId, string $date, string $externalId)
    {
        $this->apiServiceId = $apiServiceId;
        $this->date         = $date;
        $this->externalId   = $externalId;
    }

    public static function fromRequest(Request $request): self
    {
        return new self(
            'bag',
            $request->attributes->get('api_service_id'),
            now()->format('ymd'),
            $request->header('X-EXTERNAL-ID')
        );
    }
}
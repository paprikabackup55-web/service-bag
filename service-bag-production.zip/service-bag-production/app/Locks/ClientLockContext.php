<?php

namespace App\Locks;

class ClientLockContext
{
    public string $clientId;
    public string $apiServiceId;
    public string $bodyIdentifier;

    public function __construct(string $clientId, string $apiServiceId, string $bodyIdentifier)
    {
        $this->clientId = $clientId;
        $this->apiServiceId = $apiServiceId;
        $this->bodyIdentifier = $bodyIdentifier;
    }
}

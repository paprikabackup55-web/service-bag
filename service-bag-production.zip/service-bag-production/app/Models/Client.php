<?php

namespace App\Models;

use App\Traits\HasLocalTimestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Client extends Model
{
    use HasFactory, HasLocalTimestamps;

    protected $hidden = ['client_api_key', 'private_key', 'public_key'];

    protected function casts(): array
    {
        return [
            'client_api_key' => 'encrypted',
            'private_key'    => 'encrypted',
            'public_key'     => 'encrypted'
        ];
    }

    public function ipAddresses(): HasMany
    {
        return $this->hasMany(ClientIpAddress::class, 'client_id', 'id');
    }

    public function disbursements(): HasMany
    {
        return $this->hasMany(Disbursement::class, 'client_id', 'id');
    }

    public function virtualAccounts() : HasMany {
        return $this->hasMany(VirtualAccount::class, 'client_id', 'id');
    }
}

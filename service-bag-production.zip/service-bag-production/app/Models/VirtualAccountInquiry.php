<?php

namespace App\Models;

use App\Traits\HasLocalTimestamps;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class VirtualAccountInquiry extends Model
{
    use HasFactory, HasLocalTimestamps;

    public function virtualAccount(): BelongsTo
    {
        return $this->belongsTo(VirtualAccount::class, 'virtual_account_id', 'id');
    }

    public function payment(): HasOne
    {
        return $this->hasOne(VirtualAccountPayment::class, 'inquiry_id', 'id');
    }

}

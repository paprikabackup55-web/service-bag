<?php

namespace App\Models;

use App\Enums\VirtualAccountStatus;
use App\Enums\VirtualAccountType;
use App\Traits\HasLocalTimestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class VirtualAccount extends Model
{
    use HasFactory, HasLocalTimestamps;

    protected $casts = [
        'type'       => VirtualAccountType::class,
        'status'     => VirtualAccountStatus::class,
        'expires_at' => 'datetime',
    ];

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class, 'client_id', 'id');
    }

    public function inquiries(): HasMany
    {
        return $this->hasMany(VirtualAccountInquiry::class, 'virtual_account_id', 'id');
    }

    public function payments(): HasMany
    {
        return $this->hasMany(VirtualAccountPayment::class, 'virtual_account_id', 'id');
    }

    public function applicationLogs(): MorphMany
    {
        return $this->morphMany(ApplicationLog::class, 'loggable');
    }
}

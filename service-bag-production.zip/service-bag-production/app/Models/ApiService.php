<?php

namespace App\Models;

use App\Traits\HasLocalTimestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ApiService extends Model
{
    use HasFactory, HasLocalTimestamps;

    const ACCOUNT_BALANCE               = 1;
    const ACCOUNT_STATEMENT             = 2;
    const DISBURSEMENT_INQUIRY_ACCOUNT  = 3;
    const DISBURSEMENT_TRANSFER         = 4;
    const DISBURSEMENT_INQUIRY_STATUS   = 5;
    const VIRTUAL_ACCOUNT_CREATE        = 6;
    const VIRTUAL_ACCOUNT_UPDATE        = 7;
    const VIRTUAL_ACCOUNT_DELETE        = 8;
    const ACCESS_TOKEN                  = 9;
    const VIRTUAL_ACCOUNT_INQUIRY       = 10;
    const VIRTUAL_ACCOUNT_PAYMENT       = 11;
    const VIRTUAL_ACCOUNT_NOTIFICATION  = 12;

    public function requestLogs(): HasMany
    {
        return $this->hasMany(RequestLog::class, 'api_service_id', 'id');
    }
}

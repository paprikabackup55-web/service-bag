<?php

namespace App\Models;

use App\Traits\HasLocalTimestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AccountStatement extends Model
{
    use HasFactory, HasLocalTimestamps;

    public $timestamps = false;
}

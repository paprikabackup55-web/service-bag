<?php

namespace App\Models;

use App\Traits\HasLocalTimestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class ApplicationLog extends Model
{
    use HasFactory, HasLocalTimestamps;

    public function requestLog(): BelongsTo
    {
        return $this->belongsTo(RequestLog::class, 'request_log_id', 'id');
    }

    public function loggable(): MorphTo
    {
        return $this->morphTo(__FUNCTION__, 'loggable_type', 'loggable_id');
    }
}

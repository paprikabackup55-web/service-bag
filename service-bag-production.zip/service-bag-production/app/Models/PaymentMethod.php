<?php

namespace App\Models;

use App\Traits\HasLocalTimestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PaymentMethod extends Model
{
    use HasFactory, HasLocalTimestamps;

    const INTRA     = 1;
    const INTER     = 2;
    const BI_FAST   = 3;
    const VA_OPEN   = 4;
    const VA_CLOSED = 5;

    public function disbursements(): HasMany
    {
        return $this->hasMany(Disbursement::class, 'payment_method_id', 'id');
    }
}

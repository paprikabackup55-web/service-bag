<?php

namespace App\Models;

use App\Traits\HasLocalTimestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Collection;

class ClientIpAddress extends Model
{
    use HasFactory, HasLocalTimestamps;

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class, 'client_id', 'id');
    }

    public function scopeContainingIp($query, $ip, ?int $clientId = null)
    {
        $query->whereRaw('? <<= value', [$ip]);

        if ($clientId !== null) {
            $query->where('client_id', $clientId);
        }

        return $query;
    }

    public function scopeContainingAnyIp($query, Collection $ips, ?int $clientId = null)
    {
        return $query->where(function ($q) use ($ips, $clientId) {
            $ips->each(fn ($ip) => $q->orWhere(fn ($sub) => $sub->containingIp($ip, $clientId)));
        });
    }

    public function scopeOverlappingRange($query, $cidr)
    {
        return $query->whereRaw('value && ?', [$cidr]);
    }
}

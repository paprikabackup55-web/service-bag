<?php

namespace App\Models;

use App\Enums\Currency;
use App\Enums\DisbursementStatus;
use App\Traits\HasLocalTimestamps;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class Disbursement extends Model
{
    use HasFactory, HasLocalTimestamps;

    protected $casts = [
        'status_code' => DisbursementStatus::class,
        'currency'    => Currency::class,
    ];

    protected function statusDesc(): Attribute
    {
        return Attribute::make(
            get: fn () => $this->status_code->getDesc()
        );
    }

    public function paymentMethod(): BelongsTo
    {
        return $this->belongsTo(PaymentMethod::class, 'payment_method_id', 'id');
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class, 'client_id', 'id');
    }

    public function applicationLogs(): MorphMany
    {
        return $this->morphMany(ApplicationLog::class, 'loggable');
    }
}

<?php

namespace App\Models;

use App\Enums\Currency;
use App\Enums\PaymentStatus;
use App\Traits\HasLocalTimestamps;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class VirtualAccountPayment extends Model
{
    use HasFactory, HasLocalTimestamps;

    protected $casts = [
        'status_code' => PaymentStatus::class,
        'currency'    => Currency::class,
    ];

    protected function statusDesc(): Attribute
    {
        return Attribute::make(
            get: fn(mixed $value, array $attributes) => match ($attributes['status_code']) {
                '00' => ['en' => 'Success', 'id' => 'Sukses'],
                '01' => ['en' => 'Reject', 'id' => 'Ditolak'],
                '02' => ['en' => 'Pending', 'id' => 'Pending'],
                default => ['en' => '', 'id' => '']
            }
        );
    }

    public function virtualAccount(): BelongsTo
    {
        return $this->belongsTo(VirtualAccount::class, 'virtual_account_id', 'id');
    }

    public function inquiry(): BelongsTo
    {
        return $this->belongsTo(VirtualAccountInquiry::class, 'inquiry_id', 'id');
    }
}

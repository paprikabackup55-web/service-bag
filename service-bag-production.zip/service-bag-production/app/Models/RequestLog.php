<?php

namespace App\Models;

use App\Traits\HasLocalTimestamps;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class RequestLog extends Model
{
    use HasFactory, HasLocalTimestamps;

    public function apiService(): BelongsTo
    {
        return $this->belongsTo(ApiService::class, 'api_service_id', 'id');
    }

    public function applicationLogs(): HasMany
    {
        return $this->hasMany(ApplicationLog::class, 'request_log_id', 'id');
    }
}

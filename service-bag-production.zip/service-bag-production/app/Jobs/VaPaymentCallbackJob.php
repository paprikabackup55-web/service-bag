<?php

namespace App\Jobs;

use App\Enums\LogLevel;
use App\Enums\ResponseCodeSnap;
use App\Exceptions\InternalServerException;
use App\Exceptions\VirtualAccount\BillNotFoundException;
use App\Exceptions\VirtualAccount\ExpiredBillException;
use App\Exceptions\VirtualAccount\InvalidAmountException;
use App\Helpers\LogHelper;
use App\Helpers\ResponseHelper;
use App\Models\VirtualAccount;
use App\Models\VirtualAccountPayment;
use App\Services\VirtualAccount\VaClientCallback;
use Exception;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Log;
use Throwable;

class VaPaymentCallbackJob implements ShouldQueue
{
    use Queueable;

    public $timeout = 30;

    public $tries = 3;

    public $backoff = [5, 10, 30];

    private VirtualAccount $va;

    /**
     * Create a new job instance.
     */
    public function __construct(private readonly int $vaPaymentId) {}

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        Log::Info("Callback VirtualAccountPayment with id={$this->vaPaymentId}");

        try {
            $vaPayment = VirtualAccountPayment::find($this->vaPaymentId);

            if (! $vaPayment) {
                throw new Exception("VirtualAccountPayment with id={$this->vaPaymentId} not found");
            }

            $this->va = $vaPayment->virtualAccount()->first();

            $vaClientCallback = new VaClientCallback($this->va->client);

            $response = $vaClientCallback->callbackPayment($vaPayment);

            LogHelper::create(LogLevel::Info, __METHOD__, $response, $this->va);
        } catch (ConnectionException $e) {
            LogHelper::create(LogLevel::Warning, __METHOD__, $e, $this->va);
            throw $e;
        } catch (Throwable $e) {
            LogHelper::create(LogLevel::Error, __METHOD__, $e, $this->va);
            throw $e;
        }

        if ($response->failed()) {
            LogHelper::create(LogLevel::Alert, 'Unexpected status from core-pg:'.__METHOD__, $response, $this->va);
            throw new Exception('Core Server Error');
        }

        $responseBody = $response->json() ?? [];
        $snapResponse = ResponseHelper::toSnapCode($responseBody['responseCode']);

        if ($snapResponse !== ResponseCodeSnap::Successful) {
            match ($snapResponse) {
                ResponseCodeSnap::TransactionExpired          => throw new ExpiredBillException,
                ResponseCodeSnap::TransactionNotFound         => throw new BillNotFoundException,
                ResponseCodeSnap::InvalidAmount               => throw new InvalidAmountException,
                ResponseCodeSnap::InvalidMandatoryField,
                ResponseCodeSnap::InvalidMerchant,
                ResponseCodeSnap::DuplicatePartnerReferenceNo => throw new InternalServerException,
                default                                       => throw new Exception('Unknown Error'),
            };
        }

        LogHelper::create(LogLevel::Debug, 'Callback VA Payment Success:', $response, $this->va);
    }

    public function failed(Throwable $exception)
    {
        LogHelper::create(LogLevel::Error, 'VaPaymentCallbackJob Error', $exception);
    }
}

<?php

namespace App\Exceptions;

use Exception;

class InternalServerException extends Exception
{
    protected $data;

    public function __construct($message = 'Internal Server Error', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

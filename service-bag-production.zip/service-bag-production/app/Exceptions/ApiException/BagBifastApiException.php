<?php

namespace App\Exceptions\ApiException;

use App\Enums\ResponseCode;
use Exception;
use Throwable;

class BagBifastApiException extends Exception
{
    public function __construct(
        public readonly ResponseCode $errorCode,
        string $message = '',
        ?Throwable $previous = null
    ) {
        parent::__construct($message ?: $errorCode->getMessage(), $errorCode->getStatus(), $previous);
    }
}

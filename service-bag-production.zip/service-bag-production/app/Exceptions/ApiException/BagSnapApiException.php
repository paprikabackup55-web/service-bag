<?php

namespace App\Exceptions\ApiException;

use App\Enums\ResponseCodeSnap;
use Exception;
use Throwable;

class BagSnapApiException extends Exception
{
    public function __construct(
        public readonly ResponseCodeSnap $errorCode,
        string $message = '',
        ?Throwable $previous = null
    ) {
        parent::__construct($message ?: $errorCode->getMessage(), $errorCode->getStatus(), $previous);
    }
}

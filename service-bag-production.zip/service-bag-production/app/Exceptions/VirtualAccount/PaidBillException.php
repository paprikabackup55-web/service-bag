<?php

namespace App\Exceptions\VirtualAccount;

use Exception;

class PaidBillException extends Exception
{
    protected $data;

    public function __construct($message = 'Bill Already Paid', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

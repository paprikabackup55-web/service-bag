<?php

namespace App\Exceptions\VirtualAccount;

use Exception;

class InvalidAmountException extends Exception
{
    protected $data;

    public function __construct($message = 'Invalid Amount', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

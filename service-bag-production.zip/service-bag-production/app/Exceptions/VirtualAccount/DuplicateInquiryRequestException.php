<?php

namespace App\Exceptions\VirtualAccount;

use Exception;

class DuplicateInquiryRequestException extends Exception
{
    protected $data;

    public function __construct($message = 'Duplicate Inquiry Request', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

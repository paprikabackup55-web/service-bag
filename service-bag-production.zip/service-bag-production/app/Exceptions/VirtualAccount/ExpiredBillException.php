<?php

namespace App\Exceptions\VirtualAccount;

use Exception;

class ExpiredBillException extends Exception
{
    protected $data;

    public function __construct($message = 'Bill Expired', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

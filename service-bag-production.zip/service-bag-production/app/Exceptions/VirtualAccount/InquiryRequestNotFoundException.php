<?php

namespace App\Exceptions\VirtualAccount;

use Exception;

class InquiryRequestNotFoundException extends Exception
{
    protected $data;

    public function __construct($message = 'Inquiry Request Not Found', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

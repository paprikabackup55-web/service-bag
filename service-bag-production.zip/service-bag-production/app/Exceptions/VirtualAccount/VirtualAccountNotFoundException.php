<?php

namespace App\Exceptions\VirtualAccount;

use Exception;

class VirtualAccountNotFoundException extends Exception
{
    protected $data;

    public function __construct($message = 'Virtual Account Not Found', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

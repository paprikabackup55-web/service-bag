<?php

namespace App\Exceptions\VirtualAccount;

use Exception;

class BillNotFoundException extends Exception
{
    protected $data;

    public function __construct($message = 'Bill Not Found', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

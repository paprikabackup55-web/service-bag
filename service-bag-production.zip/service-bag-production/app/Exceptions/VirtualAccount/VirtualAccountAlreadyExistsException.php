<?php

namespace App\Exceptions\VirtualAccount;

use Exception;

class VirtualAccountAlreadyExistsException extends Exception
{
    protected $data;

    public function __construct($message = 'Virtual Account Already Exists', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }

    
}

<?php

namespace App\Exceptions\VirtualAccount;

use Exception;

class InvalidExpirationDateException extends Exception
{
    protected $data;

    public function __construct($message = 'Invalid expiration date', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

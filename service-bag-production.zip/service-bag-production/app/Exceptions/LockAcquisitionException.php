<?php

namespace App\Exceptions;

use Exception;

class LockAcquisitionException extends Exception
{
    protected $data;

    public function __construct($message = 'Could not acquire lock', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

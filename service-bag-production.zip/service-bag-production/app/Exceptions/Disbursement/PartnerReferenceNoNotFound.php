<?php

namespace App\Exceptions\Disbursement;

use Exception;

class PartnerReferenceNoNotFound extends Exception
{
    protected $data;

    public function __construct($message = 'Partner Reference Number Not Found', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

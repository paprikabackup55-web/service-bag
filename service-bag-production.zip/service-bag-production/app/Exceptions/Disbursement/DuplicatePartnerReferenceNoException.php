<?php

namespace App\Exceptions\Disbursement;

use Exception;

class DuplicatePartnerReferenceNoException extends Exception
{
    protected $data;

    public function __construct($message = 'Duplicate Partner Reference Number', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

<?php

namespace App\Exceptions\Disbursement;

use Exception;

class InvalidDisbursementStatus extends Exception
{
    protected $data;

    public function __construct($message = 'Invalid Disbursement Status', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }

    public function getData()
    {
        return $this->data;
    }
}

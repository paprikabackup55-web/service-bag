<?php

namespace App\Exceptions\Disbursement;

use Exception;

class PaymentMethodNotFound extends Exception
{
    protected $data;

    public function __construct($message = 'Payment Method Not Found', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}

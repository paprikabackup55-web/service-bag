<?php

namespace App\Exceptions;

use Exception;

class GetAccessTokenException extends Exception
{
    protected $data;

    public function __construct($message = 'Get Access Token Failed', $data = [])
    {
        parent::__construct($message);
        $this->data = $data;
    }
}
<?php

namespace App\Helpers;

class BagConfigHelper
{
    public const BASE_URL             = 'services.bag.snap.base_url';
    public const ACCOUNT_NO           = 'services.bag.account_no';
    
    // va
    public const VA_LENGTH            = 'services.bag.snap.va.length';
    public const VA_PREFIX_OPEN       = 'services.bag.snap.va.prefix_open';
    public const VA_PREFIX_CLOSED     = 'services.bag.snap.va.prefix_closed';
    public const VA_PREFIX_REF_NUMBER = 'services.bag.snap.va.prefix_reference_number';  //?
    
    // inbound
    public const INBOUND_CLIENT_NAME   = 'services.bag.snap.inbound.client_name';
    public const INBOUND_CLIENT_ID     = 'services.bag.snap.inbound.client_id';
    public const INBOUND_CLIENT_SECRET = 'services.bag.snap.inbound.client_secret';

    // outbound
    public const OUTBOUND_CLIENT_ID     = 'services.bag.snap.outbound.client_id';
    public const OUTBOUND_CLIENT_SECRET = 'services.bag.snap.outbound.client_secret';
    public const OUTBOUND_PARTNER_ID    = 'services.bag.snap.outbound.partner_id';     //?
    public const OUTBOUND_CHANNEL_ID    = 'services.bag.snap.outbound.channel_id';     //?
    
    // lock
    public const CLIENT_LOCK_DURATION = 'services.bag.client_lock_duration';
    public const BAG_LOCK_DURATION    = 'services.bag.vendor_lock_duration';

    // BIFAST
    public const BIFAST_BASE_URL      = 'services.bag.non_snap.base_url';
    public const BIFAST_API_KEY       = 'services.bag.non_snap.api_key';
    public const BIFAST_SECRET_KEY    = 'services.bag.non_snap.secret_key';
    public const BIFAST_MERCHANT_ID   = 'services.bag.non_snap.merchant_id';

    
    public static function get(string $key): string
    {
        return config($key);
    }

    public static function baseUrl(): string
    {
        return self::get(self::BASE_URL);
    }

    public static function accountNo(): string
    {
        return self::get(self::ACCOUNT_NO);
    }

    // bag credentials
    public static function inbound(): array
    {
        return [
            'client_name'   => self::get(self::INBOUND_CLIENT_NAME),
            'client_id'     => self::get(self::INBOUND_CLIENT_ID),
            'client_secret' => self::get(self::INBOUND_CLIENT_SECRET)
        ];
    }

    // paprika credentials
    public static function outbound(): array
    {
        return [
            'client_secret' => self::get(self::OUTBOUND_CLIENT_SECRET),
            'client_id'     => self::get(self::OUTBOUND_CLIENT_ID),
            'partner_id'    => self::get(self::OUTBOUND_PARTNER_ID),
            'channel_id'    => self::get(self::OUTBOUND_CHANNEL_ID),
        ];
    }

    public static function va(): array
    {
        return [
            'length'            => self::get(self::VA_LENGTH),
            'prefix_open'       => self::get(self::VA_PREFIX_OPEN),
            'prefix_closed'     => self::get(self::VA_PREFIX_CLOSED),
            'prefix_ref_number' => self::get(self::VA_PREFIX_REF_NUMBER) ? : 'BAG',
        ];
    }

    public static function bifast(): array
    {
        return [
            'base_url'    => self::get(self::BIFAST_BASE_URL),
            'api_key'     => self::get(self::BIFAST_API_KEY),
            'secret_key'  => self::get(self::BIFAST_SECRET_KEY),
            'merchant_id' => self::get(self::BIFAST_MERCHANT_ID)
        ];
    }

    public static function clientLockDuration(): int
    {
        return self::get(self::CLIENT_LOCK_DURATION);
    }

    public static function bagLockDuration(): int
    {
        return self::get(self::BAG_LOCK_DURATION);
    }
}

<?php

namespace App\Helpers;

use App\Enums\VirtualAccountType;
use App\Models\VirtualAccount;
use App\Models\VirtualAccountPayment;
use Carbon\Carbon;
use Illuminate\Http\Request;

class ResponsePayloadHelper
{
    public static function snapInquiryPayload(
        Request $request,
        string $status,
        string $englishReason,
        string $indonesianReason,
        ?VirtualAccount $virtualAccount = null
    ): array {
        $vaType = $virtualAccount->type;

        $amountValue    = $virtualAccount->amount;
        $amountCurrency = $virtualAccount->currency;

        $vaTrxType = $vaType === VirtualAccountType::OPEN_PAYMENT ? '0' : $virtualAccount->type->value;

        return [
            'virtualAccountData' => [
                'inquiryStatus' => $status,   //O
                'inquiryReason' => [
                    'english'   => $englishReason,
                    'indonesia' => $indonesianReason,
                ], //O
                'inquiryRequestId'      => $request->inquiryRequestId,     //M
                'partnerServiceId'      => $request->partnerServiceId,     //M
                'customerNo'            => $request->customerNo,           //M
                'virtualAccountNo'      => $request->virtualAccountNo,     //M
                'virtualAccountName'    => $virtualAccount->name,          //M
                'virtualAccountEmail'   => '',
                'virtualAccountPhone'   => '',
                'virtualAccountTrxType' => $vaTrxType,
                'totalAmount'           => [
                    'value'    => $status === '00' ? $amountValue : '0',
                    'currency' => $status === '00' ? $amountCurrency : 'IDR',
                ],
                'feeAmount' => [
                    'value'    => '0.00',
                    'currency' => 'IDR',
                ],
                'freeTexts' => [
                    'english'   => '',
                    'indonesia' => '',
                ],
                'billDetails' => [
                    'billCode'        => '',
                    'billNo'          => '',
                    'billName'        => '',
                    'billShortName'   => '',
                    'billDescription' => [
                        'english'   => '',
                        'indonesia' => '',
                    ],
                    'billSubCompany' => '',
                    'billAmount'     => [
                        'value'    => '0.00',
                        'currency' => 'IDR'
                    ],
                    'billAmountLabel' => '',
                    'billAmountValue' => '',
                ],
                'additionalInfo' => [
                    'merchantId' => $request->additionalInfo['merchantId'] ?? '',
                    'channel'    => $request->additionalInfo['channel'] ?? '',
                ],
            ],
        ];
    }

    public static function snapPaymentPayload(
        Request $request,
        string $status,
        string $englishReason,
        string $indonesianReason
    ): array {
        return [
            'virtualAccountData' => [
                'paymentFlagStatus' => $status,
                'paymentFlagReason' => [
                    'english'   => $englishReason,
                    'indonesia' => $indonesianReason,
                ],
                'partnerServiceId'   => $request->partnerServiceId,
                'customerNo'         => $request->customerNo,
                'virtualAccountNo'   => $request->virtualAccountNo,
                'virtualAccountName' => $status === '00' ? $request->virtualAccountName : '',
                'paymentRequestId'   => $request->paymentRequestId,
                'paidAmount'         => [
                    'value'    => $status === '00' ? $request->paidAmount['value'] : '',
                    'currency' => $status === '00' ? $request->paidAmount['currency'] : '',
                ],
                'totalAmount' => [
                    'value'    => $status === '00' ? $request->totalAmount['value'] : '',
                    'currency' => $status === '00' ? $request->totalAmount['currency'] : '',
                ],
                'referenceNo' => $request->referenceNo ?? '',
                'paymentType' => $request->paymentType ?? '',
                'trxDateTime' => $request->trxDateTime ?? now()->format('c'),
            ],
        ];
    }

    public static function snapNotificationPayload(
        Request $request,
        VirtualAccountPayment $payment,
        string $status,
        string $englishReason,
        string $indonesianReason
    ): array {
        return [
            'virtualAccountData' => [
                'paymentFlagReason' => [
                    'english'   => $englishReason,
                    'indonesia' => $indonesianReason,
                ],
                'partnerServiceId'   => str_pad($request->partnerServiceId, 8, " ", STR_PAD_LEFT),
                'customerNo'         => $request->customerNo,
                'virtualAccountNo'   => $request->virtualAccountNo,
                'inquiryRequestId'   => $request->paymentRequestId,
                'paymentRequestId'   => $request->paymentRequestId,
                'partnerReferenceNo' => $request->partnerReferenceNo,
                'trxDateTime'        => $status === '00' ?
                    Carbon::createFromFormat('Y-m-d H:i:s', $payment->updated_at)->format('c'): '',
                'paymentStatus'  => $status,
                'additionalInfo' => [
                    'merchantId'        => $request->merchantId ?? '',
                    'amount'            => $status === '00' ? $payment->amount : '',
                    'procode'           => $request->procode ?? '',
                    'flagAmountCheck'   => $request->flagAmountCheck ?? '',
                    'destinationVAName' => $request->destinationVAName ?? '',
                    'referenceNo'       => $status === '00' ? $payment->reference_no : '',
                    'orderId'           => $request->orderId ?? '',
                    'sourceBankCode'    => $status === '00' ? ($payment->source_bank_code ?? '') : '',
                    'sourceName'        => $status === '00' ? ($payment->source_account_name ?? '') : '',
                    'sourceAccount'     => $status === '00' ? ($payment->source_account_no ?? '') : '',
                    'description'       => $request->description ?? '',
                ],
            ],
        ];
    }
}

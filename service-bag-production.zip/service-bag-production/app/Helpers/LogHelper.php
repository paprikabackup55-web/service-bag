<?php

namespace App\Helpers;

use App\Enums\LogLevel;
use App\Models\ApplicationLog;
use App\Models\Disbursement;
use App\Models\VirtualAccount;
use Illuminate\Http\Client\Request;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Arr;
use Throwable;

class LogHelper
{
    public static function create(
        LogLevel $level,
        string $message,
        Throwable|Response|Request|array $context,
        Disbursement|VirtualAccount|null $model = null
    ): ApplicationLog {
        $context = static::context($context);

        $applicationLogdata = [
            'level'   => $level,
            'message' => $message,
            'context' => json_encode($context, JSON_UNESCAPED_SLASHES),
        ];

        $request = app()->bound('request') ? request() : null;

        if (! is_null($request)) {
            $applicationLogdata['request_log_id'] = $request->attributes->get('request_log_id');
        }

        $applicationLog = ApplicationLog::create($applicationLogdata);

        if (! is_null($model)) {
            $applicationLog->loggable()->associate($model)->save();
        }

        return $applicationLog;
    }

    public static function logOutgoingRequest(
        string $message,
        Disbursement|VirtualAccount|null $model = null
    ): callable {
        return function (Request $outgoingRequest) use ($message, $model) {
            static::create(LogLevel::Info, 'Outgoing Request:'.$message, $outgoingRequest, $model);
        };
    }

    public static function logOutgoingResponse(
        string $message,
        Response $response,
        Disbursement|VirtualAccount|null $model = null
    ): void {
        static::create(LogLevel::Info, 'Outgoing Response:'.$message, $response, $model);
    }

    public static function context(Throwable|Response|Request|array $data): array
    {
        if (is_array($data)) {
            return $data;
        }

        if ($data instanceof Throwable) {
            $appTraceOrigin = collect($data->getTrace())->filter(
                fn ($item) => isset($item['file']) && ! str_contains($item['file'], base_path('vendor'))
            )
                ->map(fn ($item) => Arr::only($item, ['file', 'line']))
                ->first();

            $appTraceOrigin = $appTraceOrigin && isset($appTraceOrigin['file'])
                ? ['file' => basename($appTraceOrigin['file']), 'line' => $appTraceOrigin['line'] ?? null]
                : ['file' => 'No application trace found', 'line' => null];

            return [
                'class'     => get_class($data),
                'message'   => $data->getMessage(),
                'file'      => basename($data->getFile()),
                'app_trace' => json_encode($appTraceOrigin, JSON_UNESCAPED_SLASHES),
            ];
        }

        if ($data instanceof Request) {
            return [
                'url'     => $data->url(),
                'headers' => $data->headers(),
                'body'    => $data->body(),
            ];
        }

        return [
            'status' => $data->status(),
            'body'   => $data->json() ?? $data->body(),
        ];
    }
}

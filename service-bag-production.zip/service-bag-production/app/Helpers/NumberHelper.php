<?php

namespace App\Helpers;

class NumberHelper
{
    public static function random(int $length): string
    {
        $number = '';

        for ($i = 1; $i <= $length; $i++) {
            $number .= rand(0, 9);
        }

        return $number;
    }

    public static function decimal(int|float $value, bool $shouldRounded = false): string
    {
        return number_format(
            num: $shouldRounded ? explode('.', (string) $value)[0] : $value,
            decimals: 2,
            thousands_separator: ''
        );
    }
}

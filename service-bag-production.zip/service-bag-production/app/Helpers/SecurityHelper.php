<?php

namespace App\Helpers;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use Illuminate\Http\Request;
use Illuminate\Encryption\Encrypter;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Storage;

class SecurityHelper
{
    public static function encrypt(string $data, ?string $key = null): string
    {
        if (is_null($key)) {
            return Crypt::encryptString($data);
        }

        return (new Encrypter($key, 'aes-256-cbc'))->encryptString($data);
    }

    public static function decrypt(string $data, ?string $key = null): string
    {
        if (is_null($key)) {
            return Crypt::decryptString($data);
        }

        return (new Encrypter($key, 'aes-256-cbc'))->decryptString($data);
    }

    public static function getIpAddresses(Request $request): array
    {
        return collect($request->ip())
            ->merge(explode(',', $request->header('x-forwarded-for', '')))
            ->transform(fn ($item) => trim($item))
            ->filter()
            ->unique()
            ->toArray();
    }

    public static function generateAsymmetricKey(): array
    {
        $options = [
            'digest_alg' => 'sha256',
            'private_key_bits' => 2048,
            'private_key_type' => OPENSSL_KEYTYPE_RSA,
        ];

        $key = openssl_pkey_new($options);

        openssl_pkey_export(key: $key, output: $privateKey, options: $options);

        return [
            'private' => $privateKey,
            'public' => openssl_pkey_get_details($key)['key'],
        ];
    }

    public static function getPublicKey(string $privateKey): string
    {
        return openssl_pkey_get_details(openssl_get_privatekey($privateKey))['key'];
    }

    public static function generateAsymmetricSignature(string $data, string $privateKey): string
    {
        openssl_sign($data, $signature, $privateKey, OPENSSL_ALGO_SHA256);

        return base64_encode($signature);
    }

    public static function verifyAsymmetricSignature(string $data, string $signature, string $publicKey): int|false
    {
        return openssl_verify($data, base64_decode($signature), $publicKey, OPENSSL_ALGO_SHA256);
    }

    public static function generateSymmetricSignature(string $algo, string $data, string $key): string
    {
        return hash_hmac($algo, $data, $key);
    }

    public static function verifySymmetricSignature(string $algo, string $data, string $key, string $signature): bool
    {
        return hash_equals(static::generateSymmetricSignature($algo, $data, $key), $signature);
    }

    public static function generateJwt(string $subject, string $audience, int $lifetime = 900): string
    {
        $now = now();

        return JWT::encode(
            payload: [
                'iss' => config('app.url'),
                'sub' => $subject,
                'aud' => $audience,
                'exp' => $now->clone()->addSeconds($lifetime)->timestamp,
                'nbf' => $now->timestamp,
                'iat' => $now->timestamp,
                'jti' => (string) str()->uuid(),
            ],
            key: config('services.jwt.key'),
            alg: 'HS256'
        );
    }

    public static function verifyJwt(string $jwt): object
    {
        return JWT::decode($jwt, new Key(config('services.jwt.key'), 'HS256'));
    }
}

<?php

namespace App\Helpers;

use App\Enums\ResponseCode;
use App\Enums\ResponseCodeSnap;
use Illuminate\Http\JsonResponse;

class ResponseHelper
{
    public static function generate(
        ResponseCode|ResponseCodeSnap $code,
        ?string $message = null,
        array $data = [],
        ?string $context = null,
    ): JsonResponse {
        $responseMessage = $message ?? $code->getMessage();
        return response()->json(
            data: array_merge([
                'responseCode' => $code->getCode(),
                'responseMessage' => trim($responseMessage . ' ' . $context),
            ], $data),
            status: $code->getStatus()
        );
    }

    public static function paginate(
        array $items,
        int $currentPage,
        int $lastPage,
        int $perPage,
        int $totalItems,
        ?string $message = null,
        array $data = [],
    ): JsonResponse {
        return self::generate(
            code: ResponseCode::Ok,
            message: $message,
            data: array_merge($data, [
                'items' => $items,
                'currentPage' => $currentPage,
                'lastPage' => $lastPage,
                'perPage' => $perPage,
                'totalItems' => $totalItems,
            ])
        );
    }

    public static function normalizeCode(string $code): string
    {
        return substr($code, 0, 3) . substr($code, strlen($code) - 2, strlen($code));
    }

    public static function toSnapCode(string $code): ResponseCodeSnap
    {
        $code = ResponseHelper::normalizeCode($code);
        return ResponseCodeSnap::from($code);
    }
}

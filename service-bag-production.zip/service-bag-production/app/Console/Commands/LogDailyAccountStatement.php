<?php

namespace App\Console\Commands;

use App\Enums\LogLevel;
use App\Helpers\LogHelper;
use App\Models\AccountStatement;
use App\Services\Account\AccountService;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Throwable;

class LogDailyAccountStatement extends Command
{
    protected $signature = 'app:daily-statement';

    protected $description = 'Log daily account statement';

    private AccountService $accountService;

    public function __construct(AccountService $accountService)
    {
        parent::__construct();
        $this->accountService = $accountService;
    }

    public function handle()
    {
        $schedule = Cache::get('schedules:account-statement', now()->subDays(3)->toDateString());
        $date = Carbon::createFromFormat('Y-m-d', $schedule);
        $isStatementExists = AccountStatement::whereDate('created_at', $date)->exists();

        if ($date->lessThan(now()) && ! $isStatementExists) {
            $this->collectAccountStatement($date);
        }

        Cache::put('schedules:account-statement', $date->addDay()->toDateString());
    }

    private function collectAccountStatement(string $date)
    {
        DB::beginTransaction();
        $page = 1;
        $isError = false;
        do {
            try {
                $detailData = $this->accountService->getStatement($date, $date, $page, 3);

                $statement = collect($detailData)->transform(function ($item) {
                    return [
                        'status' => $item['status'],
                        'reference_no' => $item['additionalInfo']['trxIdCore'],
                        'type' => $item['type'],
                        'start_balance' => $item['amount']['value'],
                        'amount' => $item['sourceOfFunds']['amount']['value'],
                        'currency' => $item['sourceOfFunds']['amount']['currency'],
                        'remark' => $item['remark'],
                        'transaction_date' => $item['dateTime'],
                    ];
                })->toArray();

                DB::table('account_statements')->insert($statement);

            } catch (Throwable $th) {
                $isError = true;
                LogHelper::create(LogLevel::Warning, $this->description, $th);
            }

            $page++;
        } while (! $isError);

        if ($isError) {
            DB::rollBack();

            return;
        }

        DB::commit();
    }
}

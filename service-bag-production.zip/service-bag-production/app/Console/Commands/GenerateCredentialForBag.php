<?php

namespace App\Console\Commands;

use App\Helpers\SecurityHelper;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

class GenerateCredentialForBag extends Command
{
    protected $signature = 'app:generate-credential-for-bag {--force : Overwrite existing credential files}';

    protected $description = 'Generate Paprika credentials to share with BAG (client key, client secret, and RSA key pair)';

    private const OUTPUT_DIR = 'credentials/for-bag';

    private const CREDENTIAL_FILE = 'paprika-bag-credential.txt';

    public function handle(): int
    {
        $outputDir = self::OUTPUT_DIR;
        $credentialPath = "{$outputDir}/" . self::CREDENTIAL_FILE;
        $privateKeyPath = "{$outputDir}/private.pem";
        $publicKeyPath = "{$outputDir}/public.pem";

        if (! $this->option('force') && $this->outputFilesExist($credentialPath, $privateKeyPath, $publicKeyPath)) {
            $this->error('Credential files already exist. Use --force to overwrite.');

            return Command::FAILURE;
        }

        $clientKey = (string) str()->uuid();
        $clientSecret = base64_encode((string) str()->uuid());
        $keys = SecurityHelper::generateAsymmetricKey();

        Storage::disk('local')->makeDirectory($outputDir);
        Storage::disk('local')->put($privateKeyPath, $keys['private']);
        Storage::disk('local')->put($publicKeyPath, $keys['public']);
        Storage::disk('local')->put($credentialPath, $this->buildCredentialContent(
            clientKey: $clientKey,
            clientSecret: $clientSecret,
            publicKey: $keys['public'],
        ));

        $this->info('BAG credentials generated successfully.');
        $this->line("  Credential file : storage/app/private/{$credentialPath}");
        $this->line("  Private key     : storage/app/private/{$privateKeyPath}");
        $this->line("  Public key      : storage/app/private/{$publicKeyPath}");

        return Command::SUCCESS;
    }

    private function outputFilesExist(string ...$paths): bool
    {
        return collect($paths)->contains(fn (string $path) => Storage::disk('local')->exists($path));
    }

    private function buildCredentialContent(string $clientKey, string $clientSecret, string $publicKey): string
    {
        return implode(PHP_EOL, [
            'Client Key: ' . $clientKey,
            'Client Secret (base64): ' . $clientSecret,
            'Public Key (PKCS#8):',
            trim($publicKey),
            '',
        ]);
    }
}
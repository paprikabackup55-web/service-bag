<?php

namespace App\Console\Commands;

use App\Helpers\SecurityHelper;
use App\Models\Client;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use InvalidArgumentException;

class ExchangeCredentialWithClient extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:exchange-credential-with-client {clientId}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Automate credentials sharing with Client (e.g. Core-PG). Store credential from Client and generate credential for Client';

    /**
     * Execute the console command.
     */
    public function handle()
    {

        // Find Client from input
        if (! $client = $this->findClientFromArgument()) {
            return Command::INVALID;
        }

        // Find File Name based on Found Client Name
        $dir = 'credentials/from-client';
        if (! $credentialFileName = $this->getLatestCredentialFileName($dir, $client->name)) {
            return Command::FAILURE;
        }

        DB::beginTransaction();
        try {
            // Get Client Credential From Found File
            $key = $this->askingForEncryptionKey();
            $data = Storage::disk('local')->get($credentialFileName);
            $content = SecurityHelper::decrypt($data, $key);
            $credentialArray = (array) json_decode($content);

            // Update Client's Credential
            $client->client_api_key = $credentialArray['api_key'];
            $client->public_key = $credentialArray['public_key'];
            $client->save();

            // Generate Credential For Client for this Vendor Service
            $apiKey = $client->api_key;
            $generatedPublicKey = SecurityHelper::getPublicKey($client->private_key);
            $credForClient = json_encode([
                'api_key' => $apiKey,
                'public_key' => $generatedPublicKey,
            ]);
            $content = SecurityHelper::encrypt($credForClient, $key);

            $parts = explode('-', basename($credentialFileName));
            $fileName = implode('-', [$parts[1], $parts[0], date('Ymd_His')]);

            $path = implode('/', array_filter(['credentials', 'for-client', $fileName]));
            Storage::disk('local')->put(path: $path, contents: $content);
        } catch (Exception $e) {
            DB::rollBack();
            $this->error("Exchange credential from {$credentialFileName} failed : {$e->getMessage()}");

            return Command::FAILURE;
        }

        DB::commit();

        $this->info("Credential for client {$client->name} is generated successfully to : $path");
        Command::SUCCESS;
    }

    private function findClientFromArgument(): ?Client
    {
        $input = trim($this->argument('clientId'));
        if (! is_numeric($input)) {
            $this->error('Invalid input. Please provide a client ID.');

            return null;
        }

        $client = Client::find($input);
        if (!$client) {
            $this->error("Client with Id {$input} not found.");

            return null;
        }

        return $client;
    }

    private function getLatestCredentialFileName(string $dir, string $clientName): ?string
    {
        $files = Storage::disk('local')->files($dir);
        $clientName = Str::snake(strtolower($clientName));

        $fileName = collect($files)
            ->filter(function ($file) use ($clientName) {
                return str_contains($clientName, strtolower(explode('-', basename($file))[0]));
            })
            ->sort(function ($a, $b) {
                $partsA = explode('-', $a);
                $partsB = explode('-', $b);
                $timestampA = $partsA[count($partsA) - 1];
                $timestampB = $partsB[count($partsB) - 1];

                return strtotime($timestampA) <=> strtotime($timestampB);
            })
            ->values()->last();

        if (is_null($fileName)) {
            $this->error("Credential File From Client {$clientName} not found");
            return null;
        }

        return $fileName;
    }

    private function askingForEncryptionKey(): string
    {
        $password = $this->secret('Please enter your password (alpha-numeric):');
        throw_if(
            ! ctype_alnum($password),
            InvalidArgumentException::class,
            'Password must be alpha-numeric characters.'
        );

        $this->info('Your password has been securely entered.');

        return substr(str_repeat($password, ceil(32 / strlen($password))), 0, 32);
    }
}

<?php

namespace App\Console\Commands;

use App\Enums\LogLevel;
use App\Helpers\LogHelper;
use App\Models\VirtualAccountPayment;
use App\Services\VirtualAccount\VaClientCallback;
use Illuminate\Console\Command;
use Throwable;

class RetryVaPaymentCallback extends Command
{
    protected $signature = 'app:retry-va-payment-callback';

    protected $description = 'Retry Virtual Account Payment callback';

    private VaClientCallback $vaClientCallback;

    public function __construct(VaClientCallback $vaClientCallback)
    {
        parent::__construct();
        $this->vaClientCallback = $vaClientCallback;
    }

    public function handle()
    {
        $commandDesc = $this->description;
        $vaPayments = VirtualAccountPayment::query()
            ->whereNull('callback_received_at')
            // ->where('callback_retry_count', '<', 5)
            ->orderBy('id')
            ->limit(5)
            ->get();

        foreach ($vaPayments as $payment) {
            $va = $payment->virtualAccount()->first();
            try {
                $response = $this->vaClientCallback->callbackPayment($payment);
                LogHelper::create(LogLevel::Info, $commandDesc, $response, $va);
            } catch (Throwable $th) {
                LogHelper::create(LogLevel::Error, $commandDesc, $th, model: $va);
            }
        }
    }
}

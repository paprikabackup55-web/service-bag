<?php

namespace App\Http\Middleware;

use App\Helpers\SecurityHelper;
use App\Models\RequestLog;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class LogRequest
{
    public function handle(Request $request, Closure $next): Response
    {
        $requestLog = RequestLog::create([
            'ip_addresses' => json_encode(SecurityHelper::getIpAddresses($request)),
            'request_headers' => json_encode($request->header()),
            'request_payload' => json_encode($request->all()),
            'api_service_id' => $request->attributes->get('api_service_id')
        ]);

        $request->attributes->set('request_log_id', $requestLog->id);

        $response = $next($request);

        $startTime = defined('LARAVEL_START') ? LARAVEL_START : $request->server('REQUEST_TIME_FLOAT');

        $responseBody = $response->getContent();

        if (! is_string($responseBody) || mb_strlen($responseBody) >= 64000) {
            $responseBody = 'Content too large / Invalid content type';
        }

        $requestLog->update([
            'response_status' => $response->getStatusCode(),
            'response_body' => $responseBody,
            'duration' => isset($startTime) ? round((microtime(true) - $startTime) * 1000) : 0,
            'memory' => round(memory_get_peak_usage(true) / 1024 / 1024),
        ]);

        return $response;
    }
}

<?php

namespace App\Http\Middleware;

use App\Models\ApiService;
use Closure;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\HttpFoundation\Response;

class SetApiService
{
    const API_SERVICES_TAG = 'api-services';

    public function handle(Request $request, Closure $next, int $id): Response
    {
        $apiServices = Cache::tags(self::API_SERVICES_TAG)->remember(
            key     : implode(':', ['api_services']),
            ttl     : 3600 * 3,
            callback: fn () => ApiService::select(['id', 'code'])->get()
        );

        $apiService = $apiServices->filter(fn ($apiSvc) => $apiSvc->id === $id)
            ->first() ?? throw new Exception('Invalid API service');

        $request->attributes->set('api_service_id', $apiService->id);
        $request->attributes->set('api_service_code', $apiService->code);

        return $next($request);
    }
}

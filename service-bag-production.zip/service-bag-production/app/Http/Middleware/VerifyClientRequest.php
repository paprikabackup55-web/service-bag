<?php

namespace App\Http\Middleware;

use Closure;
use Exception;
use App\Models\Client;
use App\Enums\ResponseCode;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Helpers\ResponseHelper;
use App\Helpers\SecurityHelper;
use App\Models\ClientIpAddress;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Artisan;
use Symfony\Component\HttpFoundation\Response;

class VerifyClientRequest
{
    private const CLIENT_TAG = 'client';

    private const HEADERS = [
        'API_KEY'   => 'X-API-KEY',
        'TIMESTAMP' => 'X-TIMESTAMP',
        'SIGNATURE' => 'X-SIGNATURE',
    ];

    public function handle(Request $request, Closure $next): Response
    {
        $headers = $this->getHeaders($request);

        if (app()->environment(['local', 'develop', 'staging'])) {
            $request->attributes->set('client', Client::find(1));

            return $next($request);
        }

        if ($validationResponse = $this->validateHeaders($headers)) {
            return $validationResponse;
        }

        $apiKey = $headers[self::HEADERS['API_KEY']];
        $client = Cache::tags(self::CLIENT_TAG)->remember(
            key: implode(':', ['client', $apiKey]),
            ttl: 3600 * 3,
            callback: fn() => Client::select(['id', 'api_key', 'public_key', 'is_active'])
                ->where('api_key', $apiKey)
                ->first()
        );

        if (app()->environment(['local', 'develop', /* 'staging' */])) {
            $request->attributes->set('client', $client);

            return $next($request);
        }


        if ($validationResponse = $this->validateClient($request, $client)) {
            return $validationResponse;
        }

        if ($validationResponse = $this->verifyClientSignature($request, $headers, $client)) {
            return $validationResponse;
        }

        $request->attributes->set('client', $client);

        return $next($request);
    }

    private function getHeaders($request): array
    {
        $headers = [];
        foreach (self::HEADERS as $header) {
            $headers[$header] = $request->header($header, '');
        }

        return $headers;
    }

    private function validateHeaders(array $headers): ?Response
    {
        foreach ($headers as $key => $value) {
            if (strlen($value) === 0) {
                return ResponseHelper::generate(ResponseCode::Unauthorized, "Unauthorized. Missing header {$key}");
            }
        }

        $apiKey = $headers[self::HEADERS['API_KEY']];
        if (! str()->isUuid($apiKey)) {
            return ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Unknown client');
        }

        try {
            $timestamp = $headers[self::HEADERS['TIMESTAMP']];
            throw_if(Carbon::createFromFormat('c', $timestamp)->diffInSeconds(absolute: true) > 300, Exception::class);
        } catch (Exception) {
            return ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Invalid timestamp');
        }

        return null;
    }

    private function validateClient(Request $request, Client $client): ?Response
    {
        if (! $client) {
            return ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Unknown client');
        }

        if (! $client->is_active) {
            return ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Suspended');
        }

        $ipAddresses = collect([$request->ip(), ...((array) $request->header('x-forwarded-for'))])
            ->filter(fn($ip) => filter_var($ip, FILTER_VALIDATE_IP));

        if ($ipAddresses->isEmpty() || ! ClientIpAddress::containingAnyIp($ipAddresses, $client->id)->exists()) {
            return ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Invalid IP');
        }

        return null;
    }

    private function verifyClientSignature(Request $request, array $headers, Client $client): ?Response
    {
        $timestamp = $headers[self::HEADERS['TIMESTAMP']];
        $signature = $headers[self::HEADERS['SIGNATURE']];
        $requestBody = '';

        if (in_array($request->getMethod(), ['POST', 'PUT', 'DELETE'])) {
            $requestBody = json_encode($request->all(), JSON_UNESCAPED_SLASHES);
        }

        $verifySignatureResult = SecurityHelper::verifyAsymmetricSignature(
            data: implode(':', [
                $request->getMethod(),
                $request->getPathInfo(),
                hash('sha256', $requestBody),
                $timestamp,
            ]),
            signature: $signature,
            publicKey: $client->public_key
        );

        if ($verifySignatureResult !== 1) {
            return ResponseHelper::generate(ResponseCode::Unauthorized, 'Unauthorized. Invalid signature');
        }

        return null;
    }
}

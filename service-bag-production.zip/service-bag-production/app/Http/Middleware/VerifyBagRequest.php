<?php

namespace App\Http\Middleware;

use App\Enums\LogLevel;
use App\Enums\ResponseCodeSnap;
use App\Helpers\BagConfigHelper;
use App\Helpers\LogHelper;
use App\Helpers\ResponseHelper;
use App\Helpers\SecurityHelper;
use Carbon\Carbon;
use Carbon\Exceptions\InvalidFormatException;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Throwable;

class VerifyBagRequest
{
    private const HEADERS = [
        'TIMESTAMP'     => 'X-TIMESTAMP',
        'SIGNATURE'     => 'X-SIGNATURE',
        'CHANNEL_ID'    => 'CHANNEL-ID',
        'PARTNER_ID'    => 'X-PARTNER-ID',
        'EXTERNAL_ID'   => 'X-EXTERNAL-ID',
        'AUTHORIZATION' => 'Authorization',
    ];

    public function handle(Request $request, Closure $next): Response
    {
        $headers = $this->getHeaders($request);

        if ($validationResponse = $this->validateHeaders($headers)) {
            return $validationResponse;
        }

        if ($validationResponse = $this->verifyAccessToken($headers)) {
            return $validationResponse;
        }

        if ($validationResponse = $this->verifyTransactionApiSignature($request, $headers)) {
            return $validationResponse;
        }

        return $next($request);
    }

    private function getHeaders($request): array
    {
        $headers = [];
        foreach (self::HEADERS as $key => $header) {
            $headers[$header] = $key === 'AUTHORIZATION' ? $request->bearerToken()
                : ($request->header($header) ?? '');
        }

        return $headers;
    }

    private function validateHeaders(array $headers): ?Response
    {
        $missingField = array_search('', array_map('trim', $headers));
        if ($missingField) {
            return ResponseHelper::generate(
                ResponseCodeSnap::InvalidMandatoryField,
                message: 'Missing Mandatory Field',
                context: "{{$missingField}}"
            );
        }

        // Validate Timestamp
        try {
            $timestamp = $headers[self::HEADERS['TIMESTAMP']];
            throw_if(
                Carbon::createFromFormat('c', $timestamp)->diffInSeconds(absolute: true) > 300,
                InvalidFormatException::class
            );
        } catch (InvalidFormatException) {
            return ResponseHelper::generate(
                ResponseCodeSnap::InvalidFieldFormat,
                context: '{' . self::HEADERS['TIMESTAMP'] . '}'
            );
        }

        // Validate External Id
        $externalId = $headers[self::HEADERS['EXTERNAL_ID']];

        // Validate format: must be alpha-numeric (bag custom) and max 36 chars
        if (strlen($externalId) > 36 || ! preg_match('/^[a-zA-Z0-9]+$/', $externalId)) {
            return ResponseHelper::generate(code: ResponseCodeSnap::InvalidFieldFormat, context: '{X-EXTERNAL-ID}');
        }

        // Ensure uniqueness per day using cache
        $key = implode(':', ['external-id', 'bag', $externalId]);
        if (!Cache::add($key, true, now()->endOfDay())) {
            LogHelper::create(LogLevel::Debug, 'Conflict from Middleware', $headers);

            return ResponseHelper::generate(ResponseCodeSnap::Conflict);
        }

        return null;
    }

    private function verifyAccessToken(array $headers): ?Response
    {
        $accessToken = $headers[self::HEADERS['AUTHORIZATION']];
        $partnerId = $headers[self::HEADERS['PARTNER_ID']];

        try {
            $accessTokenPayload = SecurityHelper::verifyJwt($accessToken);
        } catch (Throwable $th) {
            Log::debug('Failed Verify JWT' . $th->getMessage());

            return ResponseHelper::generate(ResponseCodeSnap::InvalidToken, message: 'Access Token Invalid');
        }

        // Log::info('client_id' . BagConfigHelper::outbound()['client_id']);
        // Log::info('client_id bag' . $accessTokenPayload->sub);
        // Log::info('partner_id' . BagConfigHelper::outbound()['partner_id']);
        // Log::info('partner_id bag' . $partnerId);
        $hasValidAccessToken = $accessTokenPayload->sub === BagConfigHelper::outbound()['client_id'];
        $hasValidPartnerId = $partnerId === BagConfigHelper::outbound()['partner_id'];

        if (! $hasValidAccessToken || ! $hasValidPartnerId) {
            return ResponseHelper::generate(ResponseCodeSnap::InvalidToken, message: 'Access Token Invalid');
        }

        return null;
    }

    private function verifyTransactionApiSignature(Request $request, array $headers): ?Response
    {
        $accessToken = $headers[self::HEADERS['AUTHORIZATION']];
        $timestamp = $headers[self::HEADERS['TIMESTAMP']];
        $signature = $headers[self::HEADERS['SIGNATURE']];

        $minifiedBody = $this->customMinifiedRequestBody($request);

        // Debugging - will be removed
        // $strToSign = implode(':', [
        //     $request->getMethod(),
        //     $request->getPathInfo(),
        //     $accessToken,
        //     hash('sha256', $minifiedBody),
        //     $timestamp,
        // ]);

        // LogHelper::create(LogLevel::Debug, "verifyTransactionApiSignature", ['strToSgn' => $strToSign], null);

        // LogHelper::create(LogLevel::Debug, "minifiedBody", ['minified' => $minifiedBody], null);

        // $sig = SecurityHelper::generateSymmetricSignature(
        //     'sha512',
        //     $strToSign,
        //     base64_decode(BagConfigHelper::outbound()['client_secret'])
        // );

        // LogHelper::create(LogLevel::Debug, "verifyTransactionApiSignature", ['sig' => $sig], null);

        // Debugging - will be removed
        $isSignatureValid = SecurityHelper::verifySymmetricSignature(
            algo: 'sha512',
            data: implode(':', [
                $request->getMethod(),
                $request->getPathInfo(),
                $accessToken,
                hash('sha256', $minifiedBody),
                $timestamp,
            ]),
            key: base64_decode(BagConfigHelper::outbound()['client_secret']),
            signature: $signature
        );

        if (! $isSignatureValid) {
            return ResponseHelper::generate(ResponseCodeSnap::Unauthorized, context: 'Signature');
        }

        return null;
    }

    // Custom: Bag custom minified request body
    public function customMinifiedRequestBody(Request $request): string
    {
        $data = $request->all();

        array_walk_recursive($data, fn(&$value) => is_string($value) && $value = preg_replace('/\s+/', '', $value));

        return json_encode($data, JSON_UNESCAPED_SLASHES);
    }
}

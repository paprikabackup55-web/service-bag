<?php

namespace App\Http\Controllers\Client\V1;

use App\Enums\LogLevel;
use App\Enums\ResponseCode;
use App\Exceptions\ApiException\BagSnapApiException;
use App\Exceptions\GetAccessTokenException;
use App\Helpers\LogHelper;
use App\Helpers\ResponseHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\Client\V1\Account\GetStatementRequest;
use App\Services\Account\AccountService;
use Illuminate\Support\Facades\Log;
use Throwable;

class AccountController extends Controller
{
    public function __construct(
        private AccountService $accountService
    ) {}

    public function getBalance(string $responseType)
    {
        try {
            $isSimpleResponse = $responseType === 'simple';
            $data = $this->accountService->getBalance($isSimpleResponse);
        } catch (GetAccessTokenException) {
            return ResponseHelper::generate(ResponseCode::GetAccessTokenFailed);
        } catch (BagSnapApiException $e) {
            return ResponseHelper::generate(ResponseCode::GetBalanceFailed, context: $e->getMessage());
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th);
            Log::error($th->getMessage(), ['exception' => $th]);

            return ResponseHelper::generate(ResponseCode::GeneralError);
        }

        return ResponseHelper::generate(code: ResponseCode::Ok, data: $data);
    }

    public function getStatement(GetStatementRequest $request)
    {
        try {
            $detailData = $this->accountService->getStatement(
                startDate: $request->startDate,
                endDate  : $request->endDate,
                page     : $request->page,
                perPage  : $request->perPage
            );
        } catch (GetAccessTokenException) {
            return ResponseHelper::generate(ResponseCode::GetAccessTokenFailed);
        } catch (BagSnapApiException $e) {
            return ResponseHelper::generate(ResponseCode::GetStatementFailed, context: $e->getMessage());
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th);

            return ResponseHelper::generate(ResponseCode::GeneralError);
        }

        return ResponseHelper::generate(
            code: ResponseCode::Ok,
            data: [
                'items' => collect($detailData)->sortBy('dateTime')->values(),
            ]
        );
    }
}

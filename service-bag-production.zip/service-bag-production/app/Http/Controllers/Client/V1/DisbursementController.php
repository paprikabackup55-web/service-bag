<?php

namespace App\Http\Controllers\Client\V1;

use App\Enums\LogLevel;
use App\Enums\ResponseCode;
use App\Exceptions\Disbursement\DuplicatePartnerReferenceNoException;
use App\Exceptions\Disbursement\InvalidDisbursementStatus;
use App\Exceptions\Disbursement\PartnerReferenceNoNotFound;
use App\Exceptions\Disbursement\PaymentMethodNotFound;
use App\Exceptions\LockAcquisitionException;
use App\Helpers\LogHelper;
use App\Helpers\ResponseHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\Client\V1\Disbursement\InquiryAccountRequest;
use App\Http\Requests\Client\V1\Disbursement\InquiryStatusRequest;
use App\Http\Requests\Client\V1\Disbursement\TransferRequest;
use App\Locks\LockContextFactory;
use App\Locks\LockManager;
use App\Services\Disbursement\DisbursementService;
use Exception;
use Throwable;

class DisbursementController extends Controller
{
    public function __construct(
        private LockManager $lockManager,
        private DisbursementService $disbursementService
    ) {}

    public function inquiryAccount(InquiryAccountRequest $request)
    {
        try {
            $client = $request->attributes->get('client');
            $context = LockContextFactory::createClientLockContext($request, $request->partnerReferenceNo);

            $lock = $this->lockManager->acquireClientLock($context);
            $disbursement = $this->disbursementService->inquiryAccount($client, $request->validated());
        } catch (LockAcquisitionException) {
            return ResponseHelper::generate(ResponseCode::Conflict);
        } catch (DuplicatePartnerReferenceNoException) {
            return ResponseHelper::generate(ResponseCode::DuplicatePartnerReferenceNo);
        } catch (PaymentMethodNotFound $e) {
            return ResponseHelper::generate(ResponseCode::ValidationError, message: $e->getMessage());
        } catch (Exception $e) {
            return ResponseHelper::generate(ResponseCode::ExternalServerError, $e->getMessage());
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th);
            return ResponseHelper::generate(ResponseCode::GeneralError);
        } finally {
            $lock->forceRelease();
        }

        return ResponseHelper::generate(
            code: ResponseCode::Ok,
            data: [
                'partnerReferenceNo' => $disbursement->partner_reference_no,
                'referenceNo'        => $disbursement->reference_no,
                'accountName'        => $disbursement->account_name,
            ]
        );
    }

    public function transfer(TransferRequest $request)
    {
        try {
            $client = $request->attributes->get('client');
            $partnerReferenceNo = $request->validated()['partnerReferenceNo'];
            $context = LockContextFactory::createClientLockContext($request, $partnerReferenceNo);

            $lock = $this->lockManager->acquireClientLock($context);
            $disbursement = $this->disbursementService->transfer($client, $partnerReferenceNo);
        } catch (LockAcquisitionException) {
            return ResponseHelper::generate(ResponseCode::Conflict);
        } catch (PartnerReferenceNoNotFound $e) {
            return ResponseHelper::generate(ResponseCode::NotFound, $e->getMessage());
        } catch (InvalidDisbursementStatus $e) {
            return ResponseHelper::generate(ResponseCode::InvalidTransactionStatus, data: $e->getData());
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th);
            return ResponseHelper::generate(ResponseCode::GeneralError);
        } finally {
            $lock->forceRelease();
        }

        return ResponseHelper::generate(
            code: ResponseCode::Ok,
            data: [
                'statusCode'         => $disbursement->status_code,
                'statusDesc'         => $disbursement->status_desc,
                'partnerReferenceNo' => $disbursement->partner_reference_no,
                'referenceNo'        => $disbursement->reference_no,
                'accountNo'          => $disbursement->account_no,
                'accountName'        => $disbursement->account_name,
                'bankCode'           => $disbursement->bank_code,
                'amount'             => $disbursement->amount,
                'currency'           => $disbursement->currency,
                'remark'             => $disbursement->remark,
                'paymentMethod'      => $disbursement->paymentMethod->code,
            ]
        );
    }

    public function inquiryStatus(InquiryStatusRequest $request)
    {
        
        try {
            $client = $request->attributes->get('client');
            $partnerReferenceNo = $request->validated()['partnerReferenceNo'];
            $disbursement = $this->disbursementService->inquiryStatus($client, $partnerReferenceNo);
        } catch (PartnerReferenceNoNotFound $e) {
            return ResponseHelper::generate(ResponseCode::NotFound, $e->getMessage());
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th);
            return ResponseHelper::generate(ResponseCode::GeneralError);
        }

        return ResponseHelper::generate(
            code: ResponseCode::Ok,
            data: [
                'statusCode'         => $disbursement->status_code,
                'statusDesc'         => $disbursement->status_desc,
                'partnerReferenceNo' => $disbursement->partner_reference_no,
                'referenceNo'        => $disbursement->reference_no,
                'accountNo'          => $disbursement->account_no,
                'accountName'        => $disbursement->account_name,
                'bankCode'           => $disbursement->bank_code,
                'amount'             => $disbursement->amount,
                'currency'           => $disbursement->currency,
                'remark'             => $disbursement->remark,
                'paymentMethod'      => $disbursement->paymentMethod->code,
            ]
        );
    }
}

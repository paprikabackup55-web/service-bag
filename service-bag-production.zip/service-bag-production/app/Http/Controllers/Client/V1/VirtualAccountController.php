<?php

namespace App\Http\Controllers\Client\V1;

use App\Enums\LogLevel;
use App\Enums\ResponseCode;
use App\Exceptions\VirtualAccount\InvalidExpirationDateException;
use App\Exceptions\LockAcquisitionException;
use App\Exceptions\VirtualAccount\VirtualAccountAlreadyExistsException;
use App\Exceptions\VirtualAccount\VirtualAccountNotFoundException;
use App\Helpers\LogHelper;
use App\Helpers\ResponseHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\Client\V1\VirtualAccount\CreateRequest;
use App\Http\Requests\Client\V1\VirtualAccount\DeleteRequest;
use App\Http\Requests\Client\V1\VirtualAccount\UpdateRequest;
use App\Locks\LockContextFactory;
use App\Locks\LockManager;
use App\Services\VirtualAccount\VaClientService;
use Throwable;

class VirtualAccountController extends Controller
{
    public function __construct(
        private LockManager $lockManager,
        private VaClientService $vaClientService
    ) {}

    public function create(CreateRequest $request)
    {
        try {
            $client = $request->attributes->get('client');
            $context = LockContextFactory::createClientLockContext($request, $request->trxId);
            
            $lock = $this->lockManager->acquireClientLock($context);
            $virtualAccount = $this->vaClientService->createVirtualAccount($client, $request->validated());
        } catch (LockAcquisitionException) {
            return ResponseHelper::generate(ResponseCode::Conflict);
        } catch (InvalidExpirationDateException $e) {
            return ResponseHelper::generate(ResponseCode::ValidationError, message: $e->getMessage());
        } catch (VirtualAccountAlreadyExistsException) {
            return ResponseHelper::generate(ResponseCode::VirtualAccountAlreadyExists);
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th);

            return ResponseHelper::generate(ResponseCode::GeneralError);
        } finally {
            $lock->forceRelease();
        }

        return ResponseHelper::generate(
            code: ResponseCode::Ok,
            data: [
                'virtualAccountNo' => $virtualAccount->no,
                'virtualAccountName' => $virtualAccount->name,
            ]
        );
    }

    public function update(UpdateRequest $request)
    {
        try {
            $client = $request->attributes->get('client');
            $vaNo = $request->virtualAccountNo;
            $context = LockContextFactory::createClientLockContext($request, $vaNo);
            $dataToUpdate = [
                'name' => strtoupper($request->customerName),
                'is_active' => $request->isActive,
                'paymentData' => array_filter([
                    'amount' => $request->amount,
                    'currency' => $request->currency,
                    'expires_at' => $request->expiration,
                ]),
            ];

            $lock = $this->lockManager->acquireClientLock($context);
            $virtualAccount = $this->vaClientService->updateVirtualAccount($client, $vaNo, $dataToUpdate);
        } catch (LockAcquisitionException) {
            return ResponseHelper::generate(ResponseCode::Conflict);
        } catch (VirtualAccountNotFoundException) {
            return ResponseHelper::generate(ResponseCode::VirtualAccountNotFound);
        } catch (Throwable) {
            return ResponseHelper::generate(ResponseCode::GeneralError);
        } finally {
            $lock->forceRelease();
        }

        return ResponseHelper::generate(
            code: ResponseCode::Ok,
            data: [
                'virtualAccountNo' => $virtualAccount->no,
                'virtualAccountName' => $virtualAccount->name,
                'isActive' => $virtualAccount->is_active,
            ]
        );
    }

    public function delete(DeleteRequest $request)
    {
        
        try {
            $client = $request->attributes->get('client');
            $vaNo = $request->virtualAccountNo;
            $context = LockContextFactory::createClientLockContext($request, $vaNo);
            
            $lock = $this->lockManager->acquireClientLock($context);
            $this->vaClientService->deleteVirtualAccount($client, $vaNo);
        } catch (LockAcquisitionException) {
            return ResponseHelper::generate(ResponseCode::Conflict);
        } catch (VirtualAccountNotFoundException) {
            return ResponseHelper::generate(ResponseCode::VirtualAccountNotFound);
        } catch (Throwable) {
            return ResponseHelper::generate(ResponseCode::GeneralError);
        } finally {
            $lock->forceRelease();
        }

        return ResponseHelper::generate(ResponseCode::Ok);
    }
}

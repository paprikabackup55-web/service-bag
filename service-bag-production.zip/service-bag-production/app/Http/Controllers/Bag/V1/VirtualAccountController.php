<?php

namespace App\Http\Controllers\Bag\V1;

use App\Data\InquiryVaData;
use App\Data\NotificationVaData;
use App\Data\PaymentVaData;
use App\Enums\LogLevel;
use App\Enums\PaymentStatus;
use App\Enums\ResponseCodeSnap;
use App\Exceptions\VirtualAccount\BillNotFoundException;
use App\Exceptions\VirtualAccount\DuplicateInquiryRequestException;
use App\Exceptions\VirtualAccount\ExpiredBillException;
use App\Exceptions\VirtualAccount\InquiryRequestNotFoundException;
use App\Exceptions\VirtualAccount\InvalidAmountException;
use App\Exceptions\LockAcquisitionException;
use App\Exceptions\VirtualAccount\PaidBillException;
use App\Exceptions\VirtualAccount\VirtualAccountNotFoundException;
use App\Helpers\LogHelper;
use App\Helpers\ResponseHelper;
use App\Helpers\ResponsePayloadHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\Bag\V1\InquiryVaRequest;
use App\Http\Requests\Bag\V1\NotificationVaRequest;
use App\Http\Requests\Bag\V1\PaymentVaRequest;
use App\Locks\LockContextFactory;
use App\Locks\LockManager;
use App\Services\VirtualAccount\VaBagService;
use Throwable;

class VirtualAccountController extends Controller
{
    public function __construct(
        private LockManager $lockManager,
        private VaBagService $vaBagService
    ) {}

    public function inquiry(InquiryVaRequest $request)
    {
        try {
            $context = LockContextFactory::createBagLockContext($request);
            $channelId = $request->header('CHANNEL-ID');
            $lock = $this->lockManager->acquireBagLock($context);

            $dto = InquiryVaData::from($request->validated());
            $virtualAccount = $this->vaBagService->inquiry($dto, $channelId);
        } catch (LockAcquisitionException) {
            return ResponseHelper::generate(ResponseCodeSnap::Conflict);
        } catch (DuplicateInquiryRequestException) {
            return ResponseHelper::generate(ResponseCodeSnap::InvalidFieldFormat, context: '{inquiryRequestId}');
        } catch (VirtualAccountNotFoundException) {
            return ResponseHelper::generate(ResponseCodeSnap::InvalidBillOrVirtualAccount, message: 'Bill not found');
        } catch (PaidBillException) {
            return ResponseHelper::generate(ResponseCodeSnap::PaidBill);
        } catch (ExpiredBillException) {
            return ResponseHelper::generate(ResponseCodeSnap::InvalidBillOrVirtualAccountExpired, message: 'Bill expired');
        } catch (InvalidAmountException) {
            return ResponseHelper::generate(ResponseCodeSnap::InvalidAmount);
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th);

            return ResponseHelper::generate(ResponseCodeSnap::GeneralError);
        } finally {
            $lock->release();
        }

        return ResponseHelper::generate(
            ResponseCodeSnap::Successful,
            message: 'Success',
            data: ResponsePayloadHelper::snapInquiryPayload(
                request: $request,
                status: PaymentStatus::Success->value,
                englishReason: 'Success',
                indonesianReason: 'Sukses',
                virtualAccount: $virtualAccount
            )
        );
    }

    /* Used when there is va transaction via API from client's partner (core pg's merchant) */
    public function payment(PaymentVaRequest $request)
    {
        try {
            $context = LockContextFactory::createBagLockContext($request);
            $lock = $this->lockManager->acquireBagLock($context);

            $dto = PaymentVaData::from($request->validated());
            $vaPayment = $this->vaBagService->payment($dto);
        } catch (LockAcquisitionException) {
            return ResponseHelper::generate(ResponseCodeSnap::Conflict);
        } catch (InvalidAmountException) {
            return ResponseHelper::generate(ResponseCodeSnap::InvalidAmount);
        } catch (VirtualAccountNotFoundException | BillNotFoundException) {
            return ResponseHelper::generate(ResponseCodeSnap::InvalidBillOrVirtualAccount, message: 'Bill not found');
        } catch (InquiryRequestNotFoundException) {
            return ResponseHelper::generate(ResponseCodeSnap::InvalidFieldFormat, context: '{paymentRequestId}');
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th, null);

            return ResponseHelper::generate(ResponseCodeSnap::GeneralError);
        } finally {
            $lock->release();
        }

        return ResponseHelper::generate(
            ResponseCodeSnap::Successful,
            message: 'Success',
            data: ResponsePayloadHelper::snapPaymentPayload(
                request: $request,
                status: PaymentStatus::Success->value,
                englishReason: $vaPayment->status_desc['en'],
                indonesianReason: $vaPayment->status_desc['id']
            )
        );
    }

    public function paymentNotification(NotificationVaRequest $request)
    {
        try {
            $context = LockContextFactory::createBagLockContext($request);
            $lock = $this->lockManager->acquireBagLock($context);

            $notificationDto = NotificationVaData::from($request->validated());
            $payment = $this->vaBagService->paymentNotification($notificationDto);
        } catch (LockAcquisitionException $e) {
            LogHelper::create(LogLevel::Error, __METHOD__, $e);
            return ResponseHelper::generate(ResponseCodeSnap::Conflict);
        } catch (VirtualAccountNotFoundException) {
            return ResponseHelper::generate(ResponseCodeSnap::InvalidBillOrVirtualAccount, message: 'Virtual Account not found');
        } catch (BillNotFoundException) {
            return ResponseHelper::generate(ResponseCodeSnap::InvalidBillOrVirtualAccount, message: 'Bill not found');
        } catch (Throwable $th) {
            LogHelper::create(LogLevel::Error, __METHOD__, $th);
            return ResponseHelper::generate(ResponseCodeSnap::GeneralError);
        } finally {
            $lock->release();
        }

        return ResponseHelper::generate(
            ResponseCodeSnap::Successful,
            message: 'Success',
            data: ResponsePayloadHelper::snapNotificationPayload(
                request: $request,
                payment: $payment,
                status: $payment->status_code->value,
                englishReason: $payment->status_desc['en'],
                indonesianReason: $payment->status_desc['id']
            )
        );
    }
}

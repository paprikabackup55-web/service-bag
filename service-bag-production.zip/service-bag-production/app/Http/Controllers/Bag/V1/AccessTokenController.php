<?php

namespace App\Http\Controllers\Bag\V1;

use App\Enums\LogLevel;
use App\Enums\ResponseCodeSnap;
use App\Helpers\LogHelper;
use App\Helpers\ResponseHelper;
use App\Helpers\SecurityHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\Bag\V1\AccessTokenB2bRequest;
use Carbon\Carbon;
use Carbon\Exceptions\InvalidFormatException;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Storage;

class AccessTokenController extends Controller
{
    private const HEADERS = [
        'CONTENT_TYPE' => 'Content-Type',
        'TIMESTAMP'    => 'X-TIMESTAMP',
        'CLIENT_KEY'   => 'X-CLIENT-KEY',
        'SIGNATURE'    => 'X-SIGNATURE',
    ];

    public function generate(AccessTokenB2bRequest $request)
    {
        $headers = $this->getHeaders($request);

        $validationResponse = $this->validateHeaders($headers);
        if ($validationResponse) {
            return $validationResponse;
        }

        if (($request->grantType ?? '') !== 'client_credentials') {
            return ResponseHelper::generate(ResponseCodeSnap::InvalidFieldFormat, context: '{grantType}');
        }

        $signatureResponse = $this->verifyAccessTokenApiSignature($headers);
        if ($signatureResponse) {
            return $signatureResponse;
        }

        $tokenLifetime = (int) config('services.jwt.ttl');
        $clientKey = $headers[self::HEADERS['CLIENT_KEY']];
        $accessToken = SecurityHelper::generateJwt(
            subject : $clientKey,
            audience: 'API',
            lifetime: $tokenLifetime
        );

        return ResponseHelper::generate(
            ResponseCodeSnap::Successful,
            data: [
                'accessToken' => $accessToken,
                'tokenType'   => 'Bearer',
                'expiresIn'   => (string) $tokenLifetime,
            ]
        );
    }

    private function getHeaders($request): array
    {
        $headers = [];
        foreach (self::HEADERS as $header) {
            $headers[$header] = $request->header($header) ?? '';
        }

        return $headers;
    }

    private function validateHeaders(array $headers): ?JsonResponse
    {
        foreach ($headers as $key => $value) {
            if (strlen(trim($value)) === 0) {
                return ResponseHelper::generate(
                    ResponseCodeSnap::InvalidMandatoryField,
                    message: 'Missing Mandatory Field',
                    context: "{{$key}}"
                );
            }
        }

        try {
            $timestamp = $headers[self::HEADERS['TIMESTAMP']];
            throw_if(
                Carbon::createFromFormat('c', $timestamp)->diffInSeconds(absolute: true) > 300,
                InvalidFormatException::class
            );
        } catch (InvalidFormatException) {
            return ResponseHelper::generate(
                ResponseCodeSnap::InvalidFieldFormat,
                context: '{'.self::HEADERS['TIMESTAMP'].'}'
            );
        }

        return null;
    }

    private function verifyAccessTokenApiSignature(array $headers): ?JsonResponse
    {
        $verifySignatureResult = SecurityHelper::verifyAsymmetricSignature(
            data: $headers[self::HEADERS['CLIENT_KEY']].'|'.$headers[self::HEADERS['TIMESTAMP']],
            signature: $headers[self::HEADERS['SIGNATURE']],
            publicKey: file_get_contents(storage_path('app/private/bag/public.pem'))
        );

        if ($verifySignatureResult !== 1) {
            LogHelper::create(LogLevel::Debug, 'unauthorized form access token', [], null);
            return ResponseHelper::generate(ResponseCodeSnap::Unauthorized, context: 'Signature');
        }

        return null;
    }
}

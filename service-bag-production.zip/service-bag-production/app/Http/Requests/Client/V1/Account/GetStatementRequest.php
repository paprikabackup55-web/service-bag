<?php

namespace App\Http\Requests\Client\V1\Account;

use Illuminate\Foundation\Http\FormRequest;

class GetStatementRequest extends FormRequest
{
    protected $stopOnFirstFailure = true;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'startDate' => ['bail', 'required', 'string', 'date_format:Y-m-d', 'before_or_equal:endDate'],
            'endDate' => ['bail', 'required', 'string', 'date_format:Y-m-d'],
            'page' => ['bail', 'required', 'integer', 'min:1'],
            'perPage' => ['bail', 'required', 'integer', 'min:10']
        ];
    }
}

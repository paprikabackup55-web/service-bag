<?php

namespace App\Http\Requests\Client\V1\Disbursement;

use Illuminate\Foundation\Http\FormRequest;

class TransferRequest extends FormRequest
{
    protected $stopOnFirstFailure = true;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'partnerReferenceNo' => ['bail', 'required', 'string', 'alpha_num:ascii', 'uppercase', 'max:30']
        ];
    }
}

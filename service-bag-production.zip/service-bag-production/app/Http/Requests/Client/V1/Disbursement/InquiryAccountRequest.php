<?php

namespace App\Http\Requests\Client\V1\Disbursement;

use App\Models\PaymentMethod;
use App\Rules\Number;
use Illuminate\Database\Query\Builder;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class InquiryAccountRequest extends FormRequest
{
    protected $stopOnFirstFailure = true;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'partnerReferenceNo' => ['bail', 'required', 'string', 'alpha_num:ascii', 'uppercase', 'max:30'],
            'accountNo'          => ['bail', 'required', 'string', new Number, 'max:30'],
            'bankCode'           => ['bail', 'required', 'string', new Number, 'size:3'],
            'bankType'           => [
                'bail',
                'nullable',
                'required_if:paymentMethodCode,BI_FAST',
                'string',
                Rule::in(['01', '02'])
            ],
            'amount'            => ['bail', 'required', 'decimal:2', 'min:10000.00'],
            'currency'          => ['bail', 'required', 'string', Rule::in(['IDR'])],
            'remark'            => ['bail', 'nullable', 'string', 'max:255'],
            'paymentMethodCode' => [
                'bail',
                'required',
                'string',
                Rule::exists('payment_methods', 'code')->where(function (Builder $query) {
                    return $query->whereIn('id', [PaymentMethod::INTRA, PaymentMethod::INTER, PaymentMethod::BI_FAST]);
                }),
            ],
        ];
    }

    /**
     * Prepare the data for validation by remapping paymentMethodCode
     */
    protected function prepareForValidation(): void
    {
        $remappedCode = in_array($this->paymentMethodCode, ['ONLINE', 'SKN', 'RTGS']) ? 'INTER'
            : $this->paymentMethodCode;

        $this->merge([
            'paymentMethodCode' => $remappedCode
        ]);
    }
}

<?php

namespace App\Http\Requests\Client\V1\VirtualAccount;

use App\Enums\Currency;
use App\Rules\Number;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateRequest extends FormRequest
{
    const EXP_DATE_FORMAT = 'Y-m-d H:i:s';

    protected $stopOnFirstFailure = true;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'virtualAccountNo' => ['bail', 'required', 'string', new Number],
            'customerName'     => ['bail', 'required', 'string', 'max:100'],
            'isActive'         => ['bail', 'required', 'boolean'],
            'amount'           => ['bail', 'sometimes', 'required', 'decimal:2'],
            'currency'         => ['bail', 'sometimes', 'required', Rule::enum(Currency::class)],
            'expiration'       => ['bail', 'sometimes', 'required', 'date_format:'.self::EXP_DATE_FORMAT],
        ];
    }
}

<?php

namespace App\Http\Requests\Client\V1\VirtualAccount;

use App\Enums\Currency;
use App\Enums\VirtualAccountType;
use App\Rules\Number;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CreateRequest extends FormRequest
{
    const EXP_DATE_FORMAT = 'Y-m-d H:i:s';

    protected $stopOnFirstFailure = true;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'partnerServiceId' => ['bail', 'required', 'string', 'max:8'],
            'trxId' => ['bail', 'required', 'string', 'max:64'],
            'customerNo' => [
                'bail',
                'nullable',
                'required_if:virtualAccountTrxType,'.VirtualAccountType::OPEN_PAYMENT->value,
                'string',
                new Number,
                'max:9', // todo: adjust also in client/core-pg
            ],
            'customerName' => ['bail', 'required', 'string', 'max:100'],
            'virtualAccountType' => ['bail', 'required', 'string', Rule::enum(VirtualAccountType::class)],
            'amount' => [
                'bail',
                'nullable',
                'required_if:virtualAccountType,'.VirtualAccountType::CLOSE_PAYMENT->value,
                'decimal:2',
            ],
            'currency' => [
                'bail',
                'nullable',
                'required_if:virtualAccountType,'.VirtualAccountType::CLOSE_PAYMENT->value,
                Rule::enum(Currency::class),
            ],
            'expiration' => [
                'bail',
                'nullable',
                'required_if:virtualAccountType,'.VirtualAccountType::CLOSE_PAYMENT->value,
                'date_format:'.self::EXP_DATE_FORMAT,
            ],
        ];
    }
}

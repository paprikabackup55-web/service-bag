<?php

namespace App\Http\Requests\Client\V1\VirtualAccount;

use App\Rules\Number;
use Illuminate\Foundation\Http\FormRequest;

class DeleteRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'virtualAccountNo' => ['bail', 'required', 'string', new Number],
        ];
    }
}

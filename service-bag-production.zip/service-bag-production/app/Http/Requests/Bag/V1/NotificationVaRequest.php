<?php

namespace App\Http\Requests\Bag\V1;

use Illuminate\Foundation\Http\FormRequest;

class NotificationVaRequest extends FormRequest
{
    protected $stopOnFirstFailure = true;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'partnerServiceId'                 => ['bail', 'required', 'string', 'max:8', 'regex:/^ *\d+$/'],
            'customerNo'                       => ['bail', 'required', 'string', 'max:20'],
            'virtualAccountNo'                 => ['bail', 'required', 'string', 'max:28'],
            'inquiryRequestId'                 => ['bail', 'nullable', 'string', 'max:128'],//O
            'paymentRequestId'                 => ['bail', 'nullable', 'string', 'max:128'],//O
            'partnerReferenceNo'               => ['bail', 'nullable', 'string', 'max:128'],//O
            'trxDateTime'                      => ['bail', 'nullable', 'string', 'date_format:YmdHis'],//O
            'paymentStatus'                    => ['bail', 'nullable', 'string', 'max:20'],//O
            'paymentFlagReason.english'        => ['bail', 'nullable', 'string', 'max:200'],
            'paymentFlagReason.indonesia'      => ['bail', 'nullable', 'string', 'max:200'],
            'additionalInfo.merchantId'        => ['bail', 'nullable', 'string', 'max:6'],//O
            'additionalInfo.amount'            => ['bail', 'nullable', 'string', 'max:12'],//O
            'additionalInfo.proCode'           => ['bail', 'nullable', 'string', 'max:6'],//O
            'additionalInfo.flagAmountCheck'   => ['bail', 'nullable', 'string', 'max:2'],//O
            'additionalInfo.destinationVAName' => ['bail', 'nullable', 'string', 'max:35'],//O
            'additionalInfo.sourceBankCode'    => ['bail', 'nullable', 'string', 'size:3'],//O
            'additionalInfo.sourceName'        => ['bail', 'nullable', 'string', 'max:35'],//O
            'additionalInfo.sourceAccount'     => ['bail', 'nullable', 'string', 'max:10'],//O
            'additionalInfo.description'       => ['bail', 'nullable', 'string', 'max:255'],//O
        ];
    }
}

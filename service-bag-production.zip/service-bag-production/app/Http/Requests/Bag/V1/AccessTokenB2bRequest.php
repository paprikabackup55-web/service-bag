<?php

namespace App\Http\Requests\Bag\V1;

use Illuminate\Foundation\Http\FormRequest;

class AccessTokenB2bRequest extends FormRequest
{
    protected $stopOnFirstFailure = true;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'grantType' => ['bail', 'required', 'string'],
        ];
    }
}

<?php

namespace App\Http\Requests\Bag\V1;

use App\Enums\Currency;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class InquiryVaRequest extends FormRequest
{
    protected $stopOnFirstFailure = true;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'partnerServiceId'               => ['bail', 'required', 'string', 'max:8', 'regex:/^ *\d+$/'],
            'customerNo'                     => ['bail', 'required', 'string', 'max:20'],
            'virtualAccountNo'               => ['bail', 'required', 'string', 'max:28'],
            'txnDateInit'                    => ['bail', 'required', 'string', 'date_format:Y-m-d\TH:i:sP'],
            'language'                       => ['bail', 'nullable', 'string', 'size:2'],
            'inquiryRequestId'               => ['bail', 'required', 'string', 'max:128'],
            'amount.value'                   => ['bail', 'nullable', 'string', 'regex:/^\d+(\.\d{2})?$/'],
            'amount.currency'                => ['bail', 'required', 'string', Rule::enum(Currency::class)],
            'channelCode'                    => ['bail', 'nullable', 'regex:/^\d{1,4}$/'], //O
            'sourceAccountNo'                => ['bail', 'nullable', 'string', 'max:32'], // O: hashed
            'sourceBankCode'                 => ['bail', 'nullable', 'string', 'size:3'], //O
            'passApp'                        => ['bail', 'nullable', 'string', 'max:64'], //amountO
            'additionalInfo.channel'         => ['bail', 'nullable', 'string', 'max:8'], //O
            'additionalInfo.merchantId'      => ['bail', 'nullable', 'string', 'max:6'],
            'additionalInfo.proCode'         => ['bail', 'nullable', 'string', 'max:6'],
            'additionalInfo.senderName'      => ['bail', 'nullable', 'string', 'max:35'],
            'additionalInfo.flagAmountCheck' => ['bail', 'nullable', 'string', 'max:2'], //O
            'additionalInfo.referenceNo'     => ['bail', 'nullable', 'string', 'max:12'], //O
        ];
    }
}

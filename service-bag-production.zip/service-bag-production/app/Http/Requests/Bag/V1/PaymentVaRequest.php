<?php

namespace App\Http\Requests\Bag\V1;

use App\Enums\Currency;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PaymentVaRequest extends FormRequest
{
    protected $stopOnFirstFailure = true;

    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'partnerServiceId'          => ['bail', 'required', 'string', 'max:8', 'regex:/^ *\d+$/'],
            'customerNo'                => ['bail', 'required', 'string', 'max:20'],
            'virtualAccountNo'          => ['bail', 'required', 'string', 'max:28'],
            'virtualAccountName'        => ['bail', 'nullable', 'string', 'max:255'],
            'paymentRequestId'          => ['bail', 'required', 'string', 'max:128'],
            'channelCode'               => ['bail', 'nullable', 'integer', 'digits:4'],
            'sourceAccountNo'           => ['bail', 'nullable', 'string', 'max:32'],
            'sourceBankCode'            => ['bail', 'nullable', 'string', 'size:3'],                      //
            'paidAmount.value'          => ['bail', 'required', 'string', 'decimal:2'],
            'paidAmount.currency'       => ['bail', 'required', 'string', Rule::enum(Currency::class)],
            'totalAmount.value'         => ['bail', 'required', 'string', 'decimal:2'],
            'totalAmount.currency'      => ['bail', 'required', 'string', Rule::enum(Currency::class)],
            'trxDateTime'               => ['bail', 'nullable', 'string', 'date_format:Y-m-d\TH:i:sP'],
            'referenceNo'               => ['bail', 'required', 'string', 'max:16'],
            'additionalInfo.channel'    => ['bail', 'nullable', 'string', 'max:12'],
            'additionalInfo.merchantId' => ['bail', 'nullable', 'string', 'max:6'],
            'additionalInfo.proCode'    => ['bail', 'nullable', 'string', 'max:6'],
            // 'cumulativePaymentAmount.value' => ['bail', 'required', 'string', 'decimal:2'],
            // 'cumulativePaymentAmount.currency' => ['bail', 'required', 'string', Rule::in(['IDR'])],
            // 'billAmount.value' => ['bail', 'required', 'string', 'decimal:2'],
            // 'billAmount.currency' => ['bail', 'required', 'string', Rule::in(['IDR'])],
            // 'trxId' => ['bail', 'required_if:', 'string', 'max:64'],
            // 'hashedSourceAccountNo' => ['bail', 'required', 'string'], // TODO
        ];
    }
}
